export type ThemeId = 'cozy' | 'kawaii' | 'trattoria' | 'cyberpunk' | 'minimalist';

export interface GameTheme {
  id: ThemeId;
  name: string;
  subtitle: string;
  icon: string;
  previewColor: string;
  // Colors and styling classes
  bodyBg: string;
  headerBg: string;
  headerBorder: string;
  headerText: string;
  tabActive: string;
  tabInactive: string;
  counterWallGrad: string;
  counterDesk: string;
  dialogueBg: string;
  dialogueBorder: string;
  dialogueArrow: string;
  kitchenBg: string;
  kitchenBorder: string;
  topBarBg: string;
  topBarBorder: string;
  peelBg: string;
  peelBorder: string;
  peelInnerRing: string;
  cardboardBox: string;
  cardboardBorder: string;
  accentBtnGrad: string;
  accentColor: string;
}

export const THEMES: Record<ThemeId, GameTheme> = {
  cozy: {
    id: 'cozy',
    name: 'Rústica Cozy (Original)',
    subtitle: 'Tonos cálidos, madera artesanal y papel kraft',
    icon: '🍕',
    previewColor: '#C89B66',
    bodyBg: '#2A2321',
    headerBg: '#8C6D52',
    headerBorder: '#6E533D',
    headerText: '#FAF5EE',
    tabActive: 'bg-amber-100 text-amber-950 shadow-xs',
    tabInactive: 'text-amber-100 hover:text-white hover:bg-white/10',
    counterWallGrad: 'from-[#F5ECD9] to-[#D5C0A7]',
    counterDesk: 'bg-[#8C6D52] border-[#6E533D] text-amber-100',
    dialogueBg: 'bg-[#FAF5EE]',
    dialogueBorder: 'border-[#8C6D52]',
    dialogueArrow: '#FAF5EE',
    kitchenBg: 'bg-[#EFE6D8] border-[#D7C9B1]',
    kitchenBorder: 'border-[#E3D6C1]',
    topBarBg: 'bg-[#FAF6EE]',
    topBarBorder: 'border-[#E3D6C1]',
    peelBg: 'bg-[#C89B66]',
    peelBorder: 'border-[#936639]',
    peelInnerRing: 'border-[#A87B4C]',
    cardboardBox: 'bg-[#CDB597]',
    cardboardBorder: 'border-[#A3896D]',
    accentBtnGrad: 'from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500',
    accentColor: '#D97706',
  },
  kawaii: {
    id: 'kawaii',
    name: 'Kawaii Pastel & Cute',
    subtitle: 'Rosas pastel, crema de fresa y detalles tiernos',
    icon: '🌸',
    previewColor: '#F472B6',
    bodyBg: '#FDF2F8',
    headerBg: '#EC4899',
    headerBorder: '#DB2777',
    headerText: '#FFF1F2',
    tabActive: 'bg-white text-pink-700 shadow-xs font-bold',
    tabInactive: 'text-pink-100 hover:text-white hover:bg-white/20',
    counterWallGrad: 'from-[#FFF1F2] to-[#FCE7F3]',
    counterDesk: 'bg-[#F472B6] border-[#DB2777] text-white',
    dialogueBg: 'bg-[#FFF5F7]',
    dialogueBorder: 'border-[#F472B6]',
    dialogueArrow: '#FFF5F7',
    kitchenBg: 'bg-[#FFF0F5] border-[#FBCFE8]',
    kitchenBorder: 'border-[#FBCFE8]',
    topBarBg: 'bg-[#FFF5F8]',
    topBarBorder: 'border-[#FCE7F3]',
    peelBg: 'bg-[#FED7AA]',
    peelBorder: 'border-[#FB923C]',
    peelInnerRing: 'border-[#FDBA74]',
    cardboardBox: 'bg-[#FBCFE8]',
    cardboardBorder: 'border-[#F472B6]',
    accentBtnGrad: 'from-pink-500 to-rose-400 hover:from-pink-400 hover:to-rose-300',
    accentColor: '#EC4899',
  },
  trattoria: {
    id: 'trattoria',
    name: 'Trattoria Clásica Italiana',
    subtitle: 'Rojos intensos, verde albahaca y ladrillo rústico',
    icon: '🇮🇹',
    previewColor: '#B91C1C',
    bodyBg: '#1C1917',
    headerBg: '#991B1B',
    headerBorder: '#7F1D1D',
    headerText: '#FEF2F2',
    tabActive: 'bg-stone-100 text-red-950 shadow-xs font-bold',
    tabInactive: 'text-red-100 hover:text-white hover:bg-white/10',
    counterWallGrad: 'from-[#FEF2F2] to-[#E7E5E4]',
    counterDesk: 'bg-[#991B1B] border-[#7F1D1D] text-white',
    dialogueBg: 'bg-[#FFFDFB]',
    dialogueBorder: 'border-[#991B1B]',
    dialogueArrow: '#FFFDFB',
    kitchenBg: 'bg-[#F5F5F4] border-[#E7E5E4]',
    kitchenBorder: 'border-[#D6D3D1]',
    topBarBg: 'bg-[#FAFAF9]',
    topBarBorder: 'border-[#E7E5E4]',
    peelBg: 'bg-[#D6A265]',
    peelBorder: 'border-[#92400E]',
    peelInnerRing: 'border-[#B45309]',
    cardboardBox: 'bg-[#E7E5E4]',
    cardboardBorder: 'border-[#991B1B]',
    accentBtnGrad: 'from-red-700 to-emerald-700 hover:from-red-600 hover:to-emerald-600',
    accentColor: '#B91C1C',
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Cyber Slice 2099',
    subtitle: 'Pizarra oscura, neón cian, magenta y ambiente nocturno',
    icon: '⚡',
    previewColor: '#06B6D4',
    bodyBg: '#0F172A',
    headerBg: '#1E293B',
    headerBorder: '#334155',
    headerText: '#F8FAFC',
    tabActive: 'bg-cyan-500 text-slate-950 shadow-sm font-bold',
    tabInactive: 'text-cyan-200 hover:text-cyan-400 hover:bg-cyan-950/40',
    counterWallGrad: 'from-[#0F172A] to-[#1E293B]',
    counterDesk: 'bg-[#1E293B] border-[#06B6D4] text-cyan-200',
    dialogueBg: 'bg-[#0F172A]',
    dialogueBorder: 'border-[#06B6D4]',
    dialogueArrow: '#0F172A',
    kitchenBg: 'bg-[#1E293B] border-[#334155]',
    kitchenBorder: 'border-[#334155]',
    topBarBg: 'bg-[#0F172A]',
    topBarBorder: 'border-[#334155]',
    peelBg: 'bg-[#334155]',
    peelBorder: 'border-[#06B6D4]',
    peelInnerRing: 'border-[#0891B2]',
    cardboardBox: 'bg-[#1E293B]',
    cardboardBorder: 'border-[#EC4899]',
    accentBtnGrad: 'from-cyan-500 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500',
    accentColor: '#06B6D4',
  },
  minimalist: {
    id: 'minimalist',
    name: 'Bistró Nórdico Minimal',
    subtitle: 'Roble claro, blanco lino, salvia suave y líneas limpias',
    icon: '🌿',
    previewColor: '#475569',
    bodyBg: '#F8FAFC',
    headerBg: '#334155',
    headerBorder: '#1E293B',
    headerText: '#F8FAFC',
    tabActive: 'bg-white text-slate-900 shadow-xs font-bold',
    tabInactive: 'text-slate-300 hover:text-white hover:bg-white/10',
    counterWallGrad: 'from-[#F8FAFC] to-[#E2E8F0]',
    counterDesk: 'bg-[#334155] border-[#1E293B] text-slate-100',
    dialogueBg: 'bg-[#FFFFFF]',
    dialogueBorder: 'border-[#64748B]',
    dialogueArrow: '#FFFFFF',
    kitchenBg: 'bg-[#F1F5F9] border-[#E2E8F0]',
    kitchenBorder: 'border-[#CBD5E1]',
    topBarBg: 'bg-[#FFFFFF]',
    topBarBorder: 'border-[#E2E8F0]',
    peelBg: 'bg-[#E2E8F0]',
    peelBorder: 'border-[#94A3B8]',
    peelInnerRing: 'border-[#CBD5E1]',
    cardboardBox: 'bg-[#E2E8F0]',
    cardboardBorder: 'border-[#94A3B8]',
    accentBtnGrad: 'from-slate-800 to-stone-700 hover:from-slate-700 hover:to-stone-600',
    accentColor: '#475569',
  },
};
