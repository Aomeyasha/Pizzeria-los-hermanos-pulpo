export type ToppingType =
  | 'pepperoni'
  | 'mushroom'
  | 'olive'
  | 'carne_mamut'
  | 'pina'
  | 'queso_extra'
  | 'puerro_cebolla'
  | 'higos_datiles'
  | 'pato_pescado'
  | 'miel_sesamo'
  | 'queso_paneer'
  | 'pollo_tandoori'
  | 'cilantro_menta'
  | 'basil'
  | 'onion'
  | 'sausage'
  | 'bell_pepper';

export interface ToppingPlacement {
  id: string;
  type: ToppingType;
  x: number; // percentage 0-100 relative to pizza center
  y: number; // percentage 0-100 relative to pizza center
  rotation: number; // degrees 0-360
  half: 'left' | 'right' | 'whole';
}

export type DoughType = 'normal' | 'wheat' | 'naan_verde';

export type PizzaSize = 'Pequeña' | 'Mediana' | 'Familiar';
export type PizzaShape = 'Circular' | 'Cuadrado' | 'Estrella' | 'Corazón';

export interface PizzaMagnitudes {
  tamano: PizzaSize;
  forma: PizzaShape;
  precio: number;
  calificacionMasa: number;
  longitudCm: string;
  areaCm2: string;
  volumenCm3: string;
  capacidadMl: number;
  masaGramos: number;
  pesoNewtons: string;
}

export interface PizzaState {
  id: string;
  dough: DoughType;
  size: PizzaSize;
  shape: PizzaShape;
  doughCompleted: boolean;
  flourWeighed?: boolean;
  doughScore: number; // 0 to 100
  harinaEnGramera: number;
  magnitudes: PizzaMagnitudes | null;
  sauce: {
    applied: boolean;
    coverage: number; // 0 to 100
    points: { x: number; y: number }[];
    half: 'whole' | 'left' | 'right' | 'none';
  };
  cheese: {
    applied: boolean;
    coverage: number; // 0 to 100
    points: { x: number; y: number }[];
    half: 'whole' | 'left' | 'right' | 'none';
  };
  toppings: ToppingPlacement[];
  bakeLevel: number; // 0 = raw, 1 = golden baked, 2 = well-done (bien cocida), 3 = burnt
  cuts: { start: { x: number; y: number }; end: { x: number; y: number } }[];
  slicesCount: number;
  boxClosed?: boolean;
}

export interface CustomerAvatarConfig {
  skinColor: string;
  hairStyle:
    | 'afro'
    | 'short'
    | 'curly'
    | 'bun'
    | 'bald'
    | 'beanie'
    | 'chef'
    | 'caveman'
    | 'pharaoh'
    | 'mummy'
    | 'sage';
  hairColor: string;
  shirtColor: string;
  accessory?: 'glasses' | 'mustache' | 'earring' | 'apron' | 'tie' | 'bone' | 'uraeus' | 'scarab' | 'bindi';
  baseExpression: 'happy' | 'neutral' | 'curious' | 'smug';
}

export interface RecipeRequirement {
  dough?: DoughType;
  size?: PizzaSize;
  shape?: PizzaShape;
  sauce: 'whole' | 'left' | 'right' | 'none';
  cheese: 'whole' | 'left' | 'right' | 'none';
  toppings: {
    type: ToppingType;
    placement: 'whole' | 'left' | 'right';
    minCount?: number;
    recommendedCount?: number;
    exactCount?: number;
  }[];
  bakeLevel: 1 | 2; // 1 = Doradita normal, 2 = Bien cocida (dos veces)
  cuts: number; // 0, 2, 4, 6, 8 slices
}

export interface MamutToppingItem {
  id: string;
  type: ToppingType;
  nombre: string;
  cantidadReal: number;
  simbolo: string | number;
}

export interface CustomerOrder {
  id: string;
  customerName: string;
  customerType?: 'cavernicola' | 'moderno' | 'faraon' | 'momia' | 'sabio_india';
  menuOrderTitle?: string;
  medidaEgipcia?: string;
  iconoEgipcio?: string;
  sabioZeroChallenge?: {
    descartados: ToppingType[];
    requeridos: ToppingType[];
    cantidadPorCadaUno: number;
    poolToppings: ToppingType[];
  };
  avatar: CustomerAvatarConfig;
  dialogue: string;
  clarification: string;
  toppingsDetail?: MamutToppingItem[];
  recipe: RecipeRequirement;
  basePrice: number;
  patienceTotal: number; // seconds (usually 70-100s)
  tipMultiplier: number;
}

export interface EvaluationResult {
  score: number; // 0 to 100
  passed: boolean;
  basePriceEarned: number;
  tipEarned: number;
  feedbackDialogue: string;
  customerReaction: 'ecstatic' | 'happy' | 'meh' | 'angry';
  breakdown: {
    doughOk?: boolean;
    doughFeedback?: string;
    sauceOk: boolean;
    sauceFeedback?: string;
    cheeseOk: boolean;
    cheeseFeedback?: string;
    toppingsOk: boolean;
    toppingsFeedback?: string;
    bakeOk: boolean;
    bakeFeedback?: string;
    cutsOk: boolean;
    cutsFeedback?: string;
  };
}

export interface GameUpgrades {
  fastOven: boolean;
  cutterGuide: boolean;
  toppingGuide: boolean;
  autoSauceCheese: boolean;
  warmBox: boolean;
  cozyDecorLevel: number;
  naanVerdeFlour: boolean;
  unlockedToppings: ToppingType[];
}

export interface DayFinancials {
  pizzasCompleted: number;
  pizzasFailed: number;
  grossIncome: number;
  tipsIncome: number;
  ingredientsCost: number;
  rent: number;
  netProfit: number;
}

export interface RecipeBookEntry {
  id: string;
  name: string;
  description: string;
  ingredients: string[];
  cuts: number;
  bakeLevel: string;
  hint: string;
}

export interface SaveSlot {
  id: number;
  title: string;
  day: number;
  cash: number;
  upgrades: GameUpgrades;
  lastPlayed: string;
  isUsed: boolean;
}
