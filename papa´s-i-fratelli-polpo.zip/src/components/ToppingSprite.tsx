import React from 'react';
import { ToppingType } from '../types/pizza';

interface ToppingSpriteProps {
  type: ToppingType;
  x?: number;
  y?: number;
  rotation?: number;
  size?: number;
  isBaked?: boolean;
}

export const ToppingSprite: React.FC<ToppingSpriteProps> = ({
  type,
  x = 0,
  y = 0,
  rotation = 0,
  size = 32,
  isBaked = false,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) rotate(${rotation}) scale(${size / 32})`}
      className="cursor-pointer select-none"
    >
      {type === 'pepperoni' && (
        <g>
          {/* Pepperoni disc */}
          <circle
            cx="0"
            cy="0"
            r="15"
            fill={isBaked ? '#B91C1C' : '#DC2626'}
            stroke={isBaked ? '#7F1D1D' : '#991B1B'}
            strokeWidth="1.8"
          />
          {/* Fat marbled specks */}
          <circle cx="-5" cy="-4" r="1.5" fill="#FCA5A5" />
          <circle cx="6" cy="-3" r="1.8" fill="#FCA5A5" />
          <circle cx="2" cy="6" r="1.6" fill="#FCA5A5" />
          <circle cx="-6" cy="5" r="1.4" fill="#FCA5A5" />
          <circle cx="0" cy="0" r="1.2" fill="#FCA5A5" />
          {/* Crispy edge rim */}
          <circle cx="0" cy="0" r="13.5" fill="none" stroke="#7F1D1D" strokeWidth="0.8" opacity="0.6" />
        </g>
      )}

      {type === 'mushroom' && (
        <g>
          {/* Mushroom cap */}
          <path
            d="M -13 4 C -13 -10 13 -10 13 4 C 11 6 -11 6 -13 4 Z"
            fill={isBaked ? '#785E48' : '#A88D75'}
            stroke="#4A3728"
            strokeWidth="1.5"
          />
          {/* Mushroom stem */}
          <path
            d="M -4 4 L -5 13 C -5 15 5 15 5 13 L 4 4 Z"
            fill={isBaked ? '#D1BFA9' : '#F5EBE1'}
            stroke="#4A3728"
            strokeWidth="1.5"
          />
          {/* Cap gills shade */}
          <path d="M -10 4 C -5 1 5 1 10 4" fill="none" stroke="#4A3728" strokeWidth="1" />
        </g>
      )}

      {type === 'olive' && (
        <g>
          {/* Olive ring */}
          <circle
            cx="0"
            cy="0"
            r="12"
            fill={isBaked ? '#111827' : '#1F2937'}
            stroke="#030712"
            strokeWidth="1.5"
          />
          {/* Hole */}
          <circle cx="0" cy="0" r="5" fill="#B45309" opacity="0.4" />
          <circle cx="0" cy="0" r="4.5" fill="#78350F" opacity="0.8" />
          {/* Olive shine reflection */}
          <path
            d="M -7 -6 C -3 -9 3 -9 7 -6"
            fill="none"
            stroke="#9CA3AF"
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.8"
          />
        </g>
      )}

      {type === 'basil' && (
        <g>
          {/* Basil leaf */}
          <path
            d="M 0 -15 C 14 -10 16 12 0 16 C -16 12 -14 -10 0 -15 Z"
            fill={isBaked ? '#15803D' : '#22C55E'}
            stroke={isBaked ? '#14532D' : '#166534'}
            strokeWidth="1.5"
          />
          {/* Leaf vein */}
          <path
            d="M 0 -12 L 0 14"
            fill="none"
            stroke={isBaked ? '#166534' : '#86EFAC'}
            strokeWidth="1.2"
            strokeLinecap="round"
          />
          <path d="M 0 -4 Q 5 -8 8 -6" fill="none" stroke={isBaked ? '#166534' : '#86EFAC'} strokeWidth="0.9" />
          <path d="M 0 3 Q -5 0 -8 2" fill="none" stroke={isBaked ? '#166534' : '#86EFAC'} strokeWidth="0.9" />
        </g>
      )}

      {type === 'onion' && (
        <g>
          {/* Onion crescent rings */}
          <path
            d="M -12 -6 C -4 -16 12 -12 14 0 C 10 -8 -2 -11 -9 -3 Z"
            fill="#F3E8FF"
            stroke="#9333EA"
            strokeWidth="1.6"
          />
          <path
            d="M -10 4 C -1 15 13 10 13 -2 C 9 6 0 9 -7 2 Z"
            fill="#FAF5FF"
            stroke="#A855F7"
            strokeWidth="1.4"
          />
        </g>
      )}

      {type === 'sausage' && (
        <g>
          {/* Savory Italian sausage chunks */}
          <ellipse
            cx="0"
            cy="0"
            rx="11"
            ry="9"
            fill={isBaked ? '#78350F' : '#92400E'}
            stroke="#451A03"
            strokeWidth="1.8"
          />
          <circle cx="-3" cy="-2" r="1.5" fill="#B45309" />
          <circle cx="3" cy="2" r="1.3" fill="#B45309" />
          <circle cx="4" cy="-3" r="1.2" fill="#D97706" />
          <circle cx="-4" cy="3" r="1.2" fill="#D97706" />
        </g>
      )}

      {type === 'bell_pepper' && (
        <g>
          {/* Crunchy green bell pepper arc */}
          <path
            d="M -12 -8 C -4 -16 8 -14 13 -6 C 16 0 14 8 8 13 C 5 9 10 3 8 -3 C 5 -9 -5 -11 -9 -4 Z"
            fill={isBaked ? '#15803D' : '#16A34A'}
            stroke="#14532D"
            strokeWidth="1.6"
          />
          <circle cx="0" cy="-6" r="1.2" fill="#BBF7D0" />
        </g>
      )}

      {type === 'carne_mamut' && (
        <g>
          {/* Prehistoric Mammoth Steak Chunk */}
          <path
            d="M -14 -4 C -15 -13 6 -15 13 -7 C 16 1 12 13 0 13 C -10 13 -13 6 -14 -4 Z"
            fill={isBaked ? '#5C2214' : '#7C2D12'}
            stroke="#3B1208"
            strokeWidth="1.8"
          />
          {/* Inner seared meat grain */}
          <ellipse
            cx="-1"
            cy="0"
            rx="8.5"
            ry="6.5"
            fill={isBaked ? '#7F1D1D' : '#991B1B'}
          />
          {/* Marbling / Grill sear lines */}
          <path
            d="M -6 -3 L 5 3 M -4 4 L 6 -2"
            stroke="#FCA5A5"
            strokeWidth="1.3"
            strokeLinecap="round"
            opacity="0.7"
          />
          {/* Little prehistoric marrow bone eye */}
          <circle cx="5" cy="-4" r="3.4" fill="#FEF3C7" stroke="#D97706" strokeWidth="1" />
          <circle cx="5" cy="-4" r="1.3" fill="#B45309" />
        </g>
      )}

      {type === 'pina' && (
        <g>
          {/* Golden Pineapple Wedge Tidbit */}
          <path
            d="M -12 8 L -5 -11 C 0 -13 6 -12 11 -9 L 13 7 C 5 12 -4 12 -12 8 Z"
            fill={isBaked ? '#CA8A04' : '#FACC15'}
            stroke="#854D0E"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          {/* Juicy inner golden highlights */}
          <path
            d="M -6 5 L -1 -7 L 7 -5 L 8 4 Z"
            fill="#FEF08A"
            opacity="0.75"
          />
          {/* Caramelized grill spots when baked */}
          {isBaked && (
            <g fill="#78350F" opacity="0.65">
              <circle cx="-3" cy="2" r="1.3" />
              <circle cx="4" cy="-2" r="1.5" />
            </g>
          )}
        </g>
      )}

      {type === 'queso_extra' && (
        <g>
          {/* Creamy Extra Cheese Dollop / Medallion */}
          <path
            d="M -12 -3 C -13 -12 -1 -15 7 -11 C 15 -7 14 7 6 12 C -4 15 -14 8 -12 -3 Z"
            fill={isBaked ? '#FDE047' : '#FEF9C3'}
            stroke="#CA8A04"
            strokeWidth="1.6"
          />
          {/* Creamy inner bulge */}
          <ellipse cx="-2" cy="-2" rx="6.5" ry="5" fill="#FFFFFF" opacity="0.65" />
          {/* Golden toasted bubbles if baked */}
          {isBaked && (
            <g fill="#D97706" opacity="0.75">
              <circle cx="3" cy="3" r="1.8" />
              <circle cx="-4" cy="4" r="1.3" />
            </g>
          )}
        </g>
      )}

      {type === 'puerro_cebolla' && (
        <g>
          {/* Caramelized Purple Onion Crescent */}
          <path
            d="M -13 -3 C -6 -15 9 -13 13 -1 C 8 -8 -3 -10 -10 -1 Z"
            fill={isBaked ? '#6B21A8' : '#9333EA'}
            stroke="#4C1D95"
            strokeWidth="1.4"
          />
          <path
            d="M -10 -1 C -4 -9 6 -8 10 1 C 6 -4 -2 -6 -8 1 Z"
            fill="#E9D5FF"
            opacity="0.8"
          />
          {/* Caramelized Leek Ring */}
          <circle
            cx="2"
            cy="5"
            r="8"
            fill={isBaked ? '#A3E635' : '#D9F99D'}
            stroke="#4D7C0F"
            strokeWidth="1.5"
          />
          <circle
            cx="2"
            cy="5"
            r="4.5"
            fill="#FEF9C3"
            stroke="#84CC16"
            strokeWidth="1"
          />
          {/* Caramelized amber sear highlights */}
          <path
            d="M -8 -6 Q -2 -11 5 -8 M -3 9 Q 3 12 8 8"
            fill="none"
            stroke="#B45309"
            strokeWidth="1.3"
            strokeLinecap="round"
            opacity="0.75"
          />
        </g>
      )}

      {type === 'higos_datiles' && (
        <g>
          {/* Fresh Fig Wedge */}
          <path
            d="M -13 7 C -14 -4 -6 -13 2 -12 C 7 -11 8 -3 5 6 C 0 11 -8 11 -13 7 Z"
            fill={isBaked ? '#4C1D95' : '#6B21A8'}
            stroke="#3B0764"
            strokeWidth="1.5"
          />
          {/* Fig ruby seeded interior */}
          <path
            d="M -10 5 C -10 -3 -4 -9 1 -9 C 4 -8 5 -2 2 4 C -1 8 -6 8 -10 5 Z"
            fill={isBaked ? '#9F1239' : '#E11D48'}
            stroke="#FDE68A"
            strokeWidth="1"
          />
          {/* Tiny fig seeds */}
          <g fill="#FEF08A">
            <circle cx="-5" cy="0" r="0.9" />
            <circle cx="-2" cy="-3" r="0.9" />
            <circle cx="-1" cy="2" r="0.9" />
            <circle cx="-6" cy="3" r="0.8" />
          </g>
          {/* Glossy Date Half */}
          <ellipse
            cx="8"
            cy="3"
            rx="6"
            ry="9"
            transform="rotate(20 8 3)"
            fill={isBaked ? '#5C2208' : '#78350F'}
            stroke="#451A03"
            strokeWidth="1.4"
          />
          <ellipse
            cx="7.5"
            cy="2.5"
            rx="3"
            ry="5.5"
            transform="rotate(20 7.5 2.5)"
            fill="#B45309"
            opacity="0.75"
          />
          <ellipse cx="6" cy="-1" rx="1.2" ry="2.2" transform="rotate(20 6 -1)" fill="#FDE68A" opacity="0.5" />
        </g>
      )}

      {type === 'pato_pescado' && (
        <g>
          {/* Smoked Nile Fish / Roasted Duck Strip 1 */}
          <path
            d="M -13 -8 C -4 -12 7 -8 13 -3 C 11 2 2 0 -9 -2 C -12 -3 -14 -6 -13 -8 Z"
            fill={isBaked ? '#7C2D12' : '#9A3412'}
            stroke="#431407"
            strokeWidth="1.4"
          />
          <path
            d="M -9 -6 C -2 -8 5 -6 9 -3"
            fill="none"
            stroke="#FDBA74"
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.8"
          />
          {/* Roasted Strip 2 */}
          <path
            d="M -11 4 C -3 0 8 2 13 8 C 9 13 -2 11 -10 9 C -13 8 -13 5 -11 4 Z"
            fill={isBaked ? '#92400E' : '#C2410C'}
            stroke="#431407"
            strokeWidth="1.4"
          />
          {/* Savory glaze & flaky smoke striations */}
          <path
            d="M -7 6 L -4 8 M -1 5 L 2 8 M 5 6 L 8 9"
            stroke="#FED7AA"
            strokeWidth="1.1"
            strokeLinecap="round"
            opacity="0.75"
          />
        </g>
      )}

      {type === 'miel_sesamo' && (
        <g>
          {/* Pure Golden Honey Drizzle Ribbon */}
          <path
            d="M -13 -5 C -8 -13 2 -11 0 -2 C -2 7 9 10 13 2"
            fill="none"
            stroke={isBaked ? '#D97706' : '#F59E0B'}
            strokeWidth="4.2"
            strokeLinecap="round"
          />
          <path
            d="M -13 -5 C -8 -13 2 -11 0 -2 C -2 7 9 10 13 2"
            fill="none"
            stroke="#FEF08A"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.85"
          />
          {/* Secondary honey droplet */}
          <circle cx="-7" cy="7" r="3" fill="#F59E0B" stroke="#B45309" strokeWidth="0.9" />
          <circle cx="-8" cy="6" r="1" fill="#FEF9C3" />
          {/* Toasted Sesame Seeds */}
          <g>
            <ellipse cx="7" cy="-8" rx="2.3" ry="1.2" transform="rotate(-25 7 -8)" fill="#FEF3C7" stroke="#92400E" strokeWidth="0.8" />
            <ellipse cx="-2" cy="9" rx="2.3" ry="1.2" transform="rotate(18 -2 9)" fill="#FDE68A" stroke="#92400E" strokeWidth="0.8" />
            <ellipse cx="9" cy="10" rx="2.1" ry="1.1" transform="rotate(-40 9 10)" fill="#FEF3C7" stroke="#92400E" strokeWidth="0.8" />
            <ellipse cx="-10" cy="-1" rx="2.1" ry="1.1" transform="rotate(35 -10 -1)" fill="#FDE68A" stroke="#92400E" strokeWidth="0.8" />
          </g>
        </g>
      )}

      {type === 'queso_paneer' && (
        <g>
          {/* Artisan Creamy Paneer Cheese Cube 1 */}
          <path
            d="M -11 -7 L 3 -12 L 12 -5 L 12 8 L -2 12 L -11 5 Z"
            fill={isBaked ? '#FEF3C7' : '#FFFDF5'}
            stroke={isBaked ? '#B45309' : '#D97706'}
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
          {/* Top face highlight */}
          <path
            d="M -11 -7 L 3 -12 L 12 -5 L -2 0 Z"
            fill={isBaked ? '#FEF9C3' : '#FFFFFF'}
            opacity="0.9"
          />
          {/* Right shaded facet */}
          <path
            d="M -2 0 L 12 -5 L 12 8 L -2 12 Z"
            fill={isBaked ? '#FDE68A' : '#FEF3C7'}
            opacity="0.7"
          />
          {/* Golden seared grill marks when baked */}
          <path
            d={isBaked ? 'M -7 -6 L 4 -9 M 1 -4 L 9 -6' : 'M -5 -5 L 2 -8'}
            stroke={isBaked ? '#B45309' : '#EAB308'}
            strokeWidth={isBaked ? '1.8' : '1.1'}
            strokeLinecap="round"
            opacity={isBaked ? '0.85' : '0.45'}
          />
        </g>
      )}

      {type === 'pollo_tandoori' && (
        <g>
          {/* Tandoori Marinated Charred Chicken Chunk */}
          <path
            d="M -13 -3 C -13 -12 3 -13 10 -6 C 14 0 9 9 -2 9 C -10 9 -13 3 -13 -3 Z"
            fill={isBaked ? '#B91C1C' : '#DC2626'}
            stroke="#7F1D1D"
            strokeWidth="1.5"
          />
          {/* Spicy Paprika & Yogurt Glaze Highlight */}
          <path
            d="M -9 -5 C -3 -9 5 -7 7 -2"
            fill="none"
            stroke="#FB923C"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0.85"
          />
          {/* Tandoor Grill Char Stripes */}
          <path
            d="M -7 -1 L 2 -4 M -5 4 L 4 1"
            stroke="#450A0A"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.75"
          />
          {/* Spiced Golden Roasted Chickpea Side Accent */}
          <circle
            cx="8"
            cy="7"
            r="5.2"
            fill={isBaked ? '#D97706' : '#F59E0B'}
            stroke="#78350F"
            strokeWidth="1.3"
          />
          <circle cx="6.8" cy="5.5" r="1.4" fill="#FEF08A" opacity="0.8" />
          <circle cx="9.2" cy="8.2" r="0.9" fill="#9A3412" opacity="0.75" />
        </g>
      )}

      {type === 'cilantro_menta' && (
        <g>
          {/* Scalloped Fresh Cilantro Leaf */}
          <path
            d="M -12 4 C -15 -3 -9 -10 -3 -8 C -1 -14 7 -13 7 -6 C 12 -4 9 4 3 4 L -2 12 L -5 11 L -3 4 C -7 7 -11 7 -12 4 Z"
            fill={isBaked ? '#15803D' : '#22C55E'}
            stroke="#14532D"
            strokeWidth="1.3"
            strokeLinejoin="round"
          />
          {/* Cool Emerald Serrated Mint Leaf */}
          <path
            d="M 1 0 C 5 -9 14 -9 14 0 C 14 7 6 12 -1 11 C -2 7 0 3 1 0 Z"
            fill={isBaked ? '#047857' : '#10B981'}
            stroke="#064E3B"
            strokeWidth="1.3"
            strokeLinejoin="round"
          />
          {/* Crisp Aromatic Herb Veins */}
          <path
            d="M -3 -5 L -2 3 M 3 8 L 9 -3"
            fill="none"
            stroke="#BBF7D0"
            strokeWidth="1.1"
            strokeLinecap="round"
            opacity="0.85"
          />
        </g>
      )}
    </g>
  );
};
