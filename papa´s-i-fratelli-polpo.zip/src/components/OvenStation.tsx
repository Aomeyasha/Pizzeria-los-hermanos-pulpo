import React, { useState, useEffect } from 'react';
import { GameUpgrades, PizzaState } from '../types/pizza';
import { sounds } from '../services/soundEffects';
import { ToppingSprite } from './ToppingSprite';
import { PizzaBaseLayers } from './PizzaShapeSVG';
import { CATALOGO_TAMANOS } from '../utils/pizzaGeometry';
import { ArrowLeft, ArrowRight, Flame, RotateCcw } from 'lucide-react';

interface OvenStationProps {
  pizza: PizzaState;
  upgrades: GameUpgrades;
  onUpdatePizza: (updater: (prev: PizzaState) => PizzaState) => void;
  onMoveToCut: () => void;
  onBackToKitchen: () => void;
}

export const OvenStation: React.FC<OvenStationProps> = ({
  pizza,
  upgrades,
  onUpdatePizza,
  onMoveToCut,
  onBackToKitchen,
}) => {
  const [isBaking, setIsBaking] = useState(false);
  const [bakingProgress, setBakingProgress] = useState(0); // 0 to 100

  // Total baking duration in ms: 6000ms normal, 3200ms with fastOven upgrade
  const bakeDuration = upgrades.fastOven ? 3200 : 5500;

  useEffect(() => {
    let timer: any = null;
    if (isBaking) {
      sounds.playOvenSizzle();
      const intervalTime = 50;
      const step = 100 / (bakeDuration / intervalTime);

      timer = setInterval(() => {
        setBakingProgress((prev) => {
          if (prev >= 100) {
            clearInterval(timer);
            setIsBaking(false);
            // Increment bake level
            onUpdatePizza((p) => ({
              ...p,
              bakeLevel: Math.min(3, p.bakeLevel + 1),
            }));
            return 100;
          }
          return prev + step;
        });
      }, intervalTime);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isBaking, bakeDuration, onUpdatePizza]);

  const startBake = () => {
    if (isBaking) return;
    setBakingProgress(0);
    setIsBaking(true);
  };

  const getBakeTitle = (level: number) => {
    switch (level) {
      case 0:
        return 'Masa Cruda (Sin Hornear)';
      case 1:
        return 'Doradita Normal (1 Pasada)';
      case 2:
        return 'Bien Cocida / Crujiente (2 Pasadas)';
      case 3:
        return '¡Quemada / Carbonizada!';
      default:
        return 'Horneada';
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#2A2321] text-amber-50 select-none">
      {/* Top Controls */}
      <div className="flex items-center justify-between px-5 py-3 bg-[#1F1918] border-b border-[#3D322F]">
        <button
          onClick={onBackToKitchen}
          disabled={isBaking}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-300 hover:text-white bg-[#352B28] hover:bg-[#433733] rounded-lg transition-colors disabled:opacity-50"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver a Cocina
        </button>

        <div className="flex items-center gap-2">
          <Flame className={`w-4 h-4 ${isBaking ? 'text-orange-500 animate-pulse' : 'text-stone-400'}`} />
          <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
            {getBakeTitle(pizza.bakeLevel)}
          </span>
        </div>

        <button
          onClick={onMoveToCut}
          disabled={isBaking || pizza.bakeLevel === 0}
          className="flex items-center gap-2 px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-700 disabled:text-stone-400 rounded-lg shadow-sm transition-all"
        >
          Llevar a Cortar
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Main Conveyor Belt Arena */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 overflow-hidden relative">
        {/* Conveyor Machine Housing */}
        <div className="relative w-full max-w-3xl h-72 sm:h-80 bg-[#3F3330] rounded-2xl border-4 border-[#594844] shadow-2xl flex items-center justify-between px-6 overflow-hidden">
          {/* Metal Grate / Conveyor Belt Tracks */}
          <div className="absolute inset-x-0 bottom-8 h-12 bg-[#231C1A] border-y-2 border-[#151110] flex items-center overflow-hidden">
            <div className={`w-full flex gap-3 ${isBaking ? 'animate-pulse' : ''}`}>
              {Array.from({ length: 32 }).map((_, i) => (
                <div key={i} className="w-3 h-10 bg-[#403431] rounded-xs shrink-0 shadow-xs" />
              ))}
            </div>
          </div>

          {/* Central Brick Oven Chamber (The Fiery Tunnel) */}
          <div className="absolute left-1/2 top-4 -translate-x-1/2 w-72 sm:w-80 h-[88%] bg-[#5C2318] rounded-xl border-4 border-[#7A2F20] shadow-inner flex flex-col items-center justify-between p-3 z-0">
            {/* Brick pattern header */}
            <div className="text-[11px] font-bold uppercase tracking-widest text-amber-200/90 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              Túnel Térmico 350°C
            </div>

            {/* Glowing Fire Interior */}
            <div className="w-full flex-1 rounded-lg bg-gradient-to-t from-orange-600/70 via-amber-500/40 to-transparent flex items-end justify-center pb-2">
              <div className="flex gap-2">
                <div className={`w-3 h-3 rounded-full bg-yellow-300 ${isBaking ? 'animate-ping' : ''}`} />
                <div className={`w-4 h-4 rounded-full bg-orange-400 ${isBaking ? 'animate-bounce' : ''}`} />
                <div className={`w-2 h-2 rounded-full bg-amber-200 ${isBaking ? 'animate-ping' : ''}`} />
              </div>
            </div>

            {/* Heat glow animation indicator */}
            {isBaking && (
              <div className="absolute inset-0 bg-orange-500/20 pointer-events-none animate-pulse rounded-xl" />
            )}
          </div>

          {/* Pizza on Conveyor (translates horizontally during baking) */}
          <div
            className="relative z-10 w-44 h-44 sm:w-52 sm:h-52 shrink-0 transition-transform duration-75"
            style={{
              transform: isBaking
                ? `translateX(${(bakingProgress / 100) * 400 - 80}px)`
                : pizza.bakeLevel > 0
                ? 'translateX(340px)'
                : 'translateX(20px)',
            }}
          >
            {/* Visual SVG Pizza */}
            <svg
              viewBox="0 0 100 100"
              style={{ transform: `scale(${CATALOGO_TAMANOS[pizza.size]?.escalaVisual || 0.9})` }}
              className="w-full h-full drop-shadow-2xl transition-transform duration-300"
            >
              <PizzaBaseLayers
                shape={pizza.shape}
                bakeLevel={pizza.bakeLevel}
                clipIdPrefix="oven"
                doughType={pizza.dough}
                sauceApplied={pizza.sauce.applied}
                sauceCoverage={pizza.sauce.coverage}
                cheeseApplied={pizza.cheese.applied}
                cheeseCoverage={pizza.cheese.coverage}
                showCheeseFreckles={true}
                hasHoneySesameFinish={pizza.toppings.some((t) => t.type === 'miel_sesamo')}
              />

              {/* Toppings rendered */}
              {pizza.toppings.map((top) => (
                <ToppingSprite
                  key={top.id}
                  type={top.type}
                  x={top.x}
                  y={top.y}
                  rotation={top.rotation}
                  size={22}
                  isBaked={pizza.bakeLevel >= 1}
                />
              ))}
            </svg>

            {/* Steam rising if fresh out of oven */}
            {pizza.bakeLevel > 0 && !isBaking && (
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 flex gap-2 pointer-events-none">
                <span className="text-xl animate-steam opacity-60">♨️</span>
                <span className="text-lg animate-steam opacity-50 delay-100">♨️</span>
              </div>
            )}
          </div>
        </div>

        {/* Oven Controls Bottom Dock */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
          {pizza.bakeLevel === 0 ? (
            <button
              onClick={startBake}
              disabled={isBaking}
              className="flex items-center gap-2 px-6 py-3 text-sm font-bold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 rounded-xl shadow-lg transition-transform active:scale-95 disabled:opacity-50"
            >
              <Flame className="w-5 h-5 fill-white" />
              {isBaking ? 'Horneando...' : 'Pasar por el Horno (Hornear)'}
            </button>
          ) : pizza.bakeLevel === 1 ? (
            <div className="flex items-center gap-3">
              <button
                onClick={startBake}
                disabled={isBaking}
                className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-amber-200 bg-[#42312D] hover:bg-[#523E3A] border border-amber-600/40 rounded-xl transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                Pasar Otra Vez (Bien Cocida)
              </button>
              <button
                onClick={onMoveToCut}
                className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-transform active:scale-95"
              >
                ¡Lista! Ir a Cortar
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={onMoveToCut}
                className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-transform active:scale-95"
              >
                ¡Bien cocida y crujiente! Ir a Cortar
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Progress bar when baking */}
        {isBaking && (
          <div className="w-64 max-w-full mt-4 bg-stone-800 rounded-full h-2.5 overflow-hidden border border-stone-700">
            <div
              className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2.5 rounded-full transition-all duration-75"
              style={{ width: `${bakingProgress}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
