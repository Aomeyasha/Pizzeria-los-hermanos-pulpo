import React, { useEffect } from 'react';
import { CustomerAvatarConfig, EvaluationResult } from '../types/pizza';
import { CustomerAvatar } from './CustomerAvatar';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import { sounds } from '../services/soundEffects';
import { ArrowRight, CheckCircle2, XCircle, Star } from 'lucide-react';

interface CustomerReactionModalProps {
  evaluation: EvaluationResult;
  customerName: string;
  avatar: CustomerAvatarConfig;
  onNextCustomer: () => void;
}

export const CustomerReactionModal: React.FC<CustomerReactionModalProps> = ({
  evaluation,
  customerName,
  avatar,
  onNextCustomer,
}) => {
  useEffect(() => {
    sounds.playReaction(evaluation.customerReaction);
    if (evaluation.basePriceEarned > 0) {
      setTimeout(() => sounds.playChaChing(), 250);
    }
  }, [evaluation]);

  const totalEarned = evaluation.basePriceEarned + evaluation.tipEarned;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/65 backdrop-blur-xs select-none animate-in fade-in">
      <WoodParchmentBoard
        variant="vertical"
        className="w-full max-w-lg"
        innerClassName="max-h-[84vh] overflow-y-auto"
      >
        {/* Customer Header */}
        <div className="flex items-center gap-4 border-b-2 border-[#C8A16B]/60 pb-4">
          <CustomerAvatar
            config={avatar}
            emotion={evaluation.customerReaction}
            size={100}
          />
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xl font-display font-bold text-[#3A1E0D]">
                {customerName}
              </h3>
              <div className="flex items-center gap-1 px-3 py-1 bg-[#EFE0BA] border border-[#C69B61] text-[#5D290D] rounded-full text-xs font-bold font-mono">
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
                {evaluation.score}%
              </div>
            </div>
            {/* Speech bubble */}
            <div className="relative mt-2 p-3 bg-[#FFFBF0]/85 rounded-xl border border-[#D4AE74] text-xs sm:text-sm font-medium italic text-[#3A1E0D] shadow-2xs">
              "{evaluation.feedbackDialogue}"
            </div>
          </div>
        </div>

        {/* Financial Earnings Strip */}
        <div className="my-4 grid grid-cols-3 gap-2 bg-[#EFE0BA]/85 p-3 rounded-xl border border-[#C69B61] text-center">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#6E4427]">Precio Pizza</div>
            <div className="text-sm sm:text-base font-bold font-mono text-[#3A1E0D]">
              ${evaluation.basePriceEarned.toFixed(2)}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase font-bold text-[#6E4427]">Propina</div>
            <div className="text-sm sm:text-base font-bold font-mono text-emerald-700">
              +${evaluation.tipEarned.toFixed(2)}
            </div>
          </div>
          <div className="bg-[#FFFDF6]/90 rounded-lg p-1 border border-[#D4AE74] shadow-2xs">
            <div className="text-[10px] uppercase font-bold text-[#5D290D]">Total Ganado</div>
            <div className="text-base sm:text-lg font-bold font-mono text-emerald-800">
              ${totalEarned.toFixed(2)}
            </div>
          </div>
        </div>

        {/* Quality Checklist */}
        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between py-1 border-b border-[#D4AE74]/60">
            <span className="text-[#5D290D] font-semibold">Masa, Tamaño y Molde</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.doughOk !== false ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {evaluation.breakdown.doughFeedback || 'Perfecta'}
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.doughFeedback || 'Falta masa'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-[#D4AE74]/60">
            <span className="text-[#5D290D] font-semibold">Salsa de tomate</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.sauceOk ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Correcta
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.sauceFeedback || 'Falla'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-[#D4AE74]/60">
            <span className="text-[#5D290D] font-semibold">Queso Mozzarella</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.cheeseOk ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Correcto
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.cheeseFeedback || 'Falla'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-[#D4AE74]/60">
            <span className="text-[#5D290D] font-semibold">Ingredientes (Toppings)</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.toppingsOk ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Bien distribuidos
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.toppingsFeedback || 'Diferencias'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-[#D4AE74]/60">
            <span className="text-[#5D290D] font-semibold">Nivel de Horneado</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.bakeOk ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Perfecto
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.bakeFeedback || 'Revisar tiempo'}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between py-1">
            <span className="text-[#5D290D] font-semibold">Corte de Porciones</span>
            <div className="flex items-center gap-1 font-medium">
              {evaluation.breakdown.cutsOk ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Cantidad exacta
                </span>
              ) : (
                <span className="text-rose-700 flex items-center gap-1">
                  <XCircle className="w-3.5 h-3.5" /> {evaluation.breakdown.cutsFeedback || 'Cortes incorrectos'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Next Customer Button */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={onNextCustomer}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            Siguiente Cliente
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </WoodParchmentBoard>
    </div>
  );
};
