import React, { useState } from 'react';
import { SaveSlot } from '../types/pizza';
import { Play, RotateCcw, Plus, Check, Trash2, Calendar, DollarSign, Sparkles, ChefHat } from 'lucide-react';
import { sounds } from '../services/soundEffects';

interface SaveSlotsSelectorProps {
  slots: SaveSlot[];
  activeSlotId: number;
  onSelectSlot: (slotId: number) => void;
  onPlaySlot: (slotId: number) => void;
  onResetSlot: (slotId: number) => void;
}

export const SaveSlotsSelector: React.FC<SaveSlotsSelectorProps> = ({
  slots,
  activeSlotId,
  onSelectSlot,
  onPlaySlot,
  onResetSlot,
}) => {
  const [confirmResetId, setConfirmResetId] = useState<number | null>(null);

  const handlePlayClick = (id: number) => {
    sounds.playChaChing();
    onPlaySlot(id);
  };

  const handleResetClick = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (confirmResetId === id) {
      sounds.playDoughSlap();
      onResetSlot(id);
      setConfirmResetId(null);
    } else {
      setConfirmResetId(id);
    }
  };

  const cancelReset = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmResetId(null);
  };

  return (
    <div className="w-full flex flex-col gap-2.5">
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
          <ChefHat className="w-3.5 h-3.5 text-amber-700" />
          Partidas Guardadas (3 Ranuras)
        </span>
        <span className="text-[11px] font-semibold text-stone-500">
          Elige una para jugar
        </span>
      </div>

      <div className="grid grid-cols-1 gap-2">
        {slots.map((slot) => {
          const isActive = slot.id === activeSlotId;
          const isConfirming = confirmResetId === slot.id;

          return (
            <div
              key={slot.id}
              onClick={() => {
                if (confirmResetId !== null) setConfirmResetId(null);
                onSelectSlot(slot.id);
              }}
              className={`relative rounded-2xl p-3 border-2 transition-all cursor-pointer select-none ${
                isActive
                  ? 'bg-[#FFFDF5] border-[#B8652B] shadow-md ring-2 ring-amber-400/50'
                  : 'bg-[#FFFBF0]/80 hover:bg-[#FFFDF5] border-[#D4AE74] shadow-2xs hover:border-[#B8652B]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                {/* Left: Slot number & info */}
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-display font-extrabold text-sm shrink-0 shadow-2xs ${
                      isActive
                        ? 'bg-gradient-to-tr from-amber-600 to-red-600 text-white'
                        : slot.isUsed
                        ? 'bg-stone-200 text-stone-700'
                        : 'bg-stone-100 text-stone-400 border border-dashed border-stone-300'
                    }`}
                  >
                    {slot.id}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-display font-bold text-sm text-stone-900 truncate">
                        {slot.title}
                      </h3>
                      {isActive && (
                        <span className="px-1.5 py-0.5 bg-amber-200/80 text-amber-900 text-[10px] font-bold rounded-md uppercase tracking-wider">
                          Actual
                        </span>
                      )}
                    </div>

                    {slot.isUsed ? (
                      <div className="flex items-center gap-2.5 mt-0.5 text-xs text-stone-600">
                        <span className="font-bold text-amber-800">
                          Día {slot.day}
                        </span>
                        <span className="text-stone-300">·</span>
                        <span className="font-mono font-bold text-emerald-700">
                          ${slot.cash.toFixed(2)}
                        </span>
                        <span className="text-stone-300 hidden sm:inline">·</span>
                        <span className="text-[11px] text-stone-500 hidden sm:inline truncate">
                          {slot.lastPlayed}
                        </span>
                      </div>
                    ) : (
                      <p className="text-xs text-stone-400 italic">
                        Ranura Vacía · Iniciar desde el Día 1
                      </p>
                    )}
                  </div>
                </div>

                {/* Right: Action Buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {isConfirming ? (
                    <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-xl border border-rose-200">
                      <button
                        onClick={(e) => handleResetClick(e, slot.id)}
                        className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded-lg shadow-2xs"
                        title="Confirmar reinicio"
                      >
                        ¿Borrar?
                      </button>
                      <button
                        onClick={cancelReset}
                        className="px-2 py-1 bg-stone-200 hover:bg-stone-300 text-stone-700 text-[11px] font-bold rounded-lg"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <>
                      {slot.isUsed && (
                        <button
                          onClick={(e) => handleResetClick(e, slot.id)}
                          className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Reiniciar esta partida al Día 1"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePlayClick(slot.id);
                        }}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition-transform active:scale-95 shadow-xs ${
                          isActive
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-700/20'
                            : 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-700/20'
                        }`}
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        {slot.isUsed ? 'Jugar' : 'Crear'}
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
