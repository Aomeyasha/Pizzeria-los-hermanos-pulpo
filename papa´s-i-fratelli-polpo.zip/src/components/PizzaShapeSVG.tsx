import React from 'react';
import { DoughType, PizzaShape } from '../types/pizza';
import { HEART_PATH_100, STAR_POINTS_100 } from '../utils/pizzaGeometry';

interface ShapeGeometryProps {
  shape: PizzaShape;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  opacity?: number;
  transform?: string;
}

export const ShapePrimitive: React.FC<ShapeGeometryProps> = ({
  shape,
  fill = 'none',
  stroke = 'none',
  strokeWidth = 0,
  opacity = 1,
  transform,
}) => {
  switch (shape) {
    case 'Cuadrado':
      return (
        <rect
          x="10"
          y="10"
          width="80"
          height="80"
          rx="8"
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          opacity={opacity}
          transform={transform}
        />
      );
    case 'Estrella':
      return (
        <polygon
          points={STAR_POINTS_100}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          strokeLinejoin="round"
          opacity={opacity}
          transform={transform}
        />
      );
    case 'Corazón':
      return (
        <path
          d={HEART_PATH_100}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          strokeLinejoin="round"
          opacity={opacity}
          transform={transform}
        />
      );
    case 'Circular':
    default:
      return (
        <circle
          cx="50"
          cy="50"
          r="44"
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          opacity={opacity}
          transform={transform}
        />
      );
  }
};

interface PizzaCrustLayersProps {
  shape: PizzaShape;
  bakeLevel: number;
  clipIdPrefix: string;
  doughType?: DoughType;
  crustFill?: string;
  sauceApplied?: boolean;
  sauceCoverage?: number;
  saucePoints?: { x: number; y: number }[];
  cheeseApplied?: boolean;
  cheeseCoverage?: number;
  cheesePoints?: { x: number; y: number }[];
  sauceFill?: string;
  cheeseFill?: string;
  showCheeseFreckles?: boolean;
  hasHoneySesameFinish?: boolean;
}

const SESAME_RIM_SEEDS = [
  { x: 50, y: 8.5, r: 12 },
  { x: 68, y: 12, r: 35 },
  { x: 82, y: 24, r: 55 },
  { x: 90, y: 41, r: 80 },
  { x: 90, y: 59, r: 105 },
  { x: 82, y: 76, r: 130 },
  { x: 67, y: 88, r: 155 },
  { x: 50, y: 91.5, r: 175 },
  { x: 33, y: 88, r: 25 },
  { x: 18, y: 76, r: 50 },
  { x: 10, y: 59, r: 75 },
  { x: 10, y: 41, r: 100 },
  { x: 18, y: 24, r: 125 },
  { x: 32, y: 12, r: 150 },
];

const NAAN_BLISTER_BUBBLES = [
  { cx: 50, cy: 10, r: 2.3 },
  { cx: 74, cy: 18, r: 2.6 },
  { cx: 88, cy: 40, r: 2.2 },
  { cx: 86, cy: 66, r: 2.7 },
  { cx: 68, cy: 86, r: 2.1 },
  { cx: 36, cy: 88, r: 2.5 },
  { cx: 14, cy: 68, r: 2.3 },
  { cx: 12, cy: 38, r: 2.6 },
  { cx: 28, cy: 16, r: 2.1 },
  { cx: 38, cy: 26, r: 1.9 },
  { cx: 65, cy: 34, r: 1.8 },
  { cx: 32, cy: 66, r: 2.0 },
  { cx: 62, cy: 70, r: 1.9 },
];

const NAAN_MINCED_GARLIC = [
  { x: 34, y: 34, rot: 20 },
  { x: 56, y: 28, rot: 65 },
  { x: 69, y: 46, rot: 110 },
  { x: 42, y: 52, rot: 45 },
  { x: 60, y: 63, rot: 15 },
  { x: 35, y: 68, rot: 80 },
  { x: 26, y: 49, rot: 135 },
  { x: 51, y: 41, rot: 95 },
  { x: 48, y: 73, rot: 30 },
];

export const PizzaBaseLayers: React.FC<PizzaCrustLayersProps> = ({
  shape,
  bakeLevel,
  clipIdPrefix,
  doughType = 'normal',
  crustFill,
  sauceApplied = false,
  sauceCoverage = 0,
  saucePoints = [],
  cheeseApplied = false,
  cheeseCoverage = 0,
  cheesePoints = [],
  sauceFill,
  cheeseFill,
  showCheeseFreckles = false,
  hasHoneySesameFinish = false,
}) => {
  const isGreenNaan = doughType === 'naan_verde';

  const innerDoughFill = isGreenNaan
    ? bakeLevel === 0
      ? '#86EFAC'
      : bakeLevel === 1
      ? '#4ADE80'
      : bakeLevel === 2
      ? '#22C55E'
      : '#1B2E1A'
    : bakeLevel === 0
    ? '#F4D3A1'
    : bakeLevel === 1
    ? '#E8BE86'
    : bakeLevel === 2
    ? '#C99455'
    : '#2D1F1A';

  const resolvedCrustFill =
    crustFill ||
    (isGreenNaan
      ? bakeLevel === 0
        ? '#4ADE80'
        : bakeLevel === 1
        ? '#65A30D'
        : bakeLevel === 2
        ? '#B45309'
        : '#1E291B'
      : bakeLevel === 0
      ? '#E6BA7E'
      : bakeLevel === 1
      ? '#C98A44'
      : bakeLevel === 2
      ? '#A66727'
      : '#3E2723');

  const resolvedCrustStroke = isGreenNaan
    ? bakeLevel === 0
      ? '#15803D'
      : bakeLevel === 1
      ? '#3F6212'
      : bakeLevel === 2
      ? '#78350F'
      : '#0B140A'
    : bakeLevel === 0
    ? '#8C5C26'
    : bakeLevel === 1
    ? '#5A3410'
    : bakeLevel === 2
    ? '#4A2606'
    : '#1A0F0D';

  const resolvedSauceFill = sauceFill || (bakeLevel >= 2 ? '#7F1D1D' : '#B91C1C');
  const resolvedCheeseFill =
    cheeseFill ||
    (bakeLevel === 0
      ? '#FDE047'
      : bakeLevel === 1
      ? '#EAB308'
      : bakeLevel === 2
      ? '#CA8A04'
      : '#573312');

  const sauceScale = Math.max(0.15, (sauceCoverage / 100) * 0.86);
  const cheeseScale = Math.max(0.15, (cheeseCoverage / 100) * 0.81);

  return (
    <g>
      <defs>
        <clipPath id={`${clipIdPrefix}-inner-clip`}>
          <ShapePrimitive
            shape={shape}
            transform="translate(50,50) scale(0.86) translate(-50,-50)"
          />
        </clipPath>
      </defs>

      {/* Outer Dough Crust */}
      <ShapePrimitive
        shape={shape}
        fill={resolvedCrustFill}
        stroke={resolvedCrustStroke}
        strokeWidth={1.6}
      />

      {/* Inner Dough Rim */}
      <ShapePrimitive
        shape={shape}
        fill={innerDoughFill}
        stroke={
          isGreenNaan
            ? bakeLevel >= 2
              ? '#D97706'
              : '#16A34A'
            : bakeLevel === 0
            ? '#DDA765'
            : '#925B22'
        }
        strokeWidth={isGreenNaan && bakeLevel >= 2 ? 1.4 : 0.8}
        transform="translate(50,50) scale(0.88) translate(-50,-50)"
      />

      {/* Green Naan Base Details: Clarified Ghee Brushstroke Sheen, Minced Garlic & Crispy High-Temp Blister Bubbles */}
      {isGreenNaan && (
        <g pointerEvents="none">
          {/* Brushed Ghee (Clarified Butter) Golden Sheen */}
          <g clipPath={`url(#${clipIdPrefix}-inner-clip)`}>
            <path
              d="M 22 36 Q 48 22 76 38 M 20 54 Q 52 44 78 58 M 28 70 Q 50 62 72 72"
              fill="none"
              stroke={bakeLevel >= 1 ? '#FACC15' : '#FEF08A'}
              strokeWidth="4.2"
              strokeLinecap="round"
              opacity={bakeLevel >= 1 ? 0.36 : 0.45}
            />
            {/* Finely Minced Garlic Specks (Ajo picado) */}
            {NAAN_MINCED_GARLIC.map((g, idx) => (
              <rect
                key={`garlic-${idx}`}
                x={g.x}
                y={g.y}
                width="2.1"
                height="1.3"
                rx="0.4"
                transform={`rotate(${g.rot} ${g.x} ${g.y})`}
                fill={bakeLevel >= 2 ? '#FDE68A' : '#FFFBEB'}
                stroke="#B45309"
                strokeWidth="0.35"
                opacity="0.92"
              />
            ))}
          </g>

          {/* Crispy Golden Naan Blister Bubbles (intensify at high-temp bake) */}
          {NAAN_BLISTER_BUBBLES.map((b, idx) => (
            <g key={`naan-bubble-${idx}`}>
              <circle
                cx={b.cx}
                cy={b.cy}
                r={bakeLevel >= 2 ? b.r * 1.15 : b.r * 0.78}
                fill={
                  bakeLevel === 0
                    ? '#BBF7D0'
                    : bakeLevel === 1
                    ? '#FDE047'
                    : bakeLevel === 2
                    ? '#F59E0B'
                    : '#451A03'
                }
                stroke={bakeLevel >= 2 ? '#78350F' : '#15803D'}
                strokeWidth="0.55"
                opacity={bakeLevel === 0 ? 0.65 : 0.92}
              />
              {bakeLevel >= 1 && (
                <circle
                  cx={b.cx - b.r * 0.25}
                  cy={b.cy - b.r * 0.25}
                  r={b.r * 0.35}
                  fill="#FEF9C3"
                  opacity="0.75"
                />
              )}
            </g>
          ))}
        </g>
      )}

      {/* Tomato Sauce Layer clipped inside shape */}
      {sauceApplied && (
        <g clipPath={`url(#${clipIdPrefix}-inner-clip)`}>
          <ShapePrimitive
            shape={shape}
            fill={resolvedSauceFill}
            stroke="#7F1D1D"
            strokeWidth={0.8}
            opacity={Math.min(1, 0.45 + (sauceCoverage / 100) * 0.55)}
            transform={`translate(50,50) scale(${sauceScale}) translate(-50,-50)`}
          />
          {saucePoints.map((pt, idx) => (
            <circle
              key={`sauce-pt-${idx}`}
              cx={pt.x}
              cy={pt.y}
              r={3.5 + (idx % 3)}
              fill="#B91C1C"
              opacity="0.7"
            />
          ))}
        </g>
      )}

      {/* Mozzarella Cheese Layer clipped inside shape */}
      {cheeseApplied && (
        <g clipPath={`url(#${clipIdPrefix}-inner-clip)`}>
          <ShapePrimitive
            shape={shape}
            fill={resolvedCheeseFill}
            stroke="#CA8A04"
            strokeWidth={0.6}
            opacity={Math.min(1, 0.45 + (cheeseCoverage / 100) * 0.55)}
            transform={`translate(50,50) scale(${cheeseScale}) translate(-50,-50)`}
          />
          {cheesePoints.map((pt, idx) => (
            <ellipse
              key={`cheese-pt-${idx}`}
              cx={pt.x}
              cy={pt.y}
              rx="3.2"
              ry="1.4"
              transform={`rotate(${(idx * 37) % 180} ${pt.x} ${pt.y})`}
              fill="#FEF9C3"
              stroke="#EAB308"
              strokeWidth="0.4"
            />
          ))}
          {showCheeseFreckles && bakeLevel >= 1 && (
            <g fill="#A16207" opacity="0.7">
              <circle cx="45" cy="40" r="1.5" />
              <circle cx="55" cy="48" r="2" />
              <circle cx="40" cy="58" r="1.8" />
              <circle cx="62" cy="42" r="1.6" />
              <circle cx="52" cy="62" r="2.2" />
            </g>
          )}
        </g>
      )}

      {/* Toasted sesame seeds around the crust rim + delicate pure honey ribbon */}
      {hasHoneySesameFinish && (
        <g pointerEvents="none">
          {SESAME_RIM_SEEDS.map((s, idx) => (
            <ellipse
              key={`sesame-rim-${idx}`}
              cx={s.x}
              cy={s.y}
              rx="1.25"
              ry="0.65"
              transform={`rotate(${s.r} ${s.x} ${s.y})`}
              fill={idx % 2 === 0 ? '#FEF3C7' : '#FDE68A'}
              stroke="#92400E"
              strokeWidth="0.35"
              opacity="0.92"
            />
          ))}
          <path
            d="M 28 34 Q 44 26 52 44 T 74 52 M 30 62 Q 46 56 58 70"
            fill="none"
            stroke="#F59E0B"
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.6"
          />
        </g>
      )}
    </g>
  );
};
