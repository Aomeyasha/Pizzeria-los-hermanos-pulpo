import React from 'react';
import { PnnNewsItem } from '../data/news';
import { sounds } from '../services/soundEffects';
import { CustomerAvatar } from './CustomerAvatar';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import { Tv, Sparkles, Newspaper, Play, Radio } from 'lucide-react';

interface PnnBroadcastProps {
  news: PnnNewsItem;
  dayNumber: number;
  onStartDay: () => void;
}

export const PnnBroadcast: React.FC<PnnBroadcastProps> = ({
  news,
  dayNumber,
  onStartDay,
}) => {
  const handleStart = () => {
    sounds.playBellDing();
    onStartDay();
  };

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-4 sm:p-6 md:p-8 bg-[#15100E] select-none overflow-hidden">
      {/* Background Studio with Octavio on the phone */}
      <img
        src="/assets/aistudio/octavio_e5dba978.jpg"
        alt="Octavio Corresponsal PNN"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-right md:object-center"
      />

      {/* Atmospheric vignette allowing the octopus to shine while text is ultra legible */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent pointer-events-none md:block hidden" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/50 pointer-events-none md:hidden block" />

      {/* Top TV Broadcast Bar */}
      <div className="relative z-10 flex items-center justify-between w-full max-w-6xl mx-auto px-2">
        <div className="flex items-center gap-2.5 px-4 py-2 bg-red-700/90 backdrop-blur-md text-white rounded-2xl border border-red-500/30 shadow-xl">
          <Tv className="w-5 h-5 text-amber-200 animate-pulse" />
          <span className="font-display text-sm sm:text-base font-bold tracking-wide">
            PNN · Pizza News Network
          </span>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-2xl border border-white/15 text-xs font-mono text-amber-200 shadow-lg">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
          <span className="font-bold text-red-400">EN DIRECTO</span>
          <span className="text-stone-400">·</span>
          <span>CORRESPONSAL OCTAVIO</span>
          <span className="text-stone-400">·</span>
          <span className="text-amber-300 font-bold">DÍA {dayNumber}</span>
        </div>
      </div>

      {/* Main Content: Artisanal Wooden Rolling-Pin Cutting Board & Curled Parchment */}
      <WoodParchmentBoard
        variant="horizontal"
        className="relative z-10 w-full max-w-lg md:max-w-md lg:max-w-xl my-auto self-start md:ml-4 lg:ml-8"
        innerClassName="max-h-[78vh] overflow-y-auto gap-3"
      >
        {/* Headline Tag & Header */}
        <div className="border-b-2 border-[#C8A16B]/60 pb-2.5">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[#9A231B] mb-1">
            <span className="flex items-center gap-1.5">
              <Newspaper className="w-4 h-4" />
              Titular de la Mañana
            </span>
            <span className="text-[11px] text-[#5D290D] bg-[#EFE0BA] border border-[#C69B61] px-2 py-0.5 rounded-md font-mono">
              Boletín #{dayNumber}
            </span>
          </div>
          <h2 className="text-lg sm:text-2xl font-display font-extrabold text-[#3A1E0D] leading-tight">
            {news.headline}
          </h2>
          <p className="text-xs sm:text-sm text-[#6E4427] mt-1 italic font-medium">
            "{news.subheadline}"
          </p>
        </div>

        {/* Story Dispatch */}
        <div className="bg-[#FFFBF0]/80 p-3.5 sm:p-4 rounded-xl border border-[#D4AE74] text-xs sm:text-sm leading-relaxed text-[#2F1608] font-medium">
          {news.story}
        </div>

        {/* Extra Bulletin (e.g. Day 3 Egyptian visitors & Day 4 Sabio de la India) */}
        {news.extraBulletin && (
          <div
            className={`rounded-xl p-3.5 shadow-sm space-y-2 border-2 ${
              dayNumber === 4
                ? 'bg-gradient-to-br from-purple-100/95 to-amber-50/90 border-purple-400'
                : 'bg-gradient-to-br from-amber-100/90 to-yellow-50/90 border-amber-500'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span
                className={`text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-md ${
                  dayNumber === 4
                    ? 'text-purple-950 bg-purple-200/80'
                    : 'text-amber-900 bg-amber-200/80'
                }`}
              >
                {news.extraBulletin.badge}
              </span>
            </div>
            <h3
              className={`font-display font-extrabold text-sm sm:text-base leading-snug ${
                dayNumber === 4 ? 'text-purple-950' : 'text-amber-950'
              }`}
            >
              {news.extraBulletin.title}
            </h3>
            <div className="flex flex-col sm:flex-row items-center gap-3">
              {news.extraBulletin.image ? (
                <img
                  src={news.extraBulletin.image}
                  alt="Medidas corporales egipcias: Mano extendida, 1 Codo y 2 Codos"
                  className="w-full sm:w-36 h-20 object-cover rounded-xl border border-sky-300 bg-[#BCE3F7] shrink-0"
                />
              ) : dayNumber === 4 ? (
                <div className="w-20 h-20 rounded-2xl bg-purple-50 border-2 border-purple-300 flex items-center justify-center shrink-0 shadow-inner">
                  <CustomerAvatar
                    config={{
                      skinColor: '#C68B59',
                      hairStyle: 'sage',
                      hairColor: '#CBD5E1',
                      shirtColor: '#6D28D9',
                      accessory: 'bindi',
                      baseExpression: 'happy',
                    }}
                    emotion="happy"
                    size={76}
                  />
                </div>
              ) : null}
              <p
                className={`text-xs leading-relaxed font-medium ${
                  dayNumber === 4 ? 'text-purple-950/90' : 'text-amber-950/90'
                }`}
              >
                {news.extraBulletin.story}
              </p>
            </div>
          </div>
        )}

        {/* Reporter Tip */}
        <div className="bg-[#EFE0BA]/80 border border-[#C69B61] p-3 rounded-xl flex items-start gap-2.5">
          <div className="p-1.5 bg-[#D48244] rounded-lg text-white shrink-0 mt-0.5 shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <p className="text-xs sm:text-sm text-[#3A1E0D] font-semibold">
            {news.tip}
          </p>
        </div>

        {/* Start Day Button */}
        <div className="pt-1 flex items-center justify-between gap-3">
          <div className="text-[11px] text-[#6E4427] font-semibold hidden sm:flex items-center gap-1">
            <Radio className="w-3.5 h-3.5 text-[#8C5528]" />
            Línea directa con el puesto
          </div>
          <button
            onClick={handleStart}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm sm:text-base rounded-2xl shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-white" />
            Abrir Pizzería (Iniciar Día {dayNumber})
          </button>
        </div>
      </WoodParchmentBoard>

      {/* Bottom Subtle Indicator */}
      <div className="relative z-10 w-full max-w-6xl mx-auto flex items-center justify-between px-2 text-white/70 text-xs">
        <span className="hidden sm:inline">📞 Transmisión submarina vía Caracol-Teléfono</span>
        <span className="ml-auto font-mono text-amber-200">Papa´s i fratelli Polpo © PNN</span>
      </div>
    </div>
  );
};
