import React from 'react';

export type WoodBoardVariant = 'vertical' | 'horizontal' | 'plank';

interface WoodParchmentBoardProps {
  variant?: WoodBoardVariant;
  children: React.ReactNode;
  className?: string;
  innerClassName?: string;
  /** Optional click handler that renders the reference's cute tomato close ("×") badge in the top-right */
  onClose?: () => void;
  closeTitle?: string;
  /** Optional speech-bubble wood+parchment tail pointing toward top or left */
  pointerPosition?: 'top' | 'left' | 'none';
  /** Compact spacing for smaller HUD badges/cards (e.g. Octavia commentary strip) */
  compact?: boolean;
  /** Show top-left green herb leaves & bottom leaves */
  showHerbs?: boolean;
  /** Show top rolling pin on horizontal boards */
  showRollingPin?: boolean;
  /** Show subtle sepia culinary sketches on the parchment corners */
  showDoodles?: boolean;
}

/**
 * Artisanal Wooden Cutting Board & Weathered Curled Parchment frame
 * inspired by traditional hand-painted cooking game UI boards.
 */
export const WoodParchmentBoard: React.FC<WoodParchmentBoardProps> = ({
  variant = 'plank',
  children,
  className = '',
  innerClassName = '',
  onClose,
  closeTitle = 'Cerrar',
  pointerPosition = 'none',
  compact = false,
  showHerbs = true,
  showRollingPin = true,
  showDoodles = true,
}) => {
  const outerPad = compact
    ? 'p-2 sm:p-2.5 rounded-2xl'
    : 'p-3 sm:p-4 rounded-[22px]';

  const parchmentPad = compact
    ? 'px-3 py-2 rounded-lg'
    : 'px-4 py-4 sm:px-6 sm:py-5 rounded-xl';

  return (
    <div className={`relative ${className}`}>
      {/* VERTICAL BOARD TOP HANDLE WITH HANGING HOLE */}
      {variant === 'vertical' && (
        <div
          aria-hidden="true"
          className="relative z-0 mx-auto -mb-2.5 w-24 sm:w-28 h-7 sm:h-8 rounded-t-[18px] border-[3px] border-[#5D290D] bg-gradient-to-b from-[#DE8E4C] via-[#C67233] to-[#A65621] shadow-[inset_0_2px_3px_rgba(255,232,192,0.55),0_-2px_8px_rgba(0,0,0,0.3)] flex items-center justify-center"
        >
          {/* Hanging hole */}
          <div className="w-4 h-4 rounded-full bg-[#24130A]/85 border-2 border-[#6A3112] shadow-[inset_0_2px_3px_rgba(0,0,0,0.85),0_1px_0_rgba(255,220,175,0.45)]" />
        </div>
      )}

      {/* HORIZONTAL BOARD TOP 3D WOODEN ROLLING PIN CREST */}
      {variant === 'horizontal' && showRollingPin && (
        <div
          aria-hidden="true"
          className="pointer-events-none relative z-20 mx-auto -mb-3.5 w-[72%] max-w-[340px] flex items-center justify-center drop-shadow-[0_6px_8px_rgba(32,12,2,0.45)]"
        >
          <svg viewBox="0 0 320 34" className="w-full h-auto overflow-visible">
            <defs>
              <linearGradient id="wp-pin-body" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#F4B67B" />
                <stop offset="28%" stopColor="#DF8F4C" />
                <stop offset="72%" stopColor="#B86228" />
                <stop offset="100%" stopColor="#7C3812" />
              </linearGradient>
              <linearGradient id="wp-pin-handle" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#D67C3E" />
                <stop offset="50%" stopColor="#A24E1D" />
                <stop offset="100%" stopColor="#5E280B" />
              </linearGradient>
            </defs>
            {/* Left turned handle */}
            <path
              d="M 4 17 Q 4 10 16 11 L 46 13 L 46 21 L 16 23 Q 4 24 4 17 Z"
              fill="url(#wp-pin-handle)"
              stroke="#4B2009"
              strokeWidth="2"
            />
            <rect x="44" y="10" width="7" height="14" rx="2" fill="#7D3B14" stroke="#4B2009" strokeWidth="1.5" />
            {/* Right turned handle */}
            <path
              d="M 316 17 Q 316 10 304 11 L 274 13 L 274 21 L 304 23 Q 316 24 316 17 Z"
              fill="url(#wp-pin-handle)"
              stroke="#4B2009"
              strokeWidth="2"
            />
            <rect x="269" y="10" width="7" height="14" rx="2" fill="#7D3B14" stroke="#4B2009" strokeWidth="1.5" />
            {/* Main wooden rolling cylinder */}
            <rect
              x="50"
              y="4"
              width="220"
              height="26"
              rx="6"
              fill="url(#wp-pin-body)"
              stroke="#4B2009"
              strokeWidth="2.4"
            />
            {/* Woodgrain lines on rolling pin */}
            <path d="M 60 11 Q 130 8 255 12" fill="none" stroke="#FFF2DB" strokeWidth="1.5" opacity="0.55" strokeLinecap="round" />
            <path d="M 68 18 Q 160 22 252 17" fill="none" stroke="#6E300E" strokeWidth="1.2" opacity="0.45" strokeLinecap="round" />
            <path d="M 85 24 Q 165 26 240 23" fill="none" stroke="#532208" strokeWidth="1.1" opacity="0.4" strokeLinecap="round" />
          </svg>
        </div>
      )}

      {/* BACKGROUND HERB LEAVES PEEKING OUT FROM BEHIND BOARD */}
      {showHerbs && (
        <>
          {/* Top-Left Fresh Basil / Parsley Sprig */}
          <svg
            aria-hidden="true"
            viewBox="0 0 60 60"
            className={`pointer-events-none absolute -top-2.5 -left-3.5 z-0 drop-shadow-md ${
              compact ? 'w-7 h-7' : 'w-11 h-11'
            }`}
          >
            <path
              d="M 46 46 C 30 42 18 35 12 20 C 26 16 40 24 46 46 Z"
              fill="#65A30D"
              stroke="#365314"
              strokeWidth="2"
            />
            <path
              d="M 44 48 C 28 50 12 46 6 34 C 18 28 36 32 44 48 Z"
              fill="#84CC16"
              stroke="#365314"
              strokeWidth="2"
            />
            <path d="M 16 24 Q 30 33 43 44" fill="none" stroke="#ECFCCB" strokeWidth="1.3" opacity="0.7" />
            <path d="M 11 36 Q 27 41 42 46" fill="none" stroke="#ECFCCB" strokeWidth="1.3" opacity="0.7" />
          </svg>

          {/* Bottom-Right Parsley Leaves */}
          <svg
            aria-hidden="true"
            viewBox="0 0 60 60"
            className={`pointer-events-none absolute -bottom-3 -right-2.5 z-0 drop-shadow-md ${
              compact ? 'w-7 h-7' : 'w-11 h-11'
            }`}
          >
            <path
              d="M 12 14 C 28 16 42 22 48 38 C 34 42 20 34 12 14 Z"
              fill="#65A30D"
              stroke="#365314"
              strokeWidth="2"
            />
            <path
              d="M 16 18 C 34 14 48 18 54 30 C 42 36 26 32 16 18 Z"
              fill="#84CC16"
              stroke="#365314"
              strokeWidth="2"
            />
            <path d="M 18 19 Q 34 26 44 35" fill="none" stroke="#ECFCCB" strokeWidth="1.3" opacity="0.7" />
          </svg>
        </>
      )}

      {/* SPEECH BUBBLE WOOD + PARCHMENT POINTER (Optional for dialogue boxes) */}
      {pointerPosition === 'top' && (
        <div
          aria-hidden="true"
          className="absolute -top-2.5 left-1/2 -translate-x-1/2 z-20 w-6 h-6 rotate-45 bg-[#DFB97C] border-t-[3px] border-l-[3px] border-[#5D290D] shadow-sm"
        />
      )}
      {pointerPosition === 'left' && (
        <div
          aria-hidden="true"
          className="absolute top-6 -left-2 z-20 w-4 h-4 rotate-45 bg-[#D48244] border-b-[3px] border-l-[3px] border-[#5D290D] shadow-sm"
        />
      )}

      {/* OPTIONAL TOMATO / APPLE CLOSE BUTTON ON TOP-RIGHT (matches reference image) */}
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          title={closeTitle}
          aria-label={closeTitle}
          className={`group absolute z-40 cursor-pointer transition-transform hover:scale-110 active:scale-95 drop-shadow-[0_4px_6px_rgba(0,0,0,0.45)] ${
            compact ? '-top-2.5 -right-2.5 w-7 h-7' : '-top-3 -right-3 w-10 h-10'
          }`}
        >
          <svg viewBox="0 0 44 44" className="w-full h-full overflow-visible">
            {/* Green tomato calyx stem */}
            <path
              d="M 22 4 L 18 10 L 13 8 L 18 12 L 22 10 L 26 12 L 31 8 L 26 10 Z"
              fill="#4D7C0F"
              stroke="#1A2E05"
              strokeWidth="1.2"
              strokeLinejoin="round"
            />
            {/* Glossy red tomato body */}
            <circle
              cx="22"
              cy="24"
              r="16"
              fill="#DC2626"
              stroke="#7F1D1D"
              strokeWidth="2.2"
            />
            <ellipse cx="16" cy="18" rx="4.5" ry="2.8" transform="rotate(-25 16 18)" fill="#FCA5A5" opacity="0.65" />
            {/* Dark X mark */}
            <path
              d="M 16.5 18.5 L 27.5 29.5 M 27.5 18.5 L 16.5 29.5"
              stroke="#450A0A"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            <path
              d="M 16.5 18.5 L 27.5 29.5 M 27.5 18.5 L 16.5 29.5"
              stroke="#FEF2F2"
              strokeWidth="1.4"
              strokeLinecap="round"
              opacity="0.85"
            />
          </svg>
        </button>
      )}

      {/* WOODEN CUTTING BOARD PLANK FRAME */}
      <div
        className={`relative z-10 flex flex-col border-[3px] border-[#5D290D] shadow-[0_18px_38px_rgba(12,5,1,0.62),inset_0_2px_2px_rgba(255,222,173,0.52),inset_0_-4px_6px_rgba(68,25,6,0.6)] ${outerPad}`}
        style={{
          background:
            'repeating-linear-gradient(180deg, #D58344 0px, #C77234 46px, #A55220 48px, #BD682D 50px, #CC7A3C 96px, #9B4B1B 98px)',
        }}
      >
        {/* Subtle Woodgrain & Side Notch Carved Bevels */}
        <svg
          aria-hidden="true"
          viewBox="0 0 400 260"
          preserveAspectRatio="none"
          className="pointer-events-none absolute inset-0 w-full h-full opacity-25 rounded-[18px]"
        >
          <path d="M 0 22 Q 110 15 220 24 T 400 20" fill="none" stroke="#4D1E07" strokeWidth="1.6" />
          <path d="M 0 74 Q 140 82 260 70 T 400 76" fill="none" stroke="#FFE1B8" strokeWidth="1.1" />
          <path d="M 0 138 Q 95 130 210 142 T 400 135" fill="none" stroke="#4D1E07" strokeWidth="1.5" />
          <path d="M 0 204 Q 130 212 270 198 T 400 206" fill="none" stroke="#4D1E07" strokeWidth="1.5" />
          {/* Little rustic edge wood notches */}
          <polygon points="0,44 7,48 0,52" fill="#4B2009" />
          <polygon points="400,92 393,96 400,100" fill="#4B2009" />
          <polygon points="0,185 6,189 0,193" fill="#4B2009" />
        </svg>

        {/* LAYERED WEATHERED PARCHMENT RECIPE SHEET */}
        <div
          className={`relative z-10 flex flex-col text-[#3A1E0D] border-2 border-[#B38651] shadow-[0_5px_12px_rgba(52,20,4,0.42),inset_0_0_22px_rgba(196,144,78,0.22)] ${parchmentPad} ${innerClassName}`}
          style={{
            background:
              'linear-gradient(155deg, #FFF7E4 0%, #FBF0D3 52%, #F3DFB4 100%)',
          }}
        >
          {/* Curled Paper Corner: Top-Right Fold */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute top-0 right-0 w-6 h-6 z-20 overflow-hidden rounded-tr-lg"
          >
            <div
              className="w-full h-full"
              style={{
                background:
                  'linear-gradient(225deg, #9C5324 0%, #9C5324 46%, #8C6239 48%, #E6C78E 52%, #FFF7E4 100%)',
                boxShadow: '-2px 2px 4px rgba(85,42,12,0.32)',
              }}
            />
          </div>

          {/* Curled Paper Corner: Bottom-Left Fold */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute bottom-0 left-0 w-6 h-6 z-20 overflow-hidden rounded-bl-lg"
          >
            <div
              className="w-full h-full"
              style={{
                background:
                  'linear-gradient(45deg, #8F481E 0%, #8F481E 46%, #8C6239 48%, #DFBE82 52%, #FFF5DC 100%)',
                boxShadow: '2px -2px 4px rgba(85,42,12,0.3)',
              }}
            />
          </div>

          {/* Subtle Parchment Smudges, Flour Dust & Hand-Drawn Culinary Doodles in Outer Corners */}
          {showDoodles && !compact && (
            <svg
              aria-hidden="true"
              viewBox="0 0 400 240"
              preserveAspectRatio="none"
              className="pointer-events-none absolute inset-0 w-full h-full z-0 opacity-65 rounded-xl"
            >
              {/* Subtle warm parchment smudges near corners */}
              <ellipse cx="42" cy="34" rx="26" ry="13" fill="#DEC08A" opacity="0.22" />
              <ellipse cx="355" cy="202" rx="30" ry="16" fill="#DEC08A" opacity="0.24" />
              <ellipse cx="356" cy="38" rx="22" ry="12" fill="#FFFFFF" opacity="0.48" />
              {/* Tiny rosemary sprig doodle top-left */}
              <g stroke="#7A4B26" strokeWidth="1.2" fill="none" opacity="0.32">
                <path d="M 12 30 Q 20 20 30 12" strokeLinecap="round" />
                <path d="M 16 26 L 12 19 M 20 22 L 17 14 M 24 18 L 28 23 M 20 23 L 26 27" strokeLinecap="round" />
              </g>
              {/* Tiny wooden spoon doodle bottom-right */}
              <g stroke="#7A4B26" strokeWidth="1.2" fill="none" opacity="0.28" transform="translate(362, 198) rotate(-32)">
                <ellipse cx="10" cy="8" rx="5.5" ry="7.5" />
                <line x1="10" y1="15.5" x2="10" y2="31" strokeLinecap="round" />
              </g>
            </svg>
          )}

          {/* Actual Content Layer */}
          <div className="relative z-10 flex flex-col flex-1 min-h-0">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
