import React, { useState, useRef, useCallback } from 'react';
import { CustomerOrder, GameUpgrades, PizzaState, ToppingPlacement, ToppingType } from '../types/pizza';
import { BASE_COSTS, TOPPING_COSTS, TOPPING_NAMES } from '../data/customers';
import { sounds } from '../services/soundEffects';
import { ToppingSprite } from './ToppingSprite';
import { PizzaBaseLayers } from './PizzaShapeSVG';
import { CATALOGO_TAMANOS, ICONOS_FORMA } from '../utils/pizzaGeometry';
import { Trash2, ArrowRight, Eye, Sparkles, AlertCircle, Undo2 } from 'lucide-react';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import { GameTheme } from '../types/theme';

interface KitchenStationProps {
  pizza: PizzaState;
  order: CustomerOrder | null;
  upgrades: GameUpgrades;
  theme?: GameTheme;
  onUpdatePizza: (updater: (prev: PizzaState) => PizzaState) => void;
  onDeductMoney: (amount: number) => void;
  onMoveToOven: () => void;
  onDiscardPizza: () => void;
}

export const KitchenStation: React.FC<KitchenStationProps> = ({
  pizza,
  order,
  upgrades,
  theme,
  onUpdatePizza,
  onDeductMoney,
  onMoveToOven,
  onDiscardPizza,
}) => {
  // Selected tool: 'none' | 'sauce' | 'cheese' | ToppingType
  const [selectedTool, setSelectedTool] = useState<'sauce' | 'cheese' | ToppingType | null>('sauce');
  const [halfMode, setHalfMode] = useState<'whole' | 'left' | 'right'>('whole');
  const [showToppingGuide, setShowToppingGuide] = useState<boolean>(upgrades.toppingGuide);
  const [isDraggingSauce, setIsDraggingSauce] = useState(false);

  const pizzaSvgRef = useRef<SVGSVGElement | null>(null);

  // Helper to get pizza relative percentage coordinates (0-100)
  const getPizzaCoords = useCallback((e: React.MouseEvent<SVGSVGElement>) => {
    if (!pizzaSvgRef.current) return null;
    const rect = pizzaSvgRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    // Check if within the circular dough boundary (radius ~ 43% from center 50, 50)
    const dx = x - 50;
    const dy = y - 50;
    const dist = Math.sqrt(dx * dx + dy * dy);

    return { x, y, dist, inside: dist <= 43 };
  }, []);

  // Handle click on pizza
  const handlePizzaClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const coords = getPizzaCoords(e);
    if (!coords || !coords.inside) return;

    if (selectedTool === 'sauce') {
      applySauceAt(coords.x, coords.y);
    } else if (selectedTool === 'cheese') {
      applyCheeseAt(coords.x, coords.y);
    } else if (selectedTool) {
      // Placing a topping
      placeTopping(selectedTool, coords.x, coords.y);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (isDraggingSauce && selectedTool === 'sauce') {
      const coords = getPizzaCoords(e);
      if (coords && coords.inside) {
        applySauceAt(coords.x, coords.y);
      }
    }
  };

  // 1. Sauce Application
  const applySauceAt = (x: number, y: number) => {
    // Only charge once when sauce is first applied
    if (!pizza.sauce.applied) {
      onDeductMoney(BASE_COSTS.sauce);
    }
    sounds.playSauceSquirt();

    onUpdatePizza((prev) => {
      const newCoverage = Math.min(100, prev.sauce.coverage + 12);
      const newPoints = [...prev.sauce.points, { x, y }];
      return {
        ...prev,
        sauce: {
          applied: true,
          coverage: newCoverage,
          points: newPoints.slice(-30), // keep recent swirl points
          half: halfMode,
        },
      };
    });
  };

  // 2. Cheese Application
  const applyCheeseAt = (x: number, y: number) => {
    if (!pizza.cheese.applied) {
      onDeductMoney(BASE_COSTS.cheese);
    }
    sounds.playCheeseSprinkle();

    onUpdatePizza((prev) => {
      const newCoverage = Math.min(100, prev.cheese.coverage + 14);
      const newPoints = [...prev.cheese.points, { x, y }];
      return {
        ...prev,
        cheese: {
          applied: true,
          coverage: newCoverage,
          points: newPoints.slice(-40),
          half: halfMode,
        },
      };
    });
  };

  // 3. Topping Placement
  const placeTopping = (type: ToppingType, x: number, y: number) => {
    // Check half restrictions if chosen
    if (halfMode === 'left' && x > 50) return;
    if (halfMode === 'right' && x < 50) return;

    const cost = TOPPING_COSTS[type] || 0.15;
    onDeductMoney(cost);

    const pitch = (x + y) / 100;
    sounds.playToppingPop(pitch);

    const rotation = Math.floor(Math.random() * 360);
    const jitterX = (Math.random() - 0.5) * 1.5;
    const jitterY = (Math.random() - 0.5) * 1.5;

    const newTopping: ToppingPlacement = {
      id: `top-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      x: x + jitterX,
      y: y + jitterY,
      rotation,
      half: x < 50 ? 'left' : 'right',
    };

    onUpdatePizza((prev) => ({
      ...prev,
      toppings: [...prev.toppings, newTopping],
    }));
  };

  // Auto helper (if unlocked)
  const applyAutoSauceAndCheese = () => {
    if (!pizza.sauce.applied) onDeductMoney(BASE_COSTS.sauce);
    if (!pizza.cheese.applied) onDeductMoney(BASE_COSTS.cheese);
    sounds.playSauceSquirt();
    sounds.playCheeseSprinkle();

    onUpdatePizza((prev) => ({
      ...prev,
      sauce: {
        applied: true,
        coverage: 95,
        points: [],
        half: 'whole',
      },
      cheese: {
        applied: true,
        coverage: 95,
        points: [],
        half: 'whole',
      },
    }));
  };

  // 18 standard topping guide points (3 per slice for 6 slices)
  const GUIDE_POINTS = [
    // Inner ring (6 points, radius ~18%)
    { x: 50, y: 32 }, { x: 65, y: 41 }, { x: 65, y: 59 },
    { x: 50, y: 68 }, { x: 35, y: 59 }, { x: 35, y: 41 },
    // Outer ring (12 points, radius ~33%)
    { x: 50, y: 17 }, { x: 66, y: 21 }, { x: 79, y: 33 },
    { x: 83, y: 50 }, { x: 79, y: 67 }, { x: 66, y: 79 },
    { x: 50, y: 83 }, { x: 34, y: 79 }, { x: 21, y: 67 },
    { x: 17, y: 50 }, { x: 21, y: 33 }, { x: 34, y: 21 },
  ];

  return (
    <div className="relative flex flex-col h-full bg-[#1A1412] select-none overflow-hidden">
      {/* Background: User Rustic Kitchen Ingredients Table Image */}
      <img
        src="/assets/aistudio/kitcken_5d4796e4.jpg"
        alt="Mesa de Ingredientes"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
      />
      {/* Soft overlay for visual clarity */}
      <div className="absolute inset-0 bg-black/20 pointer-events-none" />

      {/* Top Bar Controls */}
      <div className="relative z-20 flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-[#FAF6EE]/90 backdrop-blur-md border-b border-[#8C6D52]/40 shadow-md">
        {/* Halves Selector */}
        <div className="flex items-center gap-1.5 p-1 bg-black/5 rounded-lg">
          <button
            onClick={() => setHalfMode('whole')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 ${
              halfMode === 'whole'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-700 hover:bg-black/5'
            }`}
          >
            Toda la Pizza
          </button>
          <button
            onClick={() => setHalfMode('left')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 ${
              halfMode === 'left'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-700 hover:bg-black/5'
            }`}
          >
            Mitad Izquierda
          </button>
          <button
            onClick={() => setHalfMode('right')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 ${
              halfMode === 'right'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-700 hover:bg-black/5'
            }`}
          >
            Mitad Derecha
          </button>
        </div>

        {/* Upgrades toggles & helpers */}
        <div className="flex items-center gap-2">
          {upgrades.autoSauceCheese && (
            <button
              onClick={applyAutoSauceAndCheese}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-950 bg-amber-200 hover:bg-amber-300 rounded-lg border border-amber-300 transition-colors whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              Auto Salsa & Queso
            </button>
          )}

          <button
            onClick={() => setShowToppingGuide(!showToppingGuide)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
              showToppingGuide
                ? 'bg-stone-700 text-white border-stone-800'
                : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
            }`}
            title="Activa los puntos de referencia para colocar 18 porciones perfectas"
          >
            <Eye className="w-3.5 h-3.5" />
            Guía de Toppings
          </button>

          <button
            onClick={() => {
              if (pizza.toppings.length === 0) return;
              sounds.playToppingPop(0.4);
              onUpdatePizza((prev) => ({
                ...prev,
                toppings: prev.toppings.slice(0, -1),
              }));
            }}
            disabled={pizza.toppings.length === 0}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-100 disabled:opacity-45 border border-stone-300 rounded-lg transition-colors whitespace-nowrap shrink-0"
            title="Quitar el último topping colocado"
          >
            <Undo2 className="w-3.5 h-3.5" />
            Deshacer
          </button>

          <button
            onClick={() => {
              if (window.confirm('¿Deseas tirar esta pizza a la basura y empezar otra?')) {
                onDiscardPizza();
              }
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
            title="Tirar masa y comenzar de nuevo"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Tirar
          </button>

          <button
            onClick={onMoveToOven}
            className="flex items-center gap-2 px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0"
          >
            Llevar al Horno
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Workspace Area */}
      <div className="relative z-10 flex-1 flex flex-col md:flex-row items-center justify-center p-3 gap-6 overflow-hidden">
        {/* Center: Pizza Peel & Dough */}
        <div className="relative flex items-center justify-center w-[340px] h-[340px] sm:w-[420px] sm:h-[420px] max-w-full drop-shadow-xl select-none">
          {/* Wooden Pizza Peel Texture */}
          <div className={`absolute inset-0 rounded-full ${theme ? theme.peelBg : 'bg-[#C89B66]'} border-4 ${theme ? theme.peelBorder : 'border-[#936639]'} shadow-inner flex items-center justify-center`}>
            {/* Wood grain ring lines */}
            <div className={`w-[94%] h-[94%] rounded-full border-2 ${theme ? theme.peelInnerRing : 'border-[#A87B4C]'} opacity-40 pointer-events-none`} />
            <div className="w-[84%] h-[84%] rounded-full border border-black/15 opacity-30 pointer-events-none" />
          </div>

          {/* Size & Shape persistence badge */}
          <div className="absolute -top-3 z-20 px-3 py-0.5 bg-amber-100 text-amber-950 text-[11px] font-bold rounded-full shadow-xs border border-amber-300 flex items-center gap-1.5">
            <span>{ICONOS_FORMA[pizza.shape]}</span>
            <span>Pizza {pizza.size} · {pizza.shape}</span>
          </div>

          {/* SVG Pizza Interactive Surface */}
          <svg
            ref={pizzaSvgRef}
            viewBox="0 0 100 100"
            style={{ transform: `scale(${CATALOGO_TAMANOS[pizza.size]?.escalaVisual || 0.9})` }}
            className="relative z-10 w-[92%] h-[92%] cursor-crosshair overflow-visible transition-transform duration-300"
            onClick={handlePizzaClick}
            onMouseDown={() => setIsDraggingSauce(true)}
            onMouseUp={() => setIsDraggingSauce(false)}
            onMouseLeave={() => setIsDraggingSauce(false)}
            onMouseMove={handleMouseMove}
          >
            <PizzaBaseLayers
              shape={pizza.shape}
              bakeLevel={0}
              clipIdPrefix="kitchen"
              doughType={pizza.dough}
              sauceApplied={pizza.sauce.applied}
              sauceCoverage={pizza.sauce.coverage}
              saucePoints={pizza.sauce.points}
              cheeseApplied={pizza.cheese.applied}
              cheeseCoverage={pizza.cheese.coverage}
              cheesePoints={pizza.cheese.points}
              hasHoneySesameFinish={pizza.toppings.some((t) => t.type === 'miel_sesamo')}
            />

            {/* 4. Half Division Line (subtle dashed line if half mode chosen) */}
            {halfMode !== 'whole' && (
              <line
                x1="50"
                y1="8"
                x2="50"
                y2="92"
                stroke="#1E293B"
                strokeWidth="0.8"
                strokeDasharray="2 2"
                opacity="0.6"
                pointerEvents="none"
              />
            )}

            {/* 5. Toppings Guide Overlay (if toggled) */}
            {showToppingGuide && (
              <g pointerEvents="none" opacity="0.65">
                {GUIDE_POINTS.map((pt, idx) => (
                  <circle
                    key={`guide-${idx}`}
                    cx={pt.x}
                    cy={pt.y}
                    r="1.8"
                    fill="none"
                    stroke="#0284C7"
                    strokeWidth="0.8"
                    strokeDasharray="1 1"
                  />
                ))}
              </g>
            )}

            {/* 6. Placed Toppings */}
            {pizza.toppings.map((top) => (
              <ToppingSprite
                key={top.id}
                type={top.type}
                x={top.x}
                y={top.y}
                rotation={top.rotation}
                size={22}
                isBaked={false}
              />
            ))}
          </svg>

          {/* Current Ingredient Hint Pill */}
          <div className="absolute -bottom-3 px-3 py-1 bg-white/90 backdrop-blur-xs text-stone-800 text-[11px] font-medium rounded-full shadow-xs border border-stone-200">
            {selectedTool === 'sauce' && `Salsa de Tomate (${pizza.sauce.coverage}%)`}
            {selectedTool === 'cheese' && `Queso Mozzarella (${pizza.cheese.coverage}%)`}
            {selectedTool && selectedTool !== 'sauce' && selectedTool !== 'cheese' && (
              <span>
                Colocando <strong className="capitalize">{TOPPING_NAMES[selectedTool]}</strong> ({pizza.toppings.filter((t) => t.type === selectedTool).length} puestos)
              </span>
            )}
            {!selectedTool && 'Selecciona un ingrediente'}
          </div>
        </div>

        {/* Right / Bottom: Ingredients Tray (Tubs) */}
        <div className="relative z-10 flex flex-col gap-2.5 w-full md:w-80 max-w-sm">
          {/* Dedicated Sabio de la India Panel in Toppings Station */}
          {order?.customerType === 'sabio_india' && order.sabioZeroChallenge && (
            <div className="bg-purple-100/95 backdrop-blur-md border-2 border-purple-500 rounded-2xl p-3 shadow-xl text-purple-950 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-black uppercase tracking-wider flex items-center gap-1">
                  <span>🧘🏽‍♂️</span> Reto del Sabio (El Cero)
                </span>
                <span className="text-[10px] font-extrabold bg-purple-700 text-white px-2 py-0.5 rounded-full">
                  No nombrados: {order.sabioZeroChallenge.cantidadPorCadaUno} c/u
                </span>
              </div>
              <p className="text-[11px] font-bold leading-snug text-purple-950">
                De su lista de {order.sabioZeroChallenge.poolToppings.length} ingredientes: pon{' '}
                <strong className="text-rose-700">0 (ninguno)</strong> en los marcados con 0 y{' '}
                <strong className="text-emerald-800">
                  {order.sabioZeroChallenge.cantidadPorCadaUno} c/u
                </strong>{' '}
                en los demás.
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {order.sabioZeroChallenge.poolToppings.map((t) => {
                  const isZero = order.sabioZeroChallenge?.descartados.includes(t);
                  const placedCount = pizza.toppings.filter((item) => item.type === t).length;
                  const target = isZero ? 0 : order.sabioZeroChallenge!.cantidadPorCadaUno;
                  const isWrongZero = isZero && placedCount > 0;
                  const isComplete = !isZero && placedCount === target;
                  return (
                    <button
                      key={`kitchen-sabio-${t}`}
                      type="button"
                      onClick={() => setSelectedTool(t)}
                      className={`flex items-center justify-between gap-1 px-2 py-1 rounded-xl border text-[11px] font-bold transition-all cursor-pointer ${
                        selectedTool === t ? 'ring-2 ring-purple-600 ' : ''
                      }${
                        isWrongZero
                          ? 'bg-rose-100 border-rose-500 text-rose-950'
                          : isZero
                          ? 'bg-white/80 border-rose-300 text-rose-900'
                          : isComplete
                          ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                          : 'bg-white border-purple-300 text-purple-950 hover:bg-purple-50'
                      }`}
                    >
                      <span className="capitalize truncate">{TOPPING_NAMES[t] || t}</span>
                      <span className="font-mono text-[10px] shrink-0">
                        {isZero
                          ? placedCount > 0
                            ? `⚠️ ${placedCount}/0`
                            : '🚫 0'
                          : `${placedCount}/${target}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="text-xs font-bold uppercase tracking-wider text-amber-100 flex items-center justify-between px-1 drop-shadow-md">
            <span>Mesa de Ingredientes</span>
            <span className="text-[11px] font-normal text-amber-200">Costo por porción</span>
          </div>

          <WoodParchmentBoard
            variant="plank"
            compact
            showHerbs={true}
            showDoodles={false}
            innerClassName="p-2! rounded-lg"
          >
            <div className="grid grid-cols-2 gap-2 max-h-[52vh] overflow-y-auto pr-0.5">
            {/* Sauce Tub */}
            <button
              onClick={() => setSelectedTool('sauce')}
              className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                selectedTool === 'sauce'
                  ? 'bg-rose-50 border-rose-500 shadow-xs ring-2 ring-rose-300'
                  : 'bg-white border-stone-200 hover:bg-stone-50'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-red-600 border border-red-800 shadow-inner flex items-center justify-center shrink-0">
                <div className="w-3.5 h-3.5 rounded-full bg-red-400 opacity-60" />
              </div>
              <div className="truncate">
                <div className="text-xs font-bold text-stone-900 leading-tight">Salsa Roja</div>
                <div className="text-[10px] text-stone-500 font-mono">${BASE_COSTS.sauce.toFixed(2)}</div>
              </div>
            </button>

            {/* Cheese Tub */}
            <button
              onClick={() => setSelectedTool('cheese')}
              className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                selectedTool === 'cheese'
                  ? 'bg-amber-50 border-amber-500 shadow-xs ring-2 ring-amber-300'
                  : 'bg-white border-stone-200 hover:bg-stone-50'
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-amber-300 border border-amber-500 shadow-inner flex items-center justify-center shrink-0">
                <div className="w-3.5 h-2 rounded-sm bg-yellow-100" />
              </div>
              <div className="truncate">
                <div className="text-xs font-bold text-stone-900 leading-tight">Mozzarella</div>
                <div className="text-[10px] text-stone-500 font-mono">${BASE_COSTS.cheese.toFixed(2)}</div>
              </div>
            </button>

            {/* Pepperoni Tub */}
            <button
              onClick={() => setSelectedTool('pepperoni')}
              className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                selectedTool === 'pepperoni'
                  ? 'bg-red-50 border-red-500 shadow-xs ring-2 ring-red-300'
                  : 'bg-white border-stone-200 hover:bg-stone-50'
              }`}
            >
              <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                <ToppingSprite type="pepperoni" />
              </svg>
              <div className="truncate">
                <div className="text-xs font-bold text-stone-900 leading-tight">Pepperoni</div>
                <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.pepperoni.toFixed(2)} c/u</div>
              </div>
              {pizza.toppings.filter((t) => t.type === 'pepperoni').length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                  {pizza.toppings.filter((t) => t.type === 'pepperoni').length}
                </span>
              )}
            </button>

            {/* Mushroom Tub */}
            <button
              onClick={() => setSelectedTool('mushroom')}
              className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                selectedTool === 'mushroom'
                  ? 'bg-amber-50 border-amber-600 shadow-xs ring-2 ring-amber-300'
                  : 'bg-white border-stone-200 hover:bg-stone-50'
              }`}
            >
              <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                <ToppingSprite type="mushroom" />
              </svg>
              <div className="truncate">
                <div className="text-xs font-bold text-stone-900 leading-tight">Champiñones</div>
                <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.mushroom.toFixed(2)} c/u</div>
              </div>
              {pizza.toppings.filter((t) => t.type === 'mushroom').length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                  {pizza.toppings.filter((t) => t.type === 'mushroom').length}
                </span>
              )}
            </button>

            {/* Olive Tub */}
            <button
              onClick={() => setSelectedTool('olive')}
              className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                selectedTool === 'olive'
                  ? 'bg-stone-100 border-stone-700 shadow-xs ring-2 ring-stone-400'
                  : 'bg-white border-stone-200 hover:bg-stone-50'
              }`}
            >
              <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                <ToppingSprite type="olive" />
              </svg>
              <div className="truncate">
                <div className="text-xs font-bold text-stone-900 leading-tight">Aceitunas</div>
                <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.olive.toFixed(2)} c/u</div>
              </div>
              {pizza.toppings.filter((t) => t.type === 'olive').length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                  {pizza.toppings.filter((t) => t.type === 'olive').length}
                </span>
              )}
            </button>

            {/* Carne de Mamut Tub (if unlocked) */}
            {upgrades.unlockedToppings.includes('carne_mamut') ? (
              <button
                onClick={() => setSelectedTool('carne_mamut')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'carne_mamut'
                    ? 'bg-orange-50 border-orange-700 shadow-xs ring-2 ring-orange-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="carne_mamut" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Carne Mamut</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.carne_mamut.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'carne_mamut').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'carne_mamut').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Carne Mamut</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Piña Tub (if unlocked) */}
            {upgrades.unlockedToppings.includes('pina') ? (
              <button
                onClick={() => setSelectedTool('pina')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'pina'
                    ? 'bg-yellow-50 border-yellow-500 shadow-xs ring-2 ring-yellow-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="pina" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Piña</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.pina.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'pina').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'pina').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Piña</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Queso Extra Tub (if unlocked) */}
            {upgrades.unlockedToppings.includes('queso_extra') ? (
              <button
                onClick={() => setSelectedTool('queso_extra')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'queso_extra'
                    ? 'bg-amber-50 border-amber-400 shadow-xs ring-2 ring-amber-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="queso_extra" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Queso Extra</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.queso_extra.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'queso_extra').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'queso_extra').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Queso Extra</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Basil Tub (if unlocked) */}
            {upgrades.unlockedToppings.includes('basil') ? (
              <button
                onClick={() => setSelectedTool('basil')}
                className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'basil'
                    ? 'bg-green-50 border-green-600 shadow-xs ring-2 ring-green-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="basil" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Albahaca</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.basil.toFixed(2)} c/u</div>
                </div>
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Albahaca</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Sausage Tub (if unlocked) */}
            {upgrades.unlockedToppings.includes('sausage') ? (
              <button
                onClick={() => setSelectedTool('sausage')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'sausage'
                    ? 'bg-orange-50 border-orange-700 shadow-xs ring-2 ring-orange-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="sausage" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Salchicha</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.sausage.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'sausage').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'sausage').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Salchicha</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Pizza Egipcia Header Divider inside tray */}
            <div className="col-span-2 mt-1 pt-1.5 border-t border-amber-300/80 flex items-center justify-between px-1">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-900">
                🏺 Pizza Egipcia
              </span>
              <span className="text-[9px] font-bold text-amber-700">Día 3+</span>
            </div>

            {/* Puerros y Cebollas Caramelizadas */}
            {upgrades.unlockedToppings.includes('puerro_cebolla') ? (
              <button
                onClick={() => setSelectedTool('puerro_cebolla')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'puerro_cebolla'
                    ? 'bg-purple-50 border-purple-600 shadow-xs ring-2 ring-purple-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="puerro_cebolla" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Puerro/Cebolla</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.puerro_cebolla.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'puerro_cebolla').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'puerro_cebolla').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Puerro/Cebolla</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Higos y Dátiles */}
            {upgrades.unlockedToppings.includes('higos_datiles') ? (
              <button
                onClick={() => setSelectedTool('higos_datiles')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'higos_datiles'
                    ? 'bg-rose-50 border-rose-600 shadow-xs ring-2 ring-rose-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="higos_datiles" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Higos/Dátiles</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.higos_datiles.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'higos_datiles').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'higos_datiles').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Higos/Dátiles</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Pato Asado / Pescado del Nilo */}
            {upgrades.unlockedToppings.includes('pato_pescado') ? (
              <button
                onClick={() => setSelectedTool('pato_pescado')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'pato_pescado'
                    ? 'bg-orange-50 border-orange-600 shadow-xs ring-2 ring-orange-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="pato_pescado" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Pato / Pescado</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.pato_pescado.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'pato_pescado').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'pato_pescado').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Pato / Pescado</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Miel Pura y Sésamo Tostado */}
            {upgrades.unlockedToppings.includes('miel_sesamo') ? (
              <button
                onClick={() => setSelectedTool('miel_sesamo')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'miel_sesamo'
                    ? 'bg-yellow-50 border-amber-500 shadow-xs ring-2 ring-amber-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="miel_sesamo" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Miel y Sésamo</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.miel_sesamo.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'miel_sesamo').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-amber-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'miel_sesamo').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Miel y Sésamo</div>
                  <div className="text-[9px] text-stone-400">En Tienda</div>
                </div>
              </div>
            )}

            {/* Rueda de Maharajá Header Divider inside tray */}
            <div className="col-span-2 mt-1 pt-1.5 border-t border-emerald-400/70 flex items-center justify-between px-1">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-900">
                🛞 Rueda de Maharajá
              </span>
              <span className="text-[9px] font-bold text-emerald-700">Día 4+</span>
            </div>

            {/* Queso Paneer */}
            {upgrades.unlockedToppings.includes('queso_paneer') ? (
              <button
                onClick={() => setSelectedTool('queso_paneer')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'queso_paneer'
                    ? 'bg-amber-50 border-amber-500 shadow-xs ring-2 ring-amber-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="queso_paneer" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Queso Paneer</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.queso_paneer.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'queso_paneer').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'queso_paneer').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Queso Paneer</div>
                  <div className="text-[9px] text-stone-400">Tienda (Día 4+)</div>
                </div>
              </div>
            )}

            {/* Pollo Tandoori o Garbanzos Especiados */}
            {upgrades.unlockedToppings.includes('pollo_tandoori') ? (
              <button
                onClick={() => setSelectedTool('pollo_tandoori')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'pollo_tandoori'
                    ? 'bg-rose-50 border-rose-500 shadow-xs ring-2 ring-rose-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="pollo_tandoori" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Pollo Tandoori</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.pollo_tandoori.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'pollo_tandoori').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'pollo_tandoori').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Pollo Tandoori</div>
                  <div className="text-[9px] text-stone-400">Tienda (Día 4+)</div>
                </div>
              </div>
            )}

            {/* Hojas de Cilantro y Menta */}
            {upgrades.unlockedToppings.includes('cilantro_menta') ? (
              <button
                onClick={() => setSelectedTool('cilantro_menta')}
                className={`relative flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                  selectedTool === 'cilantro_menta'
                    ? 'bg-emerald-50 border-emerald-600 shadow-xs ring-2 ring-emerald-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}
              >
                <svg viewBox="-18 -18 36 36" className="w-8 h-8 shrink-0">
                  <ToppingSprite type="cilantro_menta" />
                </svg>
                <div className="truncate">
                  <div className="text-xs font-bold text-stone-900 leading-tight">Cilantro y Menta</div>
                  <div className="text-[10px] text-stone-500 font-mono">${TOPPING_COSTS.cilantro_menta.toFixed(2)} c/u</div>
                </div>
                {pizza.toppings.filter((t) => t.type === 'cilantro_menta').length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-mono font-black flex items-center justify-center shadow">
                    {pizza.toppings.filter((t) => t.type === 'cilantro_menta').length}
                  </span>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2 p-2 rounded-lg border border-dashed border-stone-300 bg-stone-100/70 opacity-60">
                <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center text-xs shrink-0">🔒</div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-stone-500 leading-tight">Cilantro y Menta</div>
                  <div className="text-[9px] text-stone-400">Tienda (Día 4+)</div>
                </div>
              </div>
            )}
            </div>
          </WoodParchmentBoard>

          {/* Quick Counter Info */}
          <WoodParchmentBoard variant="plank" compact showHerbs={false} showDoodles={false}>
            <div className="text-[11px] text-[#3A1E0D] font-semibold flex items-start gap-1.5">
              <AlertCircle className="w-4 h-4 text-[#9A231B] shrink-0 mt-0.5" />
              <span>
                Haz clic o arrastra para esparcir salsa o colocar rodajas. El costo se resta de tus fondos al usarlos.
              </span>
            </div>
          </WoodParchmentBoard>
        </div>
      </div>
    </div>
  );
};
