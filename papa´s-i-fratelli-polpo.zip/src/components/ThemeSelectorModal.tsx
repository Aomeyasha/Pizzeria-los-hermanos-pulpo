import React from 'react';
import { GameTheme, THEMES, ThemeId } from '../types/theme';
import { Palette, Check, X, Sparkles } from 'lucide-react';
import { sounds } from '../services/soundEffects';

interface ThemeSelectorModalProps {
  currentThemeId: ThemeId;
  onSelectTheme: (id: ThemeId) => void;
  onClose: () => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  currentThemeId,
  onSelectTheme,
  onClose,
}) => {
  const themeList = Object.values(THEMES);

  const handleChoose = (id: ThemeId) => {
    sounds.playChaChing();
    onSelectTheme(id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none animate-in fade-in">
      <div className="relative w-full max-w-xl bg-[#FAF5EE] rounded-3xl border-4 border-[#8C6D52] shadow-2xl overflow-hidden flex flex-col text-stone-800">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#8C6D52] text-white">
          <div className="flex items-center gap-2.5">
            <Palette className="w-6 h-6 text-amber-300" />
            <div>
              <h2 className="text-xl font-display font-bold">Personalizador de Estética</h2>
              <p className="text-xs text-amber-200">Elige el estilo visual y colores de tu restaurante</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-amber-200 hover:text-white hover:bg-black/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Informational Banner */}
        <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 flex items-center gap-2 text-xs text-amber-900 font-medium">
          <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            ¡Todo es 100% personalizable! Elige un tema aquí o dime qué colores, estilo de dibujo o vibra prefieres.
          </span>
        </div>

        {/* Theme List */}
        <div className="p-6 space-y-3 max-h-[60vh] overflow-y-auto">
          {themeList.map((t) => {
            const isSelected = t.id === currentThemeId;
            return (
              <button
                key={t.id}
                onClick={() => handleChoose(t.id)}
                className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-white border-amber-600 shadow-md ring-2 ring-amber-300/60 scale-[1.01]'
                    : 'bg-white/80 hover:bg-white border-stone-200 hover:border-amber-300 shadow-2xs'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner border border-black/10 shrink-0"
                    style={{ backgroundColor: t.previewColor }}
                  >
                    {t.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-display font-bold text-base text-stone-900">
                        {t.name}
                      </h3>
                      {isSelected && (
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                          <Check className="w-3 h-3" /> Activo
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">
                      {t.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 pl-3">
                  <div className="w-4 h-4 rounded-full border border-stone-300" style={{ backgroundColor: t.previewColor }} />
                  <div className="w-4 h-4 rounded-full border border-stone-300" style={{ backgroundColor: t.headerBg }} />
                  <div className="w-4 h-4 rounded-full border border-stone-300" style={{ backgroundColor: t.bodyBg }} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-[#F4ECE1] border-t border-[#DFD3C3] flex items-center justify-between">
          <span className="text-xs text-stone-500">
            Cambio inmediato sin perder tu progreso ni tus monedas
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-stone-800 hover:bg-stone-900 text-white font-display font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Aplicar y Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
