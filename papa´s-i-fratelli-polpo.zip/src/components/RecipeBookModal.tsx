import React from 'react';
import { BookOpen, CheckCircle2, Flame, Scissors, Lock } from 'lucide-react';
import { ToppingType } from '../types/pizza';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import {
  EGYPTIAN_PIZZA_TOPPINGS,
  RUEDA_MAHARAJA_TOPPINGS,
  isEgyptianPizzaEnabled,
} from '../data/customers';

interface RecipeBookModalProps {
  day?: number;
  unlockedToppings?: ToppingType[];
  naanVerdeFlour?: boolean;
  onClose: () => void;
}

export const RecipeBookModal: React.FC<RecipeBookModalProps> = ({
  day = 1,
  unlockedToppings = [],
  naanVerdeFlour = false,
  onClose,
}) => {
  const isDay3OrMore = day >= 3;
  const isDay4OrMore = day >= 4;
  const egyptianOwnedCount = EGYPTIAN_PIZZA_TOPPINGS.filter((t) =>
    unlockedToppings.includes(t)
  ).length;
  const egyptianReady = isEgyptianPizzaEnabled(unlockedToppings);

  const maharajaOwnedCount =
    (naanVerdeFlour ? 1 : 0) +
    RUEDA_MAHARAJA_TOPPINGS.filter((t) => unlockedToppings.includes(t)).length;
  const maharajaReady =
    naanVerdeFlour &&
    RUEDA_MAHARAJA_TOPPINGS.every((t) => unlockedToppings.includes(t));

  const recipes = [
    {
      name: 'Pizza de Mamut (Especial de Otra Era)',
      description: 'La especialidad favorita de clientes modernos y de cavernícolas (desde el Día 2).',
      ingredients: 'Salsa roja + Queso Mozzarella + Carne de Mamut (OBLIGATORIO) + 1 o 2 toppings extra al gusto (1 a 6 unidades c/u)',
      bake: '1 pasada (Doradita)',
      cuts: '2, 4, 6 u 8 porciones según el pedido',
      hint: '¡Siempre lleva Carne de Mamut obligatoria! Los cavernícolas muestran porciones [ | | | | ] y toppings con rayitas (|); cuenta las rayitas o pulsa "¿Qué?" en el mostrador.',
    },
    {
      name: 'Visitantes Egipcios: Faraón y Momia (Día 3+)',
      description: 'Miden la harina usando medidas del cuerpo en lugar de la gramera digital.',
      ingredients: '🖐️ 1 Mano Extendida (2 puñados = Pequeña) · 💪 1 Codo (4 puñados = Mediana) · 💪💪 2 Codos (6 puñados = Familiar)',
      bake: '1 pasada (Doradita)',
      cuts: '2, 4, 6 u 8 porciones según el pedido',
      hint: 'En la Sala de Masa aparecerá la silueta punteada corporal sin gramera. Al entregar el pedido, la cocina vuelve automáticamente a la gramera normal.',
    },
    {
      name: 'Sabio Matemático de la India (El Cero · Día 4+)',
      description: 'Nuevo invitado permanente desde el Día 4. Usa la gramera normal y reta con el número 0.',
      ingredients: 'Salsa roja + Queso Mozzarella + 0 unidades de los ingredientes descartados + 2, 3 o 4 unidades exactas de cada ingrediente de su lista que NO nombró',
      bake: '1 pasada (Doradita)',
      cuts: '4, 6 u 8 porciones según el pedido',
      hint: 'El 0 significa NINGUNO. No pongas los que pide con 0 y coloca la cantidad exacta que indica en los demás ingredientes de su lista.',
    },
    {
      name: 'Pizza de Queso Clásica',
      description: 'La favorita de los niños y tradicionalistas.',
      ingredients: 'Salsa roja + Queso Mozzarella',
      bake: '1 pasada (Doradita)',
      cuts: '6 porciones',
      hint: 'Asegúrate de cubrir bien toda la masa con salsa y queso.',
    },
    {
      name: 'Pizza de Pepperoni',
      description: 'El clásico indiscutible de cualquier pizzería.',
      ingredients: 'Salsa roja + Queso + Pepperoni (18 rodajas)',
      bake: '1 pasada',
      cuts: '6 porciones',
      hint: 'Distribuye unas 3 rodajas por porción usando la guía.',
    },
    {
      name: 'Pizza Margherita Auténtica',
      description: 'El desafío favorito de Alicante.',
      ingredients: 'Salsa roja + Queso + Hojas de Albahaca fresca',
      bake: '2 pasadas (Bien cocida / Crujiente)',
      cuts: '6 porciones',
      hint: 'Pásala dos veces por el horno para que las hojas y el borde queden crujientes.',
    },
    {
      name: 'Pizza Vegetariana / Bosque',
      description: 'Frescura natural sin ningún producto de carne.',
      ingredients: 'Salsa roja + Queso (opcional si es vegana) + Champiñones + Aceitunas',
      bake: '1 pasada',
      cuts: '6 porciones',
      hint: 'Si el cliente dice "¡Cero animales o vegana!", ¡NO le pongas queso!',
    },
    {
      name: 'Pizza Amante de la Carne',
      description: 'Para los clientes con apetito voraz.',
      ingredients: 'Salsa roja + Queso + Pepperoni + Salchicha italiana',
      bake: '1 pasada',
      cuts: '6 porciones',
      hint: 'Tanto pepperoni como salchicha bien repartidos por toda la pizza.',
    },
    {
      name: 'Pizza Mitad y Mitad',
      description: 'Equilibrio simétrico.',
      ingredients: 'Salsa y queso en toda; Pepperoni a la izquierda, Champiñones a la derecha',
      bake: '1 pasada',
      cuts: '6 porciones',
      hint: 'Usa la línea de división central y no cruces los ingredientes al otro lado.',
    },
    {
      name: 'El Pan Plano del Poeta',
      description: 'El acertijo filosófico del trigo sagrado.',
      ingredients: 'Solo Masa cruda (SIN salsa, SIN queso, SIN toppings)',
      bake: '2 pasadas (Bien cocida)',
      cuts: '4 porciones',
      hint: '"Que el trigo sienta el calor dos veces": métela directo al horno 2 veces sin tocar salsas.',
    },
    {
      name: 'Pizza Blanca Minimalista',
      description: 'Sabor puro a lácteos.',
      ingredients: 'Solo Queso Mozzarella (SIN salsa de tomate)',
      bake: '1 pasada',
      cuts: '4 porciones',
      hint: 'Si te piden pizza blanca, omite por completo la salsa roja.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/65 backdrop-blur-xs select-none animate-in fade-in">
      <WoodParchmentBoard
        variant="horizontal"
        onClose={onClose}
        closeTitle="Cerrar Libro de Recetas"
        className="w-full max-w-2xl"
        innerClassName="max-h-[82vh] overflow-hidden p-0!"
      >
        {/* Parchment Header Banner */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 bg-[#E7CFA2]/70 border-b-2 border-[#C8A16B]/70 text-[#3A1E0D]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#8C4D1E] text-amber-200 border border-[#5D290D] shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-display font-bold text-[#3A1E0D]">Libro de Recetas del Chef</h2>
              <p className="text-xs text-[#6E4427] font-semibold">Guía de pedidos y acertijos de la clientela (Día {day})</p>
            </div>
          </div>
        </div>

        {/* Recipes Scrollable Grid */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          {/* Egyptian Reference Chart Banner */}
          <div className="bg-amber-50 p-4 rounded-2xl border-2 border-amber-300 shadow-2xs flex flex-col sm:flex-row items-center gap-4">
            <img
              src="/assets/aistudio/image_4a13d1bc.png"
              alt="Siluetas Egipcias: 1 Mano Extendida, 1 Codo y 2 Codos"
              className="w-full sm:w-44 h-24 object-cover rounded-xl border border-sky-300 bg-[#BCE3F7] shrink-0"
            />
            <div className="text-xs text-amber-950 space-y-1">
              <div className="font-display font-bold text-sm text-amber-900">
                🏛️ Tabla de Medidas Corporales (Faraón y Momia · Día 3+)
              </div>
              <p className="font-medium leading-relaxed">
                <strong>🖐️ 1 Mano Extendida:</strong> 2 puñados (Pequeña) ·{' '}
                <strong>💪 1 Codo:</strong> 4 puñados (Mediana) ·{' '}
                <strong>💪💪 2 Codos:</strong> 6 puñados (Familiar).
              </p>
            </div>
          </div>

          {/* Pizza Egipcia Recipe Card (Available from Day 3 onward) */}
          {isDay3OrMore ? (
            <div className="bg-gradient-to-br from-[#FFFBEB] to-[#FEF3C7] p-4 rounded-2xl border-2 border-amber-500 shadow-sm space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display font-bold text-base text-amber-950 flex items-center gap-1.5">
                  <span>🏺</span>
                  Pizza Egipcia (Especial del Nilo · Día 3+)
                </h3>
                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${
                    egyptianReady
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-400'
                      : 'bg-white text-amber-900 border-amber-400'
                  }`}
                >
                  {egyptianReady
                    ? '✅ Habilitada para clientes'
                    : `🔒 Compra ingredientes en Tienda (${egyptianOwnedCount}/4)`}
                </span>
              </div>

              <p className="text-xs text-amber-950/90 font-medium">
                Receta desbloqueada desde el Día 3. Una vez que compres sus 4 ingredientes en la Tienda, cualquier personaje (moderno, cavernícola, faraón, momia o clásico) podrá pedirla.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="bg-white/90 p-2.5 rounded-xl border border-amber-300">
                  <strong className="text-[10px] uppercase text-amber-800 block mb-0.5">
                    Toppings Principales:
                  </strong>
                  <span className="text-stone-900 font-semibold">
                    Salsa roja + Mozzarella + Puerros y cebollas moradas caramelizadas + Trozos de higos frescos o dátiles + Tiras de pato asado o pescado ahumado del Nilo.
                  </span>
                </div>
                <div className="bg-white/90 p-2.5 rounded-xl border border-amber-300">
                  <strong className="text-[10px] uppercase text-amber-800 block mb-0.5">
                    El Toque Final & Horneado:
                  </strong>
                  <span className="text-stone-900 font-semibold block">
                    Un hilo de miel pura antes de servir y semillas de sésamo tostadas en los bordes.
                  </span>
                  <span className="text-[11px] text-amber-900 font-bold mt-1 block">
                    🔥 1 pasada (Doradita) · ✂️ 4, 6 u 8 porciones
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-amber-950 bg-white/80 p-2 rounded-lg border border-amber-300 flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Truco del Chef:</strong>{' '}
                  {egyptianReady
                    ? '¡Ya tienes todos sus ingredientes! Coloca los 3 toppings principales y termina con Miel y Sésamo en la sección de Toppings.'
                    : 'Ve a la Tienda de Mejoras y compra Puerros/Cebollas, Higos/Dátiles, Pato/Pescado del Nilo y Miel con Sésamo para habilitarla.'}
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-stone-100 p-4 rounded-2xl border-2 border-dashed border-stone-300 flex items-center justify-between gap-3 opacity-85">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-stone-200 flex items-center justify-center text-stone-600 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm text-stone-800">
                    🏺 Pizza Egipcia (Receta Secreta)
                  </h3>
                  <p className="text-xs text-stone-600">
                    Esta receta estará disponible en el menú a partir del <strong>Día 3</strong>.
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-stone-200 text-stone-700 shrink-0">
                Día 3
              </span>
            </div>
          )}

          {/* Rueda de Maharajá Recipe Card (Available from Day 4 onward) */}
          {isDay4OrMore ? (
            <div className="bg-gradient-to-br from-[#ECFDF5] to-[#D1FAE5] p-4 rounded-2xl border-2 border-emerald-500 shadow-sm space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display font-bold text-base text-emerald-950 flex items-center gap-1.5">
                  <span>🛞</span>
                  Rueda de Maharajá (Base Naan Verde · Día 4+)
                </h3>
                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${
                    maharajaReady
                      ? 'bg-emerald-200 text-emerald-950 border-emerald-500'
                      : 'bg-white text-emerald-900 border-emerald-400'
                  }`}
                >
                  {maharajaReady
                    ? '✅ Habilitada para clientes'
                    : `🔒 Compra harina verde e ingredientes (${maharajaOwnedCount}/4)`}
                </span>
              </div>

              <p className="text-xs text-emerald-950/90 font-medium">
                Receta desbloqueada desde el Día 4. Primero selecciona la <strong>Harina Naan Verde</strong> en el mostrador de <strong>Masa</strong> (color verde, pan plano fermentado con ghee y ajo picado).
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="bg-white/90 p-2.5 rounded-xl border border-emerald-300">
                  <strong className="text-[10px] uppercase text-emerald-800 block mb-0.5">
                    Base Naan Verde & Toppings:
                  </strong>
                  <span className="text-stone-900 font-semibold">
                    Harina Naan Verde (con ghee y ajo, SIN salsa roja ni mozzarella) + Queso Paneer + Pollo Tandoori (o garbanzos especiados) + Hojas de cilantro y menta.
                  </span>
                </div>
                <div className="bg-white/90 p-2.5 rounded-xl border border-emerald-300">
                  <strong className="text-[10px] uppercase text-emerald-800 block mb-0.5">
                    Horneado a Alta Temperatura:
                  </strong>
                  <span className="text-stone-900 font-semibold block">
                    Hornear 2 veces para lograr bordes dorados y burbujas crujientes.
                  </span>
                  <span className="text-[11px] text-emerald-900 font-bold mt-1 block">
                    🔥 2 pasadas (Alta Temp.) · ✂️ 4, 6 u 8 porciones
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-emerald-950 bg-white/80 p-2 rounded-lg border border-emerald-300 flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Truco del Chef:</strong>{' '}
                  {maharajaReady
                    ? 'En la estación de Masa cambia al saco de Harina Naan Verde antes de pesar, moldea en círculo, aplica Paneer + Pollo Tandoori + Cilantro y Menta (sin salsa roja), y hornea 2 veces.'
                    : 'Ve a la Tienda de Mejoras y compra la Harina Naan Verde, Queso Paneer, Pollo Tandoori y Cilantro y Menta para habilitarla.'}
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-stone-100 p-4 rounded-2xl border-2 border-dashed border-stone-300 flex items-center justify-between gap-3 opacity-85">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-stone-200 flex items-center justify-center text-stone-600 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm text-stone-800">
                    🛞 Rueda de Maharajá (Receta Secreta)
                  </h3>
                  <p className="text-xs text-stone-600">
                    Esta receta, la Harina Naan Verde y sus ingredientes estarán disponibles desde el <strong>Día 4</strong>.
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-stone-200 text-stone-700 shrink-0">
                Día 4
              </span>
            </div>
          )}

          {recipes.map((rec, i) => (
            <div
              key={i}
              className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-2 hover:border-amber-300 transition-colors"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display font-bold text-base text-stone-900">
                  {rec.name}
                </h3>
                <span className="text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-full">
                  Receta #{i + 1}
                </span>
              </div>
              <p className="text-xs text-stone-500">{rec.description}</p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-xs">
                <div className="bg-[#FAF5EE] p-2 rounded-lg border border-[#E9DAC6]">
                  <strong className="text-[10px] uppercase text-stone-500 block">Ingredientes:</strong>
                  <span className="text-stone-800 font-medium">{rec.ingredients}</span>
                </div>
                <div className="bg-[#FAF5EE] p-2 rounded-lg border border-[#E9DAC6]">
                  <strong className="text-[10px] uppercase text-stone-500 block flex items-center gap-1">
                    <Flame className="w-3 h-3 text-orange-600" /> Horneado:
                  </strong>
                  <span className="text-stone-800 font-medium">{rec.bake}</span>
                </div>
                <div className="bg-[#FAF5EE] p-2 rounded-lg border border-[#E9DAC6]">
                  <strong className="text-[10px] uppercase text-stone-500 block flex items-center gap-1">
                    <Scissors className="w-3 h-3 text-purple-600" /> Cortes:
                  </strong>
                  <span className="text-stone-800 font-medium">{rec.cuts}</span>
                </div>
              </div>

              <div className="text-[11px] text-amber-900 bg-amber-50/80 p-2 rounded-lg border border-amber-200 flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                <span><strong>Truco del Chef:</strong> {rec.hint}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3.5 bg-[#E7CFA2]/70 border-t-2 border-[#C8A16B]/70 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            OK · A Cocinar
          </button>
        </div>
      </WoodParchmentBoard>
    </div>
  );
};
