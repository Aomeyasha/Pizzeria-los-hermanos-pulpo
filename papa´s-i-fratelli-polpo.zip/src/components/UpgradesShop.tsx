import React from 'react';
import { GameUpgrades, ToppingType } from '../types/pizza';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import {
  EGYPTIAN_PIZZA_TOPPINGS,
  RUEDA_MAHARAJA_TOPPINGS,
  isEgyptianPizzaEnabled,
  isRuedaMaharajaEnabled,
} from '../data/customers';
import { ToppingSprite } from './ToppingSprite';
import { ShoppingBag, Check, Flame, Scissors, Eye, Sparkles, Palette, Lock } from 'lucide-react';

interface UpgradesShopProps {
  cash: number;
  day?: number;
  upgrades: GameUpgrades;
  onBuyUpgrade: (cost: number, upgradeKey: keyof GameUpgrades, value: any) => void;
  onUnlockTopping: (cost: number, topping: ToppingType) => void;
  onClose: () => void;
}

export const UpgradesShop: React.FC<UpgradesShopProps> = ({
  cash,
  day = 1,
  upgrades,
  onBuyUpgrade,
  onUnlockTopping,
  onClose,
}) => {
  const egyptianOwnedCount = EGYPTIAN_PIZZA_TOPPINGS.filter((t) =>
    upgrades.unlockedToppings.includes(t)
  ).length;
  const egyptianEnabled = isEgyptianPizzaEnabled(upgrades.unlockedToppings);

  const maharajaAvailableInShop = day >= 4;
  const maharajaOwnedCount =
    (upgrades.naanVerdeFlour ? 1 : 0) +
    RUEDA_MAHARAJA_TOPPINGS.filter((t) => upgrades.unlockedToppings.includes(t)).length;
  const maharajaEnabled = isRuedaMaharajaEnabled(upgrades);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/65 backdrop-blur-xs select-none animate-in fade-in">
      <WoodParchmentBoard
        variant="horizontal"
        onClose={onClose}
        closeTitle="Cerrar Tienda"
        className="w-full max-w-2xl"
        innerClassName="max-h-[82vh] overflow-hidden p-0!"
      >
        {/* Parchment Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 bg-[#E7CFA2]/70 border-b-2 border-[#C8A16B]/70 text-[#3A1E0D] pr-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#8C4D1E] text-amber-200 border border-[#5D290D] shadow-xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-display font-bold text-[#3A1E0D]">Tienda de Mejoras</h2>
              <p className="text-xs text-[#6E4427] font-semibold">Equipa tu pizzería para atender mejor y más rápido</p>
            </div>
          </div>
          <div className="bg-[#5D290D] px-3.5 py-1.5 rounded-xl font-mono text-sm font-bold text-amber-300 border border-[#8C5528] shadow-xs">
            Fondos: ${cash.toFixed(2)}
          </div>
        </div>

        {/* Shop Items Scrollable List */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* Section 1: Nuevos Ingredientes */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-600" />
              Nuevos Ingredientes para la Carta
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Carne de Mamut */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 border border-orange-200 flex items-center justify-center p-1">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="carne_mamut" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Carne de Mamut</h4>
                    <p className="text-[11px] text-stone-500">Obligatoria para Pizza de Mamut</p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('carne_mamut') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(25.0, 'carne_mamut')}
                    disabled={cash < 25.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer"
                  >
                    $25.00
                  </button>
                )}
              </div>

              {/* Piña */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-yellow-50 border border-yellow-200 flex items-center justify-center p-1">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="pina" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Piña</h4>
                    <p className="text-[11px] text-stone-500">Trozos dorados dulces y frescos</p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('pina') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(20.0, 'pina')}
                    disabled={cash < 20.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer"
                  >
                    $20.00
                  </button>
                )}
              </div>

              {/* Queso Extra */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center p-1">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="queso_extra" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Queso Extra</h4>
                    <p className="text-[11px] text-stone-500">Medallones extra de mozzarella</p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('queso_extra') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(22.0, 'queso_extra')}
                    disabled={cash < 22.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer"
                  >
                    $22.00
                  </button>
                )}
              </div>

              {/* Basil */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-xl">
                    🌿
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Albahaca Fresca</h4>
                    <p className="text-[11px] text-stone-500">Para Margherita y pizzas veganas</p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('basil') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(30.0, 'basil')}
                    disabled={cash < 30.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $30.00
                  </button>
                )}
              </div>

              {/* Sausage */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-xl">
                    🥩
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Salchicha Italiana</h4>
                    <p className="text-[11px] text-stone-500">Para los amantes de la carne</p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('sausage') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(40.0, 'sausage')}
                    disabled={cash < 40.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $40.00
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 1B: Ingredientes de la Pizza Egipcia (Día 3+) */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border-2 border-amber-300/80">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-950 flex items-center gap-2">
                <span>🏺</span>
                Ingredientes — Pizza Egipcia (Disponible desde el Día 3)
              </h3>
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${
                  egyptianEnabled
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : 'bg-white text-amber-900 border-amber-300'
                }`}
              >
                {egyptianEnabled
                  ? day >= 3
                    ? '✅ ¡Habilitada! Cualquier cliente puede pedirla'
                    : '✅ Lista (los clientes la pedirán desde el Día 3)'
                  : `🔒 ${egyptianOwnedCount}/4 comprados para habilitarla`}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Puerros y Cebollas Moradas */}
              <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="puerro_cebolla" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Puerros y Cebollas Moradas
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Caramelizadas · Topping principal
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('puerro_cebolla') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(18.0, 'puerro_cebolla')}
                    disabled={cash < 18.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $18.00
                  </button>
                )}
              </div>

              {/* Higos Frescos y Dátiles */}
              <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="higos_datiles" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Higos Frescos y Dátiles
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Trozos dulces · Topping principal
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('higos_datiles') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(20.0, 'higos_datiles')}
                    disabled={cash < 20.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $20.00
                  </button>
                )}
              </div>

              {/* Pato Asado / Pescado del Nilo */}
              <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 border border-orange-200 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="pato_pescado" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Pato Asado / Pescado Nilo
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Tiras ahumadas · Topping principal
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('pato_pescado') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(24.0, 'pato_pescado')}
                    disabled={cash < 24.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $24.00
                  </button>
                )}
              </div>

              {/* Miel Pura y Sésamo Tostado */}
              <div className="bg-white p-3.5 rounded-2xl border border-amber-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-yellow-50 border border-yellow-300 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="miel_sesamo" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Miel Pura y Sésamo Tostado
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Toque final en bordes y superficie
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('miel_sesamo') ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(16.0, 'miel_sesamo')}
                    disabled={cash < 16.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $16.00
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 1C: Rueda de Maharajá — Harina Naan Verde & Toppings (Día 4+) */}
          <div className="bg-emerald-50/75 p-4 rounded-2xl border-2 border-emerald-400/80">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
                <span>🛞</span>
                Rueda de Maharajá — Harina Verde e Ingredientes (Día 4+)
              </h3>
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${
                  !maharajaAvailableInShop
                    ? 'bg-stone-100 text-stone-700 border-stone-300'
                    : maharajaEnabled
                    ? 'bg-emerald-200 text-emerald-950 border-emerald-500'
                    : 'bg-white text-emerald-900 border-emerald-400'
                }`}
              >
                {!maharajaAvailableInShop
                  ? '🔒 Disponible en Tienda desde el Día 4'
                  : maharajaEnabled
                  ? '✅ ¡Habilitada! Clientes pueden pedirla'
                  : `🔓 ${maharajaOwnedCount}/4 comprados para habilitarla`}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Harina Naan Verde (Ghee y Ajo) */}
              <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 border-2 border-emerald-500 flex items-center justify-center shrink-0">
                    <span className="w-5 h-5 rounded-full bg-emerald-500 border border-emerald-800 shadow-inner" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Harina Naan Verde
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Color verde · Base Naan con ghee y ajo
                    </p>
                  </div>
                </div>
                {upgrades.naanVerdeFlour ? (
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : !maharajaAvailableInShop ? (
                  <span className="text-[11px] font-bold text-stone-500 flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg shrink-0">
                    <Lock className="w-3 h-3" /> Día 4
                  </span>
                ) : (
                  <button
                    onClick={() => onBuyUpgrade(22.0, 'naanVerdeFlour', true)}
                    disabled={cash < 22.0}
                    className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $22.00
                  </button>
                )}
              </div>

              {/* Queso Paneer */}
              <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="queso_paneer" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Queso Paneer
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Cubos artesanales dorados al horno
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('queso_paneer') ? (
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : !maharajaAvailableInShop ? (
                  <span className="text-[11px] font-bold text-stone-500 flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg shrink-0">
                    <Lock className="w-3 h-3" /> Día 4
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(18.0, 'queso_paneer')}
                    disabled={cash < 18.0}
                    className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $18.00
                  </button>
                )}
              </div>

              {/* Pollo Tandoori o Garbanzos Especiados */}
              <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="pollo_tandoori" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Pollo Tandoori / Garbanzos
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Especiado asado al estilo tandoor
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('pollo_tandoori') ? (
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : !maharajaAvailableInShop ? (
                  <span className="text-[11px] font-bold text-stone-500 flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg shrink-0">
                    <Lock className="w-3 h-3" /> Día 4
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(22.0, 'pollo_tandoori')}
                    disabled={cash < 22.0}
                    className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $22.00
                  </button>
                )}
              </div>

              {/* Hojas de Cilantro y Menta */}
              <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-300 flex items-center justify-center p-1 shrink-0">
                    <svg viewBox="-18 -18 36 36" className="w-8 h-8">
                      <ToppingSprite type="cilantro_menta" />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 leading-tight">
                      Hojas de Cilantro y Menta
                    </h4>
                    <p className="text-[11px] text-stone-500 leading-tight">
                      Toque fresco aromático de la India
                    </p>
                  </div>
                </div>
                {upgrades.unlockedToppings.includes('cilantro_menta') ? (
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg shrink-0">
                    <Check className="w-3.5 h-3.5" /> Adquirido
                  </span>
                ) : !maharajaAvailableInShop ? (
                  <span className="text-[11px] font-bold text-stone-500 flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg shrink-0">
                    <Lock className="w-3 h-3" /> Día 4
                  </span>
                ) : (
                  <button
                    onClick={() => onUnlockTopping(14.0, 'cilantro_menta')}
                    disabled={cash < 14.0}
                    className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono cursor-pointer shrink-0"
                  >
                    $14.00
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Maquinaria y Ayudantes */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-600" />
              Maquinaria y Ayudantes de Cocina
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Fast Oven */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-orange-600">
                    <Flame className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Horno Rápido Turbo</h4>
                    <p className="text-[11px] text-stone-500">Hornea un 45% más veloz</p>
                  </div>
                </div>
                {upgrades.fastOven ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Instalado
                  </span>
                ) : (
                  <button
                    onClick={() => onBuyUpgrade(45.0, 'fastOven', true)}
                    disabled={cash < 45.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $45.00
                  </button>
                )}
              </div>

              {/* Auto Sauce & Cheese */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-600">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Auto Salsa & Queso</h4>
                    <p className="text-[11px] text-stone-500">Dispensado perfecto con 1 clic</p>
                  </div>
                </div>
                {upgrades.autoSauceCheese ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Instalado
                  </span>
                ) : (
                  <button
                    onClick={() => onBuyUpgrade(65.0, 'autoSauceCheese', true)}
                    disabled={cash < 65.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $65.00
                  </button>
                )}
              </div>

              {/* Topping Placement Guide */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-600">
                    <Eye className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Guía de 18 Toppings</h4>
                    <p className="text-[11px] text-stone-500">Marcadores de colocación exacta</p>
                  </div>
                </div>
                {upgrades.toppingGuide ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Instalado
                  </span>
                ) : (
                  <button
                    onClick={() => onBuyUpgrade(25.0, 'toppingGuide', true)}
                    disabled={cash < 25.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $25.00
                  </button>
                )}
              </div>

              {/* Cutting Guide */}
              <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-600">
                    <Scissors className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900">Guía de Corte Radial</h4>
                    <p className="text-[11px] text-stone-500">Líneas de simetría en corte</p>
                  </div>
                </div>
                {upgrades.cutterGuide ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <Check className="w-3.5 h-3.5" /> Instalado
                  </span>
                ) : (
                  <button
                    onClick={() => onBuyUpgrade(20.0, 'cutterGuide', true)}
                    disabled={cash < 20.0}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                  >
                    $20.00
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: Decoración Acogedora */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-600" />
              Ambiente y Decoración
            </h3>
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-600">
                  <Palette className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-stone-900">
                    Decoración Acogedora {upgrades.cozyDecorLevel > 0 ? `(Nivel ${upgrades.cozyDecorLevel}/3)` : ''}
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Plantas, cuadros vintage y luces cálidas. Los clientes son un 15% más pacientes.
                  </p>
                </div>
              </div>
              {upgrades.cozyDecorLevel >= 3 ? (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg">
                  <Check className="w-3.5 h-3.5" /> Máximo
                </span>
              ) : (
                <button
                  onClick={() => onBuyUpgrade(25.0, 'cozyDecorLevel', upgrades.cozyDecorLevel + 1)}
                  disabled={cash < 25.0}
                  className="px-3 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-400 text-white rounded-lg shadow-2xs transition-all font-mono"
                >
                  $25.00
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3.5 bg-[#E7CFA2]/70 border-t-2 border-[#C8A16B]/70 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            OK · Volver
          </button>
        </div>
      </WoodParchmentBoard>
    </div>
  );
};
