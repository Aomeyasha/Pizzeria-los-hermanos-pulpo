import React, { useState, useRef } from 'react';
import { CustomerOrder, GameUpgrades, PizzaState } from '../types/pizza';
import { sounds } from '../services/soundEffects';
import { ToppingSprite } from './ToppingSprite';
import { PizzaBaseLayers } from './PizzaShapeSVG';
import { CATALOGO_TAMANOS, ICONOS_FORMA } from '../utils/pizzaGeometry';
import { ArrowLeft, CheckCircle2, RotateCcw, Scissors, Sparkles } from 'lucide-react';
import { WoodParchmentBoard } from './WoodParchmentBoard';

interface CuttingStationProps {
  pizza: PizzaState;
  order: CustomerOrder | null;
  upgrades: GameUpgrades;
  onUpdatePizza: (updater: (prev: PizzaState) => PizzaState) => void;
  onServePizza: () => void;
  onBackToOven: () => void;
}

export const CuttingStation: React.FC<CuttingStationProps> = ({
  pizza,
  order,
  upgrades,
  onUpdatePizza,
  onServePizza,
  onBackToOven,
}) => {
  const [isDrawingCut, setIsDrawingCut] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [dragCurrent, setDragCurrent] = useState<{ x: number; y: number } | null>(null);
  const [showCutGuide, setShowCutGuide] = useState(upgrades.cutterGuide);
  const [isBoxing, setIsBoxing] = useState(false);

  const cutSvgRef = useRef<SVGSVGElement | null>(null);

  const getSvgCoords = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!cutSvgRef.current) return null;
    const rect = cutSvgRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    return { x, y };
  };

  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    const coords = getSvgCoords(e);
    if (!coords) return;
    setIsDrawingCut(true);
    setDragStart(coords);
    setDragCurrent(coords);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isDrawingCut) return;
    const coords = getSvgCoords(e);
    if (coords) setDragCurrent(coords);
  };

  const handleMouseUp = () => {
    if (!isDrawingCut || !dragStart || !dragCurrent) {
      setIsDrawingCut(false);
      setDragStart(null);
      setDragCurrent(null);
      return;
    }

    // Check if the cut line is sufficiently long (at least 25% of pizza diameter)
    const dx = dragCurrent.x - dragStart.x;
    const dy = dragCurrent.y - dragStart.y;
    const length = Math.sqrt(dx * dx + dy * dy);

    if (length >= 35) {
      sounds.playPizzaCut();

      onUpdatePizza((prev) => {
        const newCuts = [...prev.cuts, { start: dragStart, end: dragCurrent }];
        // Estimate slices count from number of diametric cuts:
        // 0 cuts -> 1 slice (sin cortar)
        // 1 cut -> 2 slices
        // 2 cuts -> 4 slices
        // 3 cuts -> 6 slices
        // 4 cuts -> 8 slices
        const estimatedSlices = Math.min(12, newCuts.length === 0 ? 1 : newCuts.length * 2);

        return {
          ...prev,
          cuts: newCuts,
          slicesCount: estimatedSlices,
        };
      });
    }

    setIsDrawingCut(false);
    setDragStart(null);
    setDragCurrent(null);
  };

  // Helper quick-cut buttons (convenience for precision)
  const applyPresetCuts = (slices: number) => {
    sounds.playPizzaCut();
    let newCuts: { start: { x: number; y: number }; end: { x: number; y: number } }[] = [];

    if (slices === 2) {
      newCuts = [{ start: { x: 50, y: 5 }, end: { x: 50, y: 95 } }];
    } else if (slices === 4) {
      newCuts = [
        { start: { x: 50, y: 5 }, end: { x: 50, y: 95 } },
        { start: { x: 5, y: 50 }, end: { x: 95, y: 50 } },
      ];
    } else if (slices === 6) {
      newCuts = [
        { start: { x: 50, y: 5 }, end: { x: 50, y: 95 } },
        { start: { x: 15, y: 30 }, end: { x: 85, y: 70 } },
        { start: { x: 15, y: 70 }, end: { x: 85, y: 30 } },
      ];
    } else if (slices === 8) {
      newCuts = [
        { start: { x: 50, y: 5 }, end: { x: 50, y: 95 } },
        { start: { x: 5, y: 50 }, end: { x: 95, y: 50 } },
        { start: { x: 18, y: 18 }, end: { x: 82, y: 82 } },
        { start: { x: 18, y: 82 }, end: { x: 82, y: 18 } },
      ];
    }

    onUpdatePizza((prev) => ({
      ...prev,
      cuts: newCuts,
      slicesCount: slices,
    }));
  };

  const resetCuts = () => {
    onUpdatePizza((prev) => ({
      ...prev,
      cuts: [],
      slicesCount: 1,
    }));
  };

  const handleBoxAndDeliver = () => {
    setIsBoxing(true);
    sounds.playBoxSnap();
    setTimeout(() => {
      onServePizza();
    }, 600);
  };

  return (
    <div className="relative flex flex-col h-full bg-[#1A1412] select-none overflow-hidden">
      {/* Background: User Rustic Cutting Table Image */}
      <img
        src="/assets/aistudio/image.png_61090b2e_2K_b56e0ef5.jpg"
        alt="Mesa de Corte"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
      />
      {/* Soft vignette overlay */}
      <div className="absolute inset-0 bg-black/20 pointer-events-none" />

      {/* Top Controls Bar */}
      <div className="relative z-20 flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-[#FAF4EA]/90 backdrop-blur-md border-b border-[#E1D3C0]/40 shadow-md">
        <button
          onClick={onBackToOven}
          disabled={isBoxing}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-[#E6D8C4] hover:bg-[#DBCABA] rounded-lg transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver al Horno
        </button>

        {/* Preset Cutting Shortcuts */}
        <div className="flex items-center gap-1.5 p-1 bg-[#E4D5BF] rounded-lg">
          <span className="text-[11px] font-bold text-amber-950 px-2 flex items-center gap-1">
            <Scissors className="w-3.5 h-3.5" />
            Cortes:
          </span>
          <button
            onClick={() => applyPresetCuts(2)}
            className="px-2.5 py-1 text-xs font-semibold bg-white hover:bg-amber-50 text-stone-800 rounded-md shadow-2xs transition-colors"
          >
            2 Porciones
          </button>
          <button
            onClick={() => applyPresetCuts(4)}
            className="px-2.5 py-1 text-xs font-semibold bg-white hover:bg-amber-50 text-stone-800 rounded-md shadow-2xs transition-colors"
          >
            4 Porciones
          </button>
          <button
            onClick={() => applyPresetCuts(6)}
            className="px-2.5 py-1 text-xs font-semibold bg-white hover:bg-amber-50 text-stone-800 rounded-md shadow-2xs transition-colors"
          >
            6 Porciones
          </button>
          <button
            onClick={() => applyPresetCuts(8)}
            className="px-2.5 py-1 text-xs font-semibold bg-white hover:bg-amber-50 text-stone-800 rounded-md shadow-2xs transition-colors"
          >
            8 Porciones
          </button>
          <button
            onClick={resetCuts}
            className="p-1 text-stone-600 hover:text-stone-900 transition-colors"
            title="Borrar cortes"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Serve button */}
        <button
          onClick={handleBoxAndDeliver}
          disabled={isBoxing}
          className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-transform active:scale-95"
        >
          <CheckCircle2 className="w-4 h-4" />
          {isBoxing ? 'Cerrando Caja...' : 'Empacar y Servir'}
        </button>
      </div>

      {/* Main Cutting Board Arena */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-4 overflow-hidden">
        {/* Slice Counter & Shape/Size Indicator */}
        <WoodParchmentBoard
          variant="plank"
          compact
          showHerbs={false}
          showDoodles={false}
          className="mb-3"
          innerClassName="py-1.5! px-4!"
        >
          <div className="text-[#3A1E0D] text-xs font-semibold flex flex-wrap items-center justify-center gap-3">
            <span className="flex items-center gap-1 text-[#5D290D] font-bold">
              <span>{ICONOS_FORMA[pizza.shape]}</span>
              <span>{pizza.size} · {pizza.shape}</span>
            </span>
            <span className="border-l border-[#C8A16B] pl-3">
              Porciones actuales:{' '}
              <strong className="text-[#9A231B] font-mono text-sm">
                {pizza.cuts.length === 0 ? '1 (Sin cortar)' : `${pizza.slicesCount} rebanadas`}
              </strong>
            </span>
            {order && (
              <span className="text-[#6E4427] border-l border-[#C8A16B] pl-3">
                Pedido del cliente:{' '}
                <strong className="text-[#3A1E0D] font-mono">
                  {order.recipe.cuts === 0
                    ? 'Sin cortar'
                    : order.customerType === 'cavernicola'
                    ? `[ ${Array(order.recipe.cuts).fill('|').join(' ')} ] porciones`
                    : `${order.recipe.cuts} porciones`}
                </strong>
              </span>
            )}
          </div>
        </WoodParchmentBoard>

        {/* Cardboard Pizza Box & Cutting Table */}
        <div className="relative w-[340px] h-[340px] sm:w-[420px] sm:h-[420px] max-w-full flex items-center justify-center">
          {/* Cardboard Box Interior */}
          <div className="absolute inset-0 bg-[#CDB597] border-4 border-[#A3896D] rounded-2xl shadow-xl flex items-center justify-center overflow-hidden">
            {/* Box greaseproof paper liner */}
            <div className="w-[94%] h-[94%] bg-[#FAF6EE] rounded-xl border border-[#DECDB8] shadow-inner" />
          </div>

          {/* Closing Box Animation Flap */}
          {isBoxing && (
            <div className="absolute inset-0 z-30 bg-[#B89F82] border-4 border-[#8C7358] rounded-2xl flex flex-col items-center justify-center shadow-2xl transition-all duration-500 animate-in fade-in zoom-in-95">
              <div className="w-24 h-24 rounded-full border-4 border-[#8C7358] flex flex-col items-center justify-center text-center p-2">
                <span className="text-2xl">🐙</span>
                <span className="text-[9px] font-bold uppercase tracking-wider text-[#5A4532]">Papa´s Polpo</span>
              </div>
              <span className="text-xs font-bold text-[#5A4532] mt-3">¡Caja Lista!</span>
            </div>
          )}

          {/* Interactive SVG Pizza with Slicer drag lines */}
          <svg
            ref={cutSvgRef}
            viewBox="0 0 100 100"
            style={{ transform: `scale(${CATALOGO_TAMANOS[pizza.size]?.escalaVisual || 0.9})` }}
            className="relative z-10 w-[88%] h-[88%] cursor-crosshair overflow-visible select-none transition-transform duration-300"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <PizzaBaseLayers
              shape={pizza.shape}
              bakeLevel={pizza.bakeLevel}
              clipIdPrefix="cutting"
              doughType={pizza.dough}
              sauceApplied={pizza.sauce.applied}
              sauceCoverage={pizza.sauce.coverage}
              cheeseApplied={pizza.cheese.applied}
              cheeseCoverage={pizza.cheese.coverage}
              showCheeseFreckles={true}
              hasHoneySesameFinish={pizza.toppings.some((t) => t.type === 'miel_sesamo')}
            />

            {/* Toppings rendered */}
            {pizza.toppings.map((top) => (
              <ToppingSprite
                key={top.id}
                type={top.type}
                x={top.x}
                y={top.y}
                rotation={top.rotation}
                size={22}
                isBaked={pizza.bakeLevel >= 1}
              />
            ))}

            {/* Cutting Guides (faint dashed lines) */}
            {showCutGuide && (
              <g stroke="#0284C7" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.5" pointerEvents="none">
                <line x1="50" y1="6" x2="50" y2="94" />
                <line x1="6" y1="50" x2="94" y2="50" />
                <line x1="18" y1="18" x2="82" y2="82" />
                <line x1="18" y1="82" x2="82" y2="18" />
              </g>
            )}

            {/* Existing Blade Cuts */}
            {pizza.cuts.map((cut, idx) => (
              <g key={`cut-line-${idx}`} pointerEvents="none">
                {/* Dark indented cut seam */}
                <line
                  x1={cut.start.x}
                  y1={cut.start.y}
                  x2={cut.end.x}
                  y2={cut.end.y}
                  stroke="#2D1A0D"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                />
                {/* Fluffy dough rim highlight beside cut */}
                <line
                  x1={cut.start.x + 0.5}
                  y1={cut.start.y}
                  x2={cut.end.x + 0.5}
                  y2={cut.end.y}
                  stroke="#FDE68A"
                  strokeWidth="0.8"
                  opacity="0.6"
                />
              </g>
            ))}

            {/* Current Active Drag Cut Line */}
            {isDrawingCut && dragStart && dragCurrent && (
              <line
                x1={dragStart.x}
                y1={dragStart.y}
                x2={dragCurrent.x}
                y2={dragCurrent.y}
                stroke="#DC2626"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeDasharray="2 1"
                pointerEvents="none"
              />
            )}
          </svg>
        </div>

        {/* Cutter Instructions hint */}
        <WoodParchmentBoard
          variant="plank"
          compact
          showHerbs={false}
          showDoodles={false}
          className="mt-3"
          innerClassName="py-1.5! px-4!"
        >
          <p className="text-xs text-[#3A1E0D] font-semibold text-center">
            Arrastra el ratón de un extremo a otro para cortar a mano con la rueda cortadora, o pulsa los botones de porciones arriba.
          </p>
        </WoodParchmentBoard>
      </div>
    </div>
  );
};
