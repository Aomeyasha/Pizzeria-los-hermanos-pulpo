import React, { useState, useRef, useEffect } from 'react';
import {
  CustomerOrder,
  PizzaShape,
  PizzaSize,
  PizzaState,
} from '../types/pizza';
import {
  CATALOGO_TAMANOS,
  ICONOS_FORMA,
  STAR_POINTS_100,
  HEART_PATH_100,
  calculatePizzaMagnitudes,
} from '../utils/pizzaGeometry';
import { PizzaBaseLayers } from './PizzaShapeSVG';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import { sounds } from '../services/soundEffects';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Hand,
  MoveVertical,
} from 'lucide-react';

interface MixingStationProps {
  pizza: PizzaState;
  order: CustomerOrder | null;
  onUpdatePizza: (updater: (prev: PizzaState) => PizzaState) => void;
  onBackToDough: () => void;
  onMoveToKitchen: () => void;
}

type MixingPhase = 'INGREDIENTS' | 'MIX_SPOON' | 'ROLL_DOUGH' | 'MOLD_SHAPE';

interface IngredientJarDef {
  id: 'flour' | 'water' | 'yeast' | 'sugar' | 'oil' | 'salt';
  label: string;
  shortName: string;
  unitLabel: string;
  wellBg: string;
  wellHeaderBg: string;
  accentColor: string;
}

const BASE_INGREDIENTS: IngredientJarDef[] = [
  {
    id: 'flour',
    label: 'Harina',
    shortName: 'Harina',
    unitLabel: '1 taza (150 g)',
    wellBg: 'bg-gradient-to-b from-[#EDE0CA] to-[#D9C6A5] border-[#B49A72] text-amber-950',
    wellHeaderBg: 'bg-[#C8B18B] text-amber-950 border-b border-[#A88E65]',
    accentColor: '#F59E0B',
  },
  {
    id: 'water',
    label: 'Agua tibia',
    shortName: 'Agua tibia',
    unitLabel: '1 chorro (125 ml)',
    wellBg: 'bg-gradient-to-b from-[#DBEAFE] to-[#BFDBFE] border-[#7FA8D9] text-sky-950',
    wellHeaderBg: 'bg-[#A6C8F0] text-sky-950 border-b border-[#7FA8D9]',
    accentColor: '#38BDF8',
  },
  {
    id: 'yeast',
    label: 'Levadura',
    shortName: 'Levadura',
    unitLabel: '1 sobre (5 g)',
    wellBg: 'bg-gradient-to-b from-[#F5DEC9] to-[#E6C29F] border-[#B98B5E] text-orange-950',
    wellHeaderBg: 'bg-[#D7AB80] text-orange-950 border-b border-[#B98B5E]',
    accentColor: '#FB923C',
  },
  {
    id: 'sugar',
    label: 'Azúcar',
    shortName: 'Azúcar',
    unitLabel: '1 cdta',
    wellBg: 'bg-gradient-to-b from-[#F5E6EB] to-[#E6CBD5] border-[#BA90A0] text-rose-950',
    wellHeaderBg: 'bg-[#D8B4C2] text-rose-950 border-b border-[#BA90A0]',
    accentColor: '#F472B6',
  },
  {
    id: 'oil',
    label: 'Aceite',
    shortName: 'Aceite',
    unitLabel: '1 cda',
    wellBg: 'bg-gradient-to-b from-[#EFE8C2] to-[#DCD194] border-[#AE9E4E] text-yellow-950',
    wellHeaderBg: 'bg-[#CFC27C] text-yellow-950 border-b border-[#AE9E4E]',
    accentColor: '#CA8A04',
  },
  {
    id: 'salt',
    label: 'Sal',
    shortName: 'Sal',
    unitLabel: '1 pizca',
    wellBg: 'bg-gradient-to-b from-[#E5E9EE] to-[#CBD2DC] border-[#8E99A8] text-slate-900',
    wellHeaderBg: 'bg-[#BCC5D1] text-slate-900 border-b border-[#8E99A8]',
    accentColor: '#94A3B8',
  },
];

interface RecipePatternStep {
  id: IngredientJarDef['id'];
  targetCount: number;
}

function generateRoundPattern(targetSize: PizzaSize): {
  pattern: RecipePatternStep[];
  compartmentOrder: IngredientJarDef[];
} {
  const flourCups = CATALOGO_TAMANOS[targetSize].tazas;
  const targets: Record<IngredientJarDef['id'], number> = {
    flour: flourCups,
    water: 2,
    yeast: Math.random() > 0.5 ? 2 : 1,
    sugar: Math.random() > 0.5 ? 2 : 1,
    oil: 2,
    salt: Math.random() > 0.5 ? 2 : 1,
  };

  // Shuffle order sequence uniquely for each match/round
  const shuffledSteps = [...BASE_INGREDIENTS]
    .sort(() => Math.random() - 0.5)
    .map((ing) => ({
      id: ing.id,
      targetCount: targets[ing.id],
    }));

  // Randomize compartment positions too
  const compartmentOrder = [...BASE_INGREDIENTS].sort(() => Math.random() - 0.5);

  return { pattern: shuffledSteps, compartmentOrder };
}

const MOLD_OPTIONS: { shape: PizzaShape; label: string }[] = [
  { shape: 'Circular', label: 'Círculo' },
  { shape: 'Cuadrado', label: 'Cuadrado' },
  { shape: 'Estrella', label: 'Estrella' },
  { shape: 'Corazón', label: 'Corazón' },
];

/**
 * Dimensional, tactile 3D-shaded SVG vessels & raw culinary ingredients
 * replacing flat emojis across compartments, floating cursor, and chalkboard.
 */
const IngredientObjectSVG: React.FC<{
  id: IngredientJarDef['id'];
  idPrefix: string;
  className?: string;
  isGreenNaan?: boolean;
}> = ({ id, idPrefix, className = 'w-14 h-14', isGreenNaan = false }) => {
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden="true">
      <defs>
        <filter id={`${idPrefix}-shadow`} x="-25%" y="-20%" width="150%" height="150%">
          <feDropShadow dx="1" dy="5" stdDeviation="3.5" floodColor="#1A0F07" floodOpacity="0.48" />
        </filter>
        <radialGradient id={`${idPrefix}-flour-heap`} cx="40%" cy="35%" r="65%">
          <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFFFFF'} />
          <stop offset="55%" stopColor={isGreenNaan ? '#86EFAC' : '#FFF8EB'} />
          <stop offset="88%" stopColor={isGreenNaan ? '#4ADE80' : '#EAD8B8'} />
          <stop offset="100%" stopColor={isGreenNaan ? '#16A34A' : '#C9B08A'} />
        </radialGradient>
        <linearGradient id={`${idPrefix}-burlap`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#E6D2B5" />
          <stop offset="50%" stopColor="#CFAF82" />
          <stop offset="100%" stopColor="#9E7B4F" />
        </linearGradient>
        <linearGradient id={`${idPrefix}-glass`} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.65" />
          <stop offset="25%" stopColor="#E0F2FE" stopOpacity="0.35" />
          <stop offset="70%" stopColor="#7DD3FC" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#0284C7" stopOpacity="0.55" />
        </linearGradient>
        <linearGradient id={`${idPrefix}-water-fill`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#BAE6FD" />
          <stop offset="45%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#0369A1" />
        </linearGradient>
        <linearGradient id={`${idPrefix}-oil-bottle`} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#3F6212" />
          <stop offset="30%" stopColor="#A3E635" />
          <stop offset="65%" stopColor="#CA8A04" />
          <stop offset="100%" stopColor="#422006" />
        </linearGradient>
        <linearGradient id={`${idPrefix}-ceramic`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="50%" stopColor="#E2E8F0" />
          <stop offset="100%" stopColor="#94A3B8" />
        </linearGradient>
        <linearGradient id={`${idPrefix}-wood`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#D6A46D" />
          <stop offset="50%" stopColor="#A46D3B" />
          <stop offset="100%" stopColor="#693E19" />
        </linearGradient>
      </defs>

      <g filter={`url(#${idPrefix}-shadow)`}>
        {/* 1. HARINA: Rolled burlap sack with overflowing 3D sifted flour dome & scoop */}
        {id === 'flour' && (
          <g>
            {/* Contact shadow */}
            <ellipse cx="50" cy="86" rx="32" ry="7" fill="#1E130B" opacity="0.35" />
            {/* Burlap sack lower body */}
            <path
              d="M 22 46 Q 16 74 28 84 Q 50 90 72 84 Q 84 74 78 46 Z"
              fill={`url(#${idPrefix}-burlap)`}
              stroke="#6B4C28"
              strokeWidth="2"
            />
            {/* Rolled burlap collar rim */}
            <ellipse cx="50" cy="46" rx="29" ry="11" fill="#B89362" stroke="#6B4C28" strokeWidth="1.8" />
            <ellipse cx="50" cy="45" rx="24" ry="8" fill="#6B4C28" opacity="0.45" />
            {/* Wheat crest stamp on sack */}
            <circle cx="50" cy="68" r="9" fill="#8C6239" opacity="0.35" />
            <path d="M 50 61 L 50 75 M 46 65 L 50 68 L 54 65 M 46 70 L 50 73 L 54 70" stroke="#FAF0DC" strokeWidth="1.4" strokeLinecap="round" fill="none" />
            {/* Heaped Sifted Flour Mound */}
            <path
              d="M 27 45 Q 35 18 50 16 Q 65 18 73 45 Q 50 53 27 45 Z"
              fill={`url(#${idPrefix}-flour-heap)`}
            />
            <ellipse cx="44" cy="30" rx="10" ry="6" fill="#FFFFFF" opacity="0.85" />
            <circle cx="58" cy="35" r="1.5" fill="#DFC9A6" />
            <circle cx="38" cy="38" r="1.3" fill="#DFC9A6" />
            {/* Tiny wooden scoop handle sticking out */}
            <path
              d="M 60 32 L 77 17 C 79 15 82 18 80 21 L 64 36 Z"
              fill="#B9824D"
              stroke="#6B401B"
              strokeWidth="1.3"
            />
          </g>
        )}

        {/* 2. AGUA TIBIA: Faceted Glass Pitcher with warm water & rising steam */}
        {id === 'water' && (
          <g>
            <ellipse cx="48" cy="88" rx="26" ry="6" fill="#0F172A" opacity="0.3" />
            {/* Glass Handle */}
            <path
              d="M 68 38 C 84 36 86 68 68 68"
              fill="none"
              stroke="#BAE6FD"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <path
              d="M 68 38 C 84 36 86 68 68 68"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.7"
            />
            {/* Pitcher Body */}
            <path
              d="M 28 28 L 22 76 Q 22 86 48 86 Q 74 86 72 76 L 68 28 Z"
              fill={`url(#${idPrefix}-glass)`}
              stroke="#7DD3FC"
              strokeWidth="2"
            />
            {/* Warm Water Volume inside */}
            <path
              d="M 24 48 L 23 76 Q 23 84 48 84 Q 72 84 71 76 L 70 48 Z"
              fill={`url(#${idPrefix}-water-fill)`}
              opacity="0.9"
            />
            {/* Water Meniscus Surface */}
            <ellipse cx="47" cy="48" rx="23" ry="6.5" fill="#E0F2FE" stroke="#7DD3FC" strokeWidth="1" opacity="0.9" />
            {/* Pitcher Lip & Rim */}
            <path d="M 24 27 Q 20 24 28 24 L 68 24 Q 72 24 70 28" fill="none" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
            {/* Vertical Glass Highlight */}
            <path d="M 32 34 L 29 76" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" opacity="0.65" />
            {/* Subtle warm steam wisps */}
            <path d="M 40 18 Q 37 12 42 7 M 54 16 Q 58 10 52 5" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.75" />
          </g>
        )}

        {/* 3. LEVADURA: Sculpted ceramic ramekin dish filled with golden active yeast granules */}
        {id === 'yeast' && (
          <g>
            <ellipse cx="50" cy="83" rx="34" ry="7" fill="#1E130B" opacity="0.35" />
            {/* Ramekin Fluted Ceramic Dish */}
            <path
              d="M 18 48 L 24 77 Q 50 86 76 77 L 82 48 Z"
              fill="#B45309"
              stroke="#78350F"
              strokeWidth="2"
            />
            {/* Fluted vertical ceramic ridges */}
            <path
              d="M 32 54 L 34 78 M 44 56 L 44 80 M 56 56 L 56 80 M 68 54 L 66 78"
              stroke="#FDE68A"
              strokeWidth="1.6"
              opacity="0.35"
              strokeLinecap="round"
            />
            {/* Ramekin Rim */}
            <ellipse cx="50" cy="48" rx="33" ry="11" fill="#F59E0B" stroke="#78350F" strokeWidth="1.8" />
            <ellipse cx="50" cy="48" rx="28" ry="8.5" fill="#92400E" />
            {/* Granular Yeast Mound */}
            <path
              d="M 24 48 Q 35 27 50 26 Q 65 27 76 48 Q 50 56 24 48 Z"
              fill="#FBBF24"
            />
            <path d="M 32 42 Q 48 28 65 40" fill="#FDE68A" opacity="0.65" />
            {/* Individual Yeast Granules */}
            <g fill="#78350F">
              <circle cx="42" cy="36" r="1.8" />
              <circle cx="52" cy="33" r="1.6" />
              <circle cx="58" cy="40" r="1.9" />
              <circle cx="47" cy="44" r="1.7" />
              <circle cx="36" cy="44" r="1.5" />
              <circle cx="64" cy="44" r="1.5" />
            </g>
            <g fill="#FFFBEB">
              <circle cx="45" cy="32" r="1.3" />
              <circle cx="55" cy="36" r="1.4" />
            </g>
          </g>
        )}

        {/* 4. AZÚCAR: Frosted glass jar with sparkling white sugar crystal mound & silver spoon */}
        {id === 'sugar' && (
          <g>
            <ellipse cx="50" cy="86" rx="30" ry="6.5" fill="#0F172A" opacity="0.3" />
            {/* Silver tasting spoon sticking out */}
            <path
              d="M 56 42 L 75 18 Q 79 14 82 18 L 62 46 Z"
              fill="#CBD5E1"
              stroke="#475569"
              strokeWidth="1.3"
            />
            {/* Ceramic/Glass Sugar Bowl Body */}
            <path
              d="M 22 46 C 18 72 28 84 50 84 C 72 84 82 72 78 46 Z"
              fill={`url(#${idPrefix}-ceramic)`}
              stroke="#9D174D"
              strokeWidth="1.8"
            />
            {/* Subtle pastel café stripe on bowl */}
            <path d="M 21 60 Q 50 68 79 60" fill="none" stroke="#F472B6" strokeWidth="4" opacity="0.7" />
            {/* Bowl Rim */}
            <ellipse cx="50" cy="46" rx="29" ry="10" fill="#F8FAFC" stroke="#9D174D" strokeWidth="1.6" />
            {/* Faceted White Sugar Pyramid */}
            <path
              d="M 26 46 Q 40 21 50 20 Q 60 21 74 46 Q 50 53 26 46 Z"
              fill="#FFFFFF"
              stroke="#E2E8F0"
              strokeWidth="1"
            />
            {/* Sparkling Sugar Crystal Facets */}
            <g fill="#FBCFE8" stroke="#FFFFFF" strokeWidth="0.6">
              <rect x="40" y="34" width="4" height="4" transform="rotate(25 42 36)" />
              <rect x="52" y="30" width="3.8" height="3.8" transform="rotate(45 54 32)" />
              <rect x="46" y="40" width="4.2" height="4.2" transform="rotate(15 48 42)" />
              <rect x="59" y="39" width="3.5" height="3.5" transform="rotate(35 61 41)" />
            </g>
          </g>
        )}

        {/* 5. ACEITE: Italian Olive Oil Glass Cruet Bottle with metal pour spout & olives */}
        {id === 'oil' && (
          <g>
            <ellipse cx="50" cy="88" rx="24" ry="6" fill="#1E130B" opacity="0.38" />
            {/* Metal Pouring Spout */}
            <path
              d="M 48 16 L 56 7 L 59 9 L 52 19 Z"
              fill="#E2E8F0"
              stroke="#475569"
              strokeWidth="1.2"
            />
            {/* Cork Collar */}
            <rect x="44" y="18" width="12" height="9" rx="2" fill="#B45309" stroke="#78350F" strokeWidth="1.5" />
            {/* Bottle Neck & Round Belly */}
            <path
              d="M 44 26 L 43 40 C 24 46 22 72 30 83 Q 50 90 70 83 C 78 72 76 46 57 40 L 56 26 Z"
              fill={`url(#${idPrefix}-oil-bottle)`}
              stroke="#365314"
              strokeWidth="2"
            />
            {/* Glowing Golden Oil Inside */}
            <path
              d="M 29 58 C 27 72 31 80 50 83 C 69 80 73 72 71 58 Q 50 63 29 58 Z"
              fill="#FACC15"
              opacity="0.72"
            />
            {/* Parchment Bottle Label */}
            <rect x="34" y="54" width="32" height="19" rx="3" fill="#FEF9EE" stroke="#A16207" strokeWidth="1.2" />
            <circle cx="47" cy="63" r="4" fill="#65A30D" />
            <circle cx="53" cy="65" r="3.5" fill="#4D7C0F" />
            {/* Specular Glass Streak */}
            <path d="M 35 48 C 30 56 30 70 34 78" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round" fill="none" opacity="0.65" />
          </g>
        )}

        {/* 6. SAL: Rustic Wooden Salt Cellar Crock with Crystalline Sea Salt Dome */}
        {id === 'salt' && (
          <g>
            <ellipse cx="50" cy="84" rx="32" ry="7" fill="#0F172A" opacity="0.34" />
            {/* Turned Wooden Crock Body */}
            <path
              d="M 20 46 C 18 70 25 82 50 82 C 75 82 82 70 80 46 Z"
              fill={`url(#${idPrefix}-wood)`}
              stroke="#451A03"
              strokeWidth="2"
            />
            {/* Wood Grain Ring */}
            <path d="M 24 62 Q 50 68 76 62" fill="none" stroke="#451A03" strokeWidth="1.5" opacity="0.4" />
            {/* Wooden Rim */}
            <ellipse cx="50" cy="46" rx="31" ry="10.5" fill="#C98F56" stroke="#451A03" strokeWidth="1.8" />
            <ellipse cx="50" cy="46" rx="26" ry="8" fill="#5C3414" />
            {/* Heaped White Coarse Sea Salt Crystals */}
            <path
              d="M 26 46 Q 38 22 50 20 Q 62 22 74 46 Q 50 53 26 46 Z"
              fill="#F8FAFC"
              stroke="#CBD5E1"
              strokeWidth="1.2"
            />
            <ellipse cx="44" cy="34" rx="10" ry="6" fill="#FFFFFF" />
            {/* Salt Crystal Cubes */}
            <g fill="#FFFFFF" stroke="#94A3B8" strokeWidth="0.8">
              <rect x="38" y="36" width="4.5" height="4.5" rx="0.6" transform="rotate(18 40 38)" />
              <rect x="52" y="32" width="4" height="4" rx="0.6" transform="rotate(42 54 34)" />
              <rect x="48" y="41" width="4.4" height="4.4" rx="0.6" transform="rotate(8 50 43)" />
              <rect x="60" y="40" width="3.8" height="3.8" rx="0.6" transform="rotate(30 62 42)" />
            </g>
          </g>
        )}
      </g>
    </svg>
  );
};

export const MixingStation: React.FC<MixingStationProps> = ({
  pizza,
  order,
  onUpdatePizza,
  onBackToDough,
  onMoveToKitchen,
}) => {
  const isGreenNaan = pizza.dough === 'naan_verde';
  const targetSize: PizzaSize = order?.recipe.size || pizza.size || 'Mediana';
  const targetShape: PizzaShape = order?.recipe.shape || pizza.shape || 'Circular';
  const infoTamano = CATALOGO_TAMANOS[targetSize];

  const [phase, setPhase] = useState<MixingPhase>(
    pizza.doughCompleted ? 'MOLD_SHAPE' : 'INGREDIENTS'
  );

  // Per-round randomized order sequence & compartment positions
  const [roundConfig, setRoundConfig] = useState<{
    pattern: RecipePatternStep[];
    compartmentOrder: IngredientJarDef[];
  }>(() => generateRoundPattern(targetSize));

  const [addedCounts, setAddedCounts] = useState<Record<IngredientJarDef['id'], number>>({
    flour: 0,
    water: 0,
    yeast: 0,
    sugar: 0,
    oil: 0,
    salt: 0,
  });

  const [brokenHearts, setBrokenHearts] = useState<number>(
    pizza.doughScore < 100 ? Math.min(3, Math.round(((100 - pizza.doughScore) / 100) * 3)) : 0
  );
  const [heartBreakFlash, setHeartBreakFlash] = useState<boolean>(false);
  const [calificacionMasa, setCalificacionMasa] = useState<number>(pizza.doughScore);
  const [statusFeedback, setStatusFeedback] = useState<{
    text: string;
    tone: 'neutral' | 'error' | 'success';
  }>({
    text: 'Mira la Secuencia de Ingredientes en la pizarra y arrastra cada porción al tazón.',
    tone: 'neutral',
  });

  // Drag / Carry state for Phase 1
  const [heldIng, setHeldIng] = useState<IngredientJarDef | null>(null);
  const [pointerPos, setPointerPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isHoveringBowl, setIsHoveringBowl] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);
  const bowlRef = useRef<HTMLDivElement | null>(null);

  // Phase 2: Spoon Stirring state
  const [mixProgress, setMixProgress] = useState<number>(pizza.doughCompleted ? 100 : 0);
  const [isHoldingSpoon, setIsHoldingSpoon] = useState<boolean>(false);
  const [spoonPos, setSpoonPos] = useState<{ x: number; y: number }>({ x: 50, y: 45 });
  const [swirlAngle, setSwirlAngle] = useState<number>(0);
  const lastSpoonPointerRef = useRef<{ x: number; y: number } | null>(null);
  const lastSoundStepRef = useRef<number>(0);
  const mixArenaRef = useRef<HTMLDivElement | null>(null);

  // Phase 3: Physical Rolling Pin state
  const [rollProgress, setRollProgress] = useState<number>(pizza.doughCompleted ? 100 : 0);
  const [isHoldingRoller, setIsHoldingRoller] = useState<boolean>(false);
  const [rollerY, setRollerY] = useState<number>(50);
  const [rollerRollDeg, setRollerRollDeg] = useState<number>(0);
  const lastRollerYRef = useRef<number | null>(null);
  const lastRollSoundStepRef = useRef<number>(0);
  const rollBoardRef = useRef<HTMLDivElement | null>(null);

  // Phase 4: Mold Selection
  const [moldeAplicado, setMoldeAplicado] = useState<boolean>(pizza.doughCompleted);
  const [feedbackMolde, setFeedbackMolde] = useState<{
    text: string;
    tone: 'neutral' | 'error' | 'success';
  } | null>(null);

  // Derived sequence progress
  const currentPatternIdx = roundConfig.pattern.findIndex(
    (step) => addedCounts[step.id] < step.targetCount
  );
  const allPatternFulfilled = currentPatternIdx === -1;
  const totalAddedUnits = Object.values(addedCounts).reduce((acc, v) => acc + v, 0);
  const heartsRemaining = Math.max(0, 3 - brokenHearts);

  // Sync broken hearts when entering from DoughStation with updated doughScore
  useEffect(() => {
    if (!pizza.doughCompleted && pizza.doughScore < 100) {
      const inheritedBroken = Math.min(3, Math.round(((100 - pizza.doughScore) / 100) * 3));
      setBrokenHearts(inheritedBroken);
      setCalificacionMasa(pizza.doughScore);
    }
  }, [pizza.doughScore, pizza.doughCompleted]);

  // Reset if pizza ID changes to a fresh uncompleted pizza
  useEffect(() => {
    if (!pizza.doughCompleted) {
      const nextCfg = generateRoundPattern(targetSize);
      setRoundConfig(nextCfg);
      setPhase('INGREDIENTS');
      setAddedCounts({
        flour: 0,
        water: 0,
        yeast: 0,
        sugar: 0,
        oil: 0,
        salt: 0,
      });
      setBrokenHearts(0);
      setHeartBreakFlash(false);
      setCalificacionMasa(100);
      const firstIng = BASE_INGREDIENTS.find((b) => b.id === nextCfg.pattern[0].id);
      setStatusFeedback({
        text: `Empieza con el #1 de la secuencia: ${firstIng?.shortName} (${nextCfg.pattern[0].targetCount}x).`,
        tone: 'neutral',
      });
      setHeldIng(null);
      setMixProgress(0);
      setIsHoldingSpoon(false);
      setRollProgress(0);
      setIsHoldingRoller(false);
      setRollerY(50);
      setMoldeAplicado(false);
      setFeedbackMolde(null);
      lastSoundStepRef.current = 0;
      lastRollSoundStepRef.current = 0;
    }
  }, [pizza.id]);

  // Check if pointer coordinates are over the bowl
  const checkInsideBowl = (clientX: number, clientY: number) => {
    if (!bowlRef.current) return false;
    const rect = bowlRef.current.getBoundingClientRect();
    const pad = 28;
    return (
      clientX >= rect.left - pad &&
      clientX <= rect.right + pad &&
      clientY >= rect.top - pad &&
      clientY <= rect.bottom + pad
    );
  };

  // Trigger a broken heart when player exceeds recipe quantity or breaks order
  const breakFlavorHeart = (reasonText: string) => {
    sounds.playReaction('angry');
    setHeartBreakFlash(true);
    setTimeout(() => setHeartBreakFlash(false), 600);

    setBrokenHearts((prev) => {
      const nextBroken = Math.min(3, prev + 1);
      const remaining = 3 - nextBroken;
      const nextScore = Math.round((remaining / 3) * 100);
      setCalificacionMasa(nextScore);
      onUpdatePizza((p) => ({
        ...p,
        doughScore: nextScore,
      }));
      setStatusFeedback({
        text: `${reasonText} ¡Se rompió un corazón de sabor! (${remaining}/3 ❤️)`,
        tone: 'error',
      });
      return nextBroken;
    });
  };

  // Player is ALWAYS free to pour any amount of any ingredient into the bowl
  const attemptAddIngredient = (ing: IngredientJarDef) => {
    if (phase !== 'INGREDIENTS') return;

    const currentCount = addedCounts[ing.id];
    const nextCount = currentCount + 1;
    const stepIdx = roundConfig.pattern.findIndex((s) => s.id === ing.id);
    const stepDef = roundConfig.pattern[stepIdx];
    const targetCount = stepDef?.targetCount ?? 1;

    const nextCounts = {
      ...addedCounts,
      [ing.id]: nextCount,
    };
    setAddedCounts(nextCounts);

    // 1. Check if player added MORE than the recipe indicates -> BREAK 1 HEART
    if (nextCount > targetCount) {
      breakFlavorHeart(
        `¡Te pasaste con ${ing.shortName}! (La secuencia pedía ${targetCount} y echaste ${nextCount}).`
      );
      return;
    }

    // 2. Check if player skipped ahead of the current sequence -> BREAK 1 HEART
    if (currentPatternIdx !== -1 && stepIdx !== currentPatternIdx) {
      const expectedStep = roundConfig.pattern[currentPatternIdx];
      const expectedIng = BASE_INGREDIENTS.find((b) => b.id === expectedStep.id);
      breakFlavorHeart(
        `¡Orden incorrecto! La secuencia de ingredientes pedía ${expectedIng?.shortName}.`
      );
      return;
    }

    // 3. Correct addition!
    sounds.playToppingPop(0.5 + nextCount * 0.12);

    const nextPendingIdx = roundConfig.pattern.findIndex(
      (s) => nextCounts[s.id] < s.targetCount
    );
    if (nextPendingIdx === -1) {
      sounds.playChaChing();
      setStatusFeedback({
        text: '¡Secuencia del tazón perfecta! Pulsa "¡Mezclar con Cuchara!" para continuar.',
        tone: 'success',
      });
    } else {
      const nextStep = roundConfig.pattern[nextPendingIdx];
      const nextIng = BASE_INGREDIENTS.find((b) => b.id === nextStep.id);
      const remainingOfNext = nextStep.targetCount - nextCounts[nextStep.id];
      setStatusFeedback({
        text: `¡Bien! Sigue con #${nextPendingIdx + 1}: ${nextIng?.shortName} (faltan ${remainingOfNext}).`,
        tone: 'success',
      });
    }
  };

  const handleGoToSpoonPhase = () => {
    if (totalAddedUnits === 0) return;
    const missingItems = roundConfig.pattern.filter(
      (s) => addedCounts[s.id] < s.targetCount
    );
    if (missingItems.length > 0 && brokenHearts < 3) {
      const penaltyBroken = Math.min(3, brokenHearts + 1);
      const nextScore = Math.round(((3 - penaltyBroken) / 3) * 100);
      setBrokenHearts(penaltyBroken);
      setCalificacionMasa(nextScore);
      onUpdatePizza((p) => ({
        ...p,
        doughScore: nextScore,
      }));
    }
    sounds.playChaChing();
    setPhase('MIX_SPOON');
  };

  // Global window pointer listeners when carrying an ingredient
  useEffect(() => {
    if (!heldIng) return;

    const onWindowPointerMove = (e: PointerEvent) => {
      setPointerPos({ x: e.clientX, y: e.clientY });
      setIsHoveringBowl(checkInsideBowl(e.clientX, e.clientY));
    };

    const onWindowPointerUp = (e: PointerEvent) => {
      const start = dragStartRef.current;
      const movedDist = start
        ? Math.hypot(e.clientX - start.x, e.clientY - start.y)
        : 0;
      const overBowl = checkInsideBowl(e.clientX, e.clientY);

      if (overBowl) {
        attemptAddIngredient(heldIng);
        setHeldIng(null);
        setIsHoveringBowl(false);
        dragStartRef.current = null;
      } else if (movedDist >= 12) {
        setHeldIng(null);
        setIsHoveringBowl(false);
        dragStartRef.current = null;
      }
    };

    window.addEventListener('pointermove', onWindowPointerMove);
    window.addEventListener('pointerup', onWindowPointerUp);
    return () => {
      window.removeEventListener('pointermove', onWindowPointerMove);
      window.removeEventListener('pointerup', onWindowPointerUp);
    };
  }, [heldIng, addedCounts, brokenHearts, phase, roundConfig, currentPatternIdx]);

  // Global pointer up to release spoon or roller safely
  useEffect(() => {
    const stopTools = () => {
      setIsHoldingSpoon(false);
      lastSpoonPointerRef.current = null;
      setIsHoldingRoller(false);
      lastRollerYRef.current = null;
    };
    window.addEventListener('pointerup', stopTools);
    return () => window.removeEventListener('pointerup', stopTools);
  }, []);

  // Handle stirring spoon movement (mouse held down)
  const handleSpoonPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!mixArenaRef.current) return;
    const rect = mixArenaRef.current.getBoundingClientRect();
    const pctX = Math.max(15, Math.min(85, ((e.clientX - rect.left) / rect.width) * 100));
    const pctY = Math.max(15, Math.min(85, ((e.clientY - rect.top) / rect.height) * 100));

    if (!isHoldingSpoon || phase !== 'MIX_SPOON') return;

    setSpoonPos({ x: pctX, y: pctY });

    if (lastSpoonPointerRef.current) {
      const dx = e.clientX - lastSpoonPointerRef.current.x;
      const dy = e.clientY - lastSpoonPointerRef.current.y;
      const dist = Math.hypot(dx, dy);

      if (dist > 1) {
        setSwirlAngle((prev) => prev + dist * 0.65);
        setMixProgress((prev) => {
          const next = Math.min(100, prev + dist * 0.14);
          const soundBucket = Math.floor(next / 16);
          if (soundBucket > lastSoundStepRef.current) {
            lastSoundStepRef.current = soundBucket;
            sounds.playSauceSquirt();
          }
          if (next >= 100 && prev < 100) {
            sounds.playChaChing();
            setIsHoldingSpoon(false);
            setTimeout(() => {
              setPhase('ROLL_DOUGH');
            }, 550);
          }
          return next;
        });
      }
    }

    lastSpoonPointerRef.current = { x: e.clientX, y: e.clientY };
  };

  // Handle physical rolling pin up & down movement
  const handleRollerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!rollBoardRef.current || !isHoldingRoller || phase !== 'ROLL_DOUGH') return;
    const rect = rollBoardRef.current.getBoundingClientRect();
    const pctY = Math.max(14, Math.min(86, ((e.clientY - rect.top) / rect.height) * 100));

    setRollerY(pctY);

    if (lastRollerYRef.current !== null) {
      const dy = e.clientY - lastRollerYRef.current;
      const absDy = Math.abs(dy);

      if (absDy > 1) {
        setRollerRollDeg((prev) => prev + dy * 1.4);
        setRollProgress((prev) => {
          const next = Math.min(100, prev + absDy * 0.16);
          const soundBucket = Math.floor(next / 20);
          if (soundBucket > lastRollSoundStepRef.current) {
            lastRollSoundStepRef.current = soundBucket;
            sounds.playDoughSlap();
          }
          if (next >= 100 && prev < 100) {
            sounds.playChaChing();
            setIsHoldingRoller(false);
            setTimeout(() => {
              setPhase('MOLD_SHAPE');
            }, 500);
          }
          return next;
        });
      }
    }

    lastRollerYRef.current = e.clientY;
  };

  // Phase 4: Mold Selection
  const aplicarMolde = (formaSeleccionada: PizzaShape) => {
    if (formaSeleccionada !== targetShape) {
      sounds.playReaction('meh');
      setFeedbackMolde({
        text: `El cliente pidió ${ICONOS_FORMA[targetShape]} ${targetShape}. ¡Intenta con ese molde!`,
        tone: 'error',
      });
      return;
    }

    sounds.playChaChing();
    setMoldeAplicado(true);
    setFeedbackMolde({
      text: `¡Genial! Tu masa estirada ya tiene forma de ${formaSeleccionada}.`,
      tone: 'success',
    });

    const mags = calculatePizzaMagnitudes(targetSize, formaSeleccionada, calificacionMasa);
    onUpdatePizza((prev) => ({
      ...prev,
      size: targetSize,
      shape: formaSeleccionada,
      flourWeighed: true,
      doughCompleted: true,
      doughScore: calificacionMasa,
      magnitudes: mags,
    }));
  };

  const getHeartsDisplay = () => {
    const arr: string[] = [];
    for (let i = 0; i < 3; i++) {
      arr.push(i < heartsRemaining ? '❤️' : '💔');
    }
    return arr;
  };

  const doughScale = 0.42 + (rollProgress / 100) * 0.58;
  const doughFlatnessShadow = Math.max(2, Math.round(14 - (rollProgress / 100) * 11));

  // Wait-for-flour check if user navigated directly via top bar without weighing flour first
  if (!pizza.flourWeighed && !pizza.doughCompleted) {
    return (
      <div className="relative flex-1 h-full flex items-center justify-center p-4 bg-[#1A1412] select-none overflow-hidden">
        <img
          src="/assets/aistudio/kitcken_5d4796e4.jpg"
          alt="Mesa de Mezclas"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-55 pointer-events-none"
        />
        <WoodParchmentBoard
          variant="vertical"
          className="relative z-10 max-w-md w-full"
          innerClassName="text-center space-y-4"
        >
          <div className="mx-auto w-20 h-20">
            <IngredientObjectSVG
              id="flour"
              idPrefix="gate-flour"
              isGreenNaan={isGreenNaan}
              className="w-full h-full"
            />
          </div>
          <h2 className="font-display font-black text-2xl text-[#3A1E0D]">
            ¡Primero pesa la harina!
          </h2>
          <p className="text-sm text-[#5D290D] font-medium">
            Antes de pasar a la sala de mezclas, ve a la gramera de <strong>Masa</strong> y pesa la harina para tu pizza <strong>{targetSize}</strong>.
          </p>
          <button
            onClick={onBackToDough}
            className="w-full py-3 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-black rounded-2xl shadow-md transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Ir a pesar la harina
          </button>
        </WoodParchmentBoard>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col h-full bg-[#1A1412] select-none overflow-hidden">
      {/* Background: Rustic Kitchen Prep Table */}
      <img
        src="/assets/aistudio/kitcken_5d4796e4.jpg"
        alt="Sala de Mezclas"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover pointer-events-none opacity-85"
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 50%, rgba(16,11,8,0.12) 20%, rgba(12,8,5,0.58) 100%)',
        }}
      />

      {/* Top Controls Bar (Solid Espresso/Oak Workbench Bar) */}
      <div className="relative z-20 flex flex-wrap items-center justify-between gap-2 px-4 py-2 bg-[#2B1D14]/95 backdrop-blur-md border-b-2 border-[#5E412A] shadow-xl">
        <button
          onClick={onBackToDough}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-100 hover:text-white bg-[#463021] hover:bg-[#5A3E2B] border border-[#7A563B] rounded-lg transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Volver a Gramera
        </button>

        {/* Step Indicators */}
        <div className="flex items-center gap-1.5 text-[11px] font-extrabold">
          <span
            className={`px-2.5 py-1 rounded-lg border ${
              phase === 'INGREDIENTS'
                ? 'bg-amber-500 text-stone-950 border-amber-300 shadow-sm'
                : 'bg-emerald-900/70 text-emerald-200 border-emerald-500/50'
            }`}
          >
            1. Compartimientos ({Object.values(addedCounts).filter((c) => c > 0).length}/6)
          </span>
          <span className="text-amber-300/60">➔</span>
          <span
            className={`px-2.5 py-1 rounded-lg border ${
              phase === 'MIX_SPOON'
                ? 'bg-emerald-500 text-stone-950 border-emerald-300 shadow-sm'
                : mixProgress >= 100
                ? 'bg-emerald-900/70 text-emerald-200 border-emerald-500/50'
                : 'bg-stone-800/80 text-stone-400 border-stone-700'
            }`}
          >
            2. Cuchara ({Math.round(mixProgress)}%)
          </span>
          <span className="text-amber-300/60">➔</span>
          <span
            className={`px-2.5 py-1 rounded-lg border ${
              phase === 'ROLL_DOUGH'
                ? 'bg-rose-500 text-white border-rose-300 shadow-sm'
                : rollProgress >= 100
                ? 'bg-emerald-900/70 text-emerald-200 border-emerald-500/50'
                : 'bg-stone-800/80 text-stone-400 border-stone-700'
            }`}
          >
            3. Rodillo ({Math.round(rollProgress)}%)
          </span>
          <span className="text-amber-300/60">➔</span>
          <span
            className={`px-2.5 py-1 rounded-lg border ${
              phase === 'MOLD_SHAPE'
                ? 'bg-indigo-500 text-white border-indigo-300 shadow-sm'
                : 'bg-stone-800/80 text-stone-400 border-stone-700'
            }`}
          >
            4. Molde
          </span>
        </div>

        {/* Flavor Rating (3 Hearts) & Order Size/Shape */}
        <div className="flex items-center gap-2 sm:gap-3">
          {isGreenNaan && (
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-emerald-900/90 rounded-lg border border-emerald-400 text-xs font-extrabold text-emerald-100">
              <span>🌿 Naan Verde</span>
            </div>
          )}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-[#3D2A1D] rounded-lg border border-[#6E4D35] text-xs font-bold text-amber-100">
            <span>{ICONOS_FORMA[targetShape]}</span>
            <span>
              {targetSize} · {targetShape}
            </span>
          </div>
          <div
            className={`flex items-center gap-2 px-3 py-1 rounded-xl border-2 text-xs font-extrabold transition-transform ${
              heartBreakFlash
                ? 'bg-rose-900 border-rose-400 scale-110 text-white'
                : 'bg-[#3D2A1D] border-rose-400/50 text-rose-100'
            }`}
            title="Calificación del Sabor: se rompe un corazón si agregas de más o fuera de la secuencia de ingredientes"
          >
            <span className="text-[11px] uppercase tracking-wider font-black">
              Sabor:
            </span>
            <span className="flex items-center gap-0.5 text-base leading-none">
              {getHeartsDisplay().map((h, i) => (
                <span key={i}>{h}</span>
              ))}
            </span>
            <span className="text-amber-300 font-mono tabular-nums">{heartsRemaining}/3</span>
          </div>
        </div>
      </div>

      {/* MAIN INTERACTIVE STUDIO */}
      <div className="relative z-10 flex-1 flex flex-col lg:flex-row items-center justify-center p-3 sm:p-5 gap-5 overflow-y-auto">
        {/* ==================== PHASE 1: DIMENSIONAL COMPARTMENTS + BOWL + CAFÉ CHALKBOARD ==================== */}
        {phase === 'INGREDIENTS' && (
          <div className="w-full max-w-6xl flex flex-col lg:flex-row items-center lg:items-stretch justify-center gap-5">
            {/* LEFT: ARTISAN OAK & ENAMEL COMPARTMENT TRAY */}
            <div className="w-full lg:w-[410px] bg-gradient-to-b from-[#6B4527] to-[#4A2E18] rounded-3xl border-4 border-[#36200F] p-3.5 shadow-[0_18px_36px_rgba(0,0,0,0.65)] flex flex-col justify-between shrink-0">
              <div>
                <div className="flex items-center justify-between px-1 pb-2.5 border-b border-amber-200/20 mb-3">
                  <h3 className="font-black text-sm sm:text-base text-amber-100 flex items-center gap-1.5 drop-shadow">
                    <Hand className="w-4 h-4 text-amber-300" />
                    Compartimientos de Ingredientes
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-black/40 text-amber-200 border border-amber-300/20">
                    Agarra y echa al tazón
                  </span>
                </div>

                {/* 6 Individual Recessed Dimensional Cubbies */}
                <div className="grid grid-cols-2 gap-2.5 bg-[#331E0E] p-2.5 rounded-2xl border-2 border-[#231307] shadow-[inset_0_4px_12px_rgba(0,0,0,0.6)]">
                  {roundConfig.compartmentOrder.map((ing) => {
                    const count = addedCounts[ing.id];
                    const stepDef = roundConfig.pattern.find((s) => s.id === ing.id);
                    const targetCount = stepDef?.targetCount ?? 1;
                    const isOver = count > targetCount;
                    const isExact = count === targetCount;
                    const isHeld = heldIng?.id === ing.id;

                    return (
                      <div
                        key={ing.id}
                        className={`rounded-xl border-2 overflow-hidden transition-all flex flex-col shadow-[0_6px_12px_rgba(0,0,0,0.45),inset_0_2px_4px_rgba(255,255,255,0.5)] ${
                          isOver
                            ? 'border-rose-500 ring-2 ring-rose-400/70 bg-gradient-to-b from-rose-100 to-rose-200 text-rose-950'
                            : isExact
                            ? 'border-emerald-500 ring-1 ring-emerald-400/60 bg-gradient-to-b from-emerald-50 to-emerald-200 text-emerald-950'
                            : ing.wellBg
                        }`}
                      >
                        {/* Metallic/Enamel Compartment Label Plate */}
                        <div
                          className={`px-2 py-1 text-[11px] font-black flex items-center justify-between shadow-2xs ${
                            isOver
                              ? 'bg-rose-300 text-rose-950 border-b border-rose-400'
                              : isExact
                              ? 'bg-emerald-300 text-emerald-950 border-b border-emerald-400'
                              : ing.wellHeaderBg
                          }`}
                        >
                          <span className="truncate">{ing.shortName}</span>
                          <span
                            className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono tabular-nums ${
                              isOver
                                ? 'bg-rose-700 text-white'
                                : isExact
                                ? 'bg-emerald-800 text-white'
                                : 'bg-stone-900/80 text-amber-100'
                            }`}
                          >
                            {count}/{targetCount}
                          </span>
                        </div>

                        {/* Interactive 3D Ingredient Grab Well */}
                        <button
                          type="button"
                          onPointerDown={(e) => {
                            e.preventDefault();
                            dragStartRef.current = { x: e.clientX, y: e.clientY };
                            setPointerPos({ x: e.clientX, y: e.clientY });
                            setHeldIng(ing);
                            sounds.playToppingPop(0.7);
                          }}
                          className={`flex-1 px-2 py-2 flex flex-col items-center justify-center gap-0.5 select-none touch-none transition-all duration-150 ${
                            isHeld
                              ? 'scale-95 opacity-55 cursor-grabbing'
                              : 'cursor-grab active:cursor-grabbing hover:brightness-105 hover:-translate-y-0.5'
                          }`}
                        >
                          <IngredientObjectSVG
                            id={ing.id}
                            idPrefix={`cubby-${ing.id}`}
                            isGreenNaan={isGreenNaan}
                            className="w-14 h-14 sm:w-16 sm:h-16 transition-transform duration-150"
                          />
                          <span className="text-[10px] font-extrabold opacity-85 leading-tight text-center">
                            +{ing.unitLabel}
                          </span>
                          {isOver && (
                            <span className="text-[10px] font-black text-rose-700">
                              ¡Exceso! (-❤️)
                            </span>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              <p className="mt-2.5 text-[11px] text-amber-100/90 font-medium text-center leading-snug">
                Puedes echar la cantidad que quieras, pero si agregas <strong>más de la receta</strong> o rompes la secuencia, se rompe un ❤️ de sabor.
              </p>
            </div>

            {/* CENTER: 3D GLAZED CERAMIC MIXING BOWL */}
            <div className="flex flex-col items-center justify-center flex-1 max-w-md mx-auto w-full">
              {/* Status feedback strip */}
              <div
                className={`mb-3 w-full px-4 py-2.5 rounded-2xl border-2 shadow-xl text-xs sm:text-sm font-black text-center transition-all ${
                  statusFeedback.tone === 'error'
                    ? 'bg-rose-950/90 border-rose-400 text-rose-100 animate-pulse'
                    : statusFeedback.tone === 'success'
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100'
                    : 'bg-[#261B14]/90 border-amber-400/60 text-amber-100'
                }`}
              >
                {heldIng
                  ? `Llevando ${heldIng.label} — suéltalo o haz clic dentro del tazón`
                  : statusFeedback.text}
              </div>

              {/* Interactive Bowl Drop Zone */}
              <div
                ref={bowlRef}
                onClick={() => {
                  if (heldIng) {
                    attemptAddIngredient(heldIng);
                    setHeldIng(null);
                    setIsHoveringBowl(false);
                    dragStartRef.current = null;
                  }
                }}
                className={`relative w-72 h-72 sm:w-84 sm:h-84 rounded-full flex items-center justify-center transition-all duration-200 ${
                  isHoveringBowl ? 'scale-105' : ''
                } ${heldIng ? 'cursor-pointer' : ''}`}
              >
                {/* 3D Glazed Ceramic Bowl Exterior & Rim */}
                <div
                  className={`w-full h-full rounded-full bg-gradient-to-b from-[#FAF5EE] via-[#E5D7C3] to-[#B79D7E] border-8 shadow-[0_22px_40px_rgba(0,0,0,0.65),inset_0_4px_10px_rgba(255,255,255,0.8)] flex items-center justify-center p-4 transition-all ${
                    isHoveringBowl
                      ? 'border-emerald-400 ring-8 ring-emerald-400/40'
                      : heldIng
                      ? 'border-amber-400 ring-4 ring-amber-300/45'
                      : 'border-[#9F8263]'
                  }`}
                >
                  {/* Deep Concave Glazed Bowl Cavity */}
                  <div className="relative w-full h-full rounded-full bg-[radial-gradient(circle_at_38%_35%,#FBF6EE_0%,#EFE3D0_55%,#CEBBA0_100%)] border-4 border-[#B9A287] shadow-[inset_0_12px_24px_rgba(70,45,20,0.38)] overflow-hidden flex items-center justify-center">
                    {totalAddedUnits === 0 && (
                      <div className="text-center px-4 pointer-events-none">
                        <span className="text-xs font-black text-stone-500 uppercase tracking-wider block">
                          Tazón de Mezcla
                        </span>
                        <span className="block text-[11px] text-stone-400 mt-0.5 font-semibold">
                          Arrastra o suelta ingredientes aquí
                        </span>
                      </div>
                    )}

                    {/* Layered Dimensional Accumulated Ingredients SVG inside Bowl */}
                    <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none">
                      <defs>
                        <radialGradient id="bowl-flour-3d" cx="42%" cy="36%" r="62%">
                          <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFFFFF'} />
                          <stop offset="55%" stopColor={isGreenNaan ? '#86EFAC' : '#FEF7E6'} />
                          <stop offset="90%" stopColor={isGreenNaan ? '#4ADE80' : '#EBD8B5'} />
                          <stop offset="100%" stopColor={isGreenNaan ? '#16A34A' : '#CBB187'} />
                        </radialGradient>
                        <radialGradient id="bowl-water-3d" cx="40%" cy="35%" r="65%">
                          <stop offset="0%" stopColor="#E0F2FE" stopOpacity="0.8" />
                          <stop offset="55%" stopColor="#38BDF8" stopOpacity="0.72" />
                          <stop offset="100%" stopColor="#0284C7" stopOpacity="0.82" />
                        </radialGradient>
                      </defs>

                      {/* Flour Mound with cast shadow & highlight peaks */}
                      {addedCounts.flour > 0 && (
                        <g className="animate-in zoom-in-75 duration-200">
                          <ellipse
                            cx="52"
                            cy="56"
                            rx={Math.min(44, 24 + addedCounts.flour * 6)}
                            ry={Math.min(40, 22 + addedCounts.flour * 5)}
                            fill="#785A3A"
                            opacity="0.22"
                          />
                          <circle
                            cx="50"
                            cy="51"
                            r={Math.min(43, 24 + addedCounts.flour * 6)}
                            fill="url(#bowl-flour-3d)"
                          />
                          <ellipse cx="42" cy="43" rx="14" ry="10" fill={isGreenNaan ? '#DCFCE7' : '#FFFFFF'} opacity="0.75" />
                        </g>
                      )}

                      {/* Water Pool with glistening specular wave */}
                      {addedCounts.water > 0 && (
                        <g className="animate-in zoom-in-75 duration-200">
                          <ellipse
                            cx="52"
                            cy="55"
                            rx={Math.min(42, 18 + addedCounts.water * 6)}
                            ry={Math.min(38, 15 + addedCounts.water * 5)}
                            fill="url(#bowl-water-3d)"
                          />
                          <path
                            d="M 38 46 Q 48 40 60 45"
                            fill="none"
                            stroke="#FFFFFF"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                            opacity="0.7"
                          />
                        </g>
                      )}

                      {/* Active Yeast Granules */}
                      {addedCounts.yeast > 0 && (
                        <g className="animate-in fade-in duration-200">
                          <circle cx="44" cy="42" r="2.3" fill="#B45309" />
                          <circle cx="56" cy="45" r="2.5" fill="#92400E" />
                          <circle cx="49" cy="58" r="2.2" fill="#D97706" />
                          {addedCounts.yeast > 1 && (
                            <>
                              <circle cx="38" cy="54" r="2.4" fill="#92400E" />
                              <circle cx="62" cy="53" r="2.6" fill="#B45309" />
                              <circle cx="52" cy="37" r="2.3" fill="#D97706" />
                            </>
                          )}
                        </g>
                      )}

                      {/* Sparkling Sugar Crystals */}
                      {addedCounts.sugar > 0 && (
                        <g className="animate-in fade-in duration-200" fill="#FFFFFF" stroke="#F472B6" strokeWidth="0.4">
                          <rect x="40" y="48" width="3" height="3" rx="0.5" transform="rotate(20 40 48)" />
                          <rect x="54" y="40" width="3" height="3" rx="0.5" transform="rotate(45 54 40)" />
                          <rect x="59" y="57" width="3" height="3" rx="0.5" transform="rotate(10 59 57)" />
                          {addedCounts.sugar > 1 && (
                            <>
                              <rect x="44" y="61" width="3.2" height="3.2" rx="0.5" transform="rotate(60 44 61)" />
                              <rect x="50" y="50" width="3.2" height="3.2" rx="0.5" />
                            </>
                          )}
                        </g>
                      )}

                      {/* Olive Oil Golden Glossy Swirl */}
                      {addedCounts.oil > 0 && (
                        <g className="animate-in zoom-in-90 duration-200">
                          <path
                            d="M 35 45 Q 50 32 65 48 Q 58 66 38 60"
                            fill="none"
                            stroke="#CA8A04"
                            strokeWidth={Math.min(8.5, 3.5 + addedCounts.oil * 1.5)}
                            strokeLinecap="round"
                            opacity="0.88"
                          />
                          <path
                            d="M 38 44 Q 50 35 61 46"
                            fill="none"
                            stroke="#FEF08A"
                            strokeWidth="1.6"
                            strokeLinecap="round"
                            opacity="0.85"
                          />
                          <circle cx="64" cy="48" r="3" fill="#FACC15" />
                        </g>
                      )}

                      {/* Coarse Sea Salt Crystals */}
                      {addedCounts.salt > 0 && (
                        <g className="animate-in fade-in duration-200" fill="#F8FAFC" stroke="#64748B" strokeWidth="0.5">
                          <rect x="45" y="43" width="2.8" height="2.8" rx="0.4" transform="rotate(15 46 44)" />
                          <rect x="54" y="50" width="2.9" height="2.9" rx="0.4" transform="rotate(40 55 51)" />
                          <rect x="40" y="55" width="2.7" height="2.7" rx="0.4" />
                          {addedCounts.salt > 1 && (
                            <>
                              <rect x="51" y="59" width="3" height="3" rx="0.4" transform="rotate(25 52 60)" />
                              <rect x="59" y="42" width="2.8" height="2.8" rx="0.4" />
                            </>
                          )}
                        </g>
                      )}
                    </svg>

                    {totalAddedUnits > 0 && (
                      <div className="absolute bottom-3 px-3 py-0.5 bg-stone-900/85 text-amber-100 rounded-md border border-amber-300/30 text-xs font-black shadow-md tabular-nums">
                        {totalAddedUnits} porción(es) en el tazón
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Proceed to Spoon Mixing Button */}
              <button
                type="button"
                disabled={totalAddedUnits === 0}
                onClick={handleGoToSpoonPhase}
                className={`mt-4 w-full max-w-xs py-3 px-5 rounded-2xl font-black text-sm shadow-2xl flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                  allPatternFulfilled
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-stone-950 ring-4 ring-emerald-300/60 animate-bounce'
                    : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                }`}
              >
                <span>
                  {allPatternFulfilled
                    ? '¡Listo! Mezclar con Cuchara'
                    : 'Pasar a Mezclar con Cuchara'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* RIGHT: SOLID CAFÉ CHALKBOARD ("Secuencia de Ingredientes" — Pizarra de Cafetería) */}
            <aside
              aria-label="Pizarra de Secuencia de Ingredientes"
              className="w-full lg:w-80 shrink-0 flex flex-col"
            >
              {/* Outer Solid Oak Café Chalkboard Frame */}
              <div className="relative bg-[#5E3A1E] p-2.5 rounded-2xl border-4 border-[#3B220F] shadow-[0_22px_45px_rgba(0,0,0,0.75),inset_0_2px_3px_rgba(255,220,180,0.28)] flex flex-col justify-between">
                {/* Inner Matte Slate Blackboard Surface */}
                <div
                  className="rounded-lg bg-[#1C2420] border-2 border-[#111613] shadow-[inset_0_4px_16px_rgba(0,0,0,0.75)] p-4 flex flex-col justify-between gap-4"
                  style={{
                    backgroundImage:
                      'radial-gradient(circle at 25% 20%, rgba(255,255,255,0.04) 0%, transparent 55%), radial-gradient(circle at 80% 75%, rgba(255,255,255,0.03) 0%, transparent 50%)',
                  }}
                >
                  <div>
                    {/* Chalkboard Header */}
                    <div className="border-b-2 border-dashed border-[#FAF6EC]/25 pb-2.5 mb-3 flex items-center justify-between gap-2">
                      <h4 className="font-display font-black text-base text-[#FAF6EC] tracking-wide leading-tight drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
                        Secuencia de Ingredientes
                      </h4>
                      <span className="text-[10px] font-bold text-[#FDE68A] border border-[#FDE68A]/35 px-2 py-0.5 rounded bg-[#FDE68A]/10 whitespace-nowrap">
                        Orden exacto
                      </span>
                    </div>

                    {/* Chalk Menu Rows */}
                    <div className="space-y-1.5">
                      {roundConfig.pattern.map((step, idx) => {
                        const ing = BASE_INGREDIENTS.find((b) => b.id === step.id)!;
                        const count = addedCounts[step.id];
                        const isExact = count === step.targetCount;
                        const isOver = count > step.targetCount;
                        const isCurrent = idx === currentPatternIdx;

                        return (
                          <div
                            key={step.id}
                            className={`px-2.5 py-2 rounded-lg border text-xs font-bold flex items-center justify-between transition-all ${
                              isOver
                                ? 'bg-rose-950/75 border-rose-400/70 text-rose-100'
                                : isExact
                                ? 'bg-emerald-950/65 border-emerald-400/60 text-emerald-100'
                                : isCurrent
                                ? 'bg-amber-400/15 border-amber-300/80 text-[#FEF3C7] ring-1 ring-amber-300/40'
                                : 'bg-white/[0.04] border-white/10 text-[#E7E2D8]'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="font-mono font-black text-[11px] text-[#FCD34D] tabular-nums">
                                {idx + 1}.
                              </span>
                              <IngredientObjectSVG
                                id={ing.id}
                                idPrefix={`board-${ing.id}`}
                                isGreenNaan={isGreenNaan}
                                className="w-6 h-6 shrink-0"
                              />
                              <span className="truncate tracking-wide">{ing.shortName}</span>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0 font-mono tabular-nums">
                              <span
                                className={`px-1.5 py-0.5 rounded text-[11px] font-black ${
                                  isOver
                                    ? 'bg-rose-500 text-white'
                                    : isExact
                                    ? 'bg-emerald-500 text-stone-950'
                                    : isCurrent
                                    ? 'bg-amber-300 text-stone-950'
                                    : 'bg-black/40 text-[#FAF6EC]'
                                }`}
                              >
                                {count}/{step.targetCount}
                              </span>
                              {isExact && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                              {isOver && <span title="Exceso">💔</span>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Chalkboard Footer: Calificación del Sabor */}
                  <div className="pt-3 border-t-2 border-dashed border-[#FAF6EC]/20 text-center space-y-1">
                    <div className="text-[11px] font-black uppercase tracking-wider text-[#FDE68A]">
                      Calificación del Sabor
                    </div>
                    <div className="text-2xl flex items-center justify-center gap-2 py-0.5">
                      {getHeartsDisplay().map((h, i) => (
                        <span
                          key={i}
                          className={h === '💔' ? 'scale-110 transition-transform' : ''}
                        >
                          {h}
                        </span>
                      ))}
                    </div>
                    <div className="text-[11px] font-semibold text-[#D6D3CD]">
                      {heartsRemaining === 3
                        ? 'Sabor Maestro (100%)'
                        : heartsRemaining === 2
                        ? 'Sabor Bueno (67%) · 1 corazón roto'
                        : heartsRemaining === 1
                        ? 'Sabor Regular (33%) · 2 corazones rotos'
                        : 'Sabor Desastroso (0%) · 3 corazones rotos'}
                    </div>
                  </div>
                </div>

                {/* Solid Wood Chalk Ledge with Chalk Sticks */}
                <div className="mt-1.5 px-4 py-1 bg-[#482B14] rounded-b-lg border-t border-[#7B4F2B] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-1.5 rounded-xs bg-[#FAF6EC] shadow-xs inline-block rotate-[-2deg]" />
                    <span className="w-5 h-1.5 rounded-xs bg-[#FDE047] shadow-xs inline-block rotate-[3deg]" />
                  </div>
                  <span className="text-[10px] font-bold text-amber-200/70 tracking-wide">
                    Pizarra de Cocina
                  </span>
                </div>
              </div>
            </aside>
          </div>
        )}

        {/* ==================== PHASE 2: STIR SPOON HOLDING CLICK UNTIL GREEN BAR FULL ==================== */}
        {phase === 'MIX_SPOON' && (
          <div className="flex flex-col items-center justify-center w-full max-w-2xl">
            {/* Solid Wood & Slate Mixing Bar */}
            <div className="w-full max-w-lg bg-[#2B1D14]/95 backdrop-blur-md p-4 rounded-3xl border-4 border-[#5E3A1E] shadow-2xl mb-5">
              <div className="flex items-center justify-between mb-2">
                <span className="font-black text-sm sm:text-base text-amber-100 flex items-center gap-2">
                  {mixProgress >= 100
                    ? '¡Bien Mezclado! ¡Bola de masa lista!'
                    : 'Mantén el clic del mouse y mueve la cuchara'}
                </span>
                <span className="font-mono font-black text-sm px-2.5 py-0.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-500/50 tabular-nums">
                  {Math.round(mixProgress)}%
                </span>
              </div>

              {/* Franja Verde de Mezclado */}
              <div className="w-full h-7 bg-[#140F0C] rounded-full overflow-hidden border-2 border-[#6B4527] shadow-inner p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-lime-400 via-emerald-500 to-green-600 transition-all duration-75 flex items-center justify-end pr-2 shadow-sm"
                  style={{ width: `${Math.max(4, mixProgress)}%` }}
                >
                  {mixProgress >= 20 && (
                    <span className="text-[10px] font-black text-white drop-shadow">
                      {mixProgress >= 100 ? '¡LISTO!' : 'MEZCLANDO'}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Interactive Stirring Bowl */}
            <div
              ref={mixArenaRef}
              onPointerDown={(e) => {
                e.preventDefault();
                setIsHoldingSpoon(true);
                lastSpoonPointerRef.current = { x: e.clientX, y: e.clientY };
                if (mixArenaRef.current) {
                  const rect = mixArenaRef.current.getBoundingClientRect();
                  setSpoonPos({
                    x: Math.max(15, Math.min(85, ((e.clientX - rect.left) / rect.width) * 100)),
                    y: Math.max(15, Math.min(85, ((e.clientY - rect.top) / rect.height) * 100)),
                  });
                }
              }}
              onPointerMove={handleSpoonPointerMove}
              className={`relative w-80 h-80 sm:w-96 sm:h-96 rounded-full bg-gradient-to-b from-[#FAF5EE] via-[#E5D7C3] to-[#B79D7E] border-8 border-[#9F8263] shadow-[0_24px_45px_rgba(0,0,0,0.7)] p-6 flex items-center justify-center touch-none ${
                isHoldingSpoon ? 'cursor-grabbing ring-8 ring-emerald-400/50' : 'cursor-grab'
              }`}
            >
              {/* Inner Glazed Bowl */}
              <div className="relative w-full h-full rounded-full bg-[radial-gradient(circle_at_38%_35%,#FBF6EE_0%,#EFE3D0_55%,#CEBBA0_100%)] border-4 border-[#B9A287] shadow-[inset_0_12px_24px_rgba(70,45,20,0.38)] overflow-hidden flex items-center justify-center">
                {/* Rotating Blended Ingredients -> Dough Ball */}
                <svg
                  viewBox="0 0 100 100"
                  style={{ transform: `rotate(${swirlAngle}deg)` }}
                  className="w-full h-full pointer-events-none transition-transform duration-75"
                >
                  <defs>
                    <radialGradient id="stir-dough-grad" cx="40%" cy="35%" r="62%">
                      <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFF7DC'} />
                      <stop
                        offset="60%"
                        stopColor={
                          isGreenNaan
                            ? mixProgress > 70
                              ? '#4ADE80'
                              : '#86EFAC'
                            : mixProgress > 70
                            ? '#F2C97D'
                            : '#FDE68A'
                        }
                      />
                      <stop offset="100%" stopColor={isGreenNaan ? '#15803D' : '#C88A36'} />
                    </radialGradient>
                  </defs>
                  <circle
                    cx="50"
                    cy="50"
                    r={35 - (mixProgress / 100) * 6}
                    fill="url(#stir-dough-grad)"
                    stroke={isGreenNaan ? '#166534' : '#B47221'}
                    strokeWidth={mixProgress > 70 ? 2 : 0.8}
                    opacity={0.96}
                  />
                  {mixProgress < 90 && (
                    <g opacity={1 - mixProgress / 100}>
                      <path
                        d="M 28 50 Q 50 25 72 50 Q 50 75 28 50"
                        fill="none"
                        stroke="#38BDF8"
                        strokeWidth="4"
                        opacity="0.45"
                      />
                      <path
                        d="M 35 38 Q 55 30 65 55"
                        fill="none"
                        stroke="#CA8A04"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                      />
                      <circle cx="42" cy="40" r="2.5" fill="#92400E" />
                      <circle cx="60" cy="56" r="2.2" fill="#92400E" />
                    </g>
                  )}
                  {mixProgress > 45 && (
                    <ellipse
                      cx="43"
                      cy="40"
                      rx="11"
                      ry="6.5"
                      fill="#FFFFFF"
                      opacity={(mixProgress - 45) / 110}
                    />
                  )}
                </svg>

                {/* Sculpted 3D Beechwood Spoon Sprite */}
                <div
                  style={{
                    left: `${spoonPos.x}%`,
                    top: `${spoonPos.y}%`,
                    transform: `translate(-30%, -70%) rotate(${
                      isHoldingSpoon ? Math.sin(swirlAngle * 0.08) * 18 - 25 : -25
                    }deg)`,
                  }}
                  className="absolute z-20 pointer-events-none transition-transform duration-75 drop-shadow-[0_12px_12px_rgba(0,0,0,0.45)]"
                >
                  <svg width="104" height="104" viewBox="0 0 100 100">
                    <defs>
                      <linearGradient id="wood-spoon-handle" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#6B401B" />
                        <stop offset="35%" stopColor="#CFA06B" />
                        <stop offset="65%" stopColor="#9E6A38" />
                        <stop offset="100%" stopColor="#5C3414" />
                      </linearGradient>
                      <radialGradient id="wood-spoon-bowl" cx="38%" cy="35%" r="65%">
                        <stop offset="0%" stopColor="#E6BA86" />
                        <stop offset="60%" stopColor="#A6713E" />
                        <stop offset="100%" stopColor="#5C3414" />
                      </radialGradient>
                    </defs>
                    <rect
                      x="45.5"
                      y="6"
                      width="11"
                      height="58"
                      rx="5.5"
                      fill="url(#wood-spoon-handle)"
                      stroke="#47270D"
                      strokeWidth="2"
                    />
                    <ellipse
                      cx="51"
                      cy="72"
                      rx="17"
                      ry="22"
                      fill="url(#wood-spoon-bowl)"
                      stroke="#47270D"
                      strokeWidth="2"
                    />
                    <ellipse cx="51" cy="73" rx="11" ry="15" fill="#5C3414" opacity="0.35" />
                  </svg>
                </div>

                {!isHoldingSpoon && mixProgress < 100 && (
                  <div className="absolute bottom-4 px-3.5 py-1.5 bg-stone-950/85 text-amber-100 text-xs font-bold rounded-full border border-amber-300/30 pointer-events-none animate-pulse shadow-lg">
                    Mantén clic sostenido aquí y gira
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ==================== PHASE 3: PHYSICAL ROLLING PIN (UP & DOWN) ==================== */}
        {phase === 'ROLL_DOUGH' && (
          <div className="flex flex-col items-center justify-center w-full max-w-2xl">
            {/* Progress Bar Header */}
            <div className="w-full max-w-lg bg-[#2B1D14]/95 backdrop-blur-md p-4 rounded-3xl border-4 border-[#5E3A1E] shadow-2xl mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-black text-sm sm:text-base text-amber-100 flex items-center gap-2">
                  <MoveVertical className="w-5 h-5 text-amber-400 animate-bounce" />
                  {rollProgress >= 100
                    ? '¡Masa perfectamente estirada!'
                    : 'Mueve el rodillo ARRIBA y ABAJO'}
                </span>
                <span className="font-mono font-black text-sm px-2.5 py-0.5 rounded-lg bg-amber-950 text-amber-200 border border-amber-400/50 tabular-nums">
                  {Math.round(rollProgress)}%
                </span>
              </div>
              <div className="w-full h-6 bg-[#140F0C] rounded-full overflow-hidden border-2 border-[#6B4527] shadow-inner p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-400 via-orange-500 to-emerald-500 transition-all duration-75"
                  style={{ width: `${Math.max(4, rollProgress)}%` }}
                />
              </div>
            </div>

            {/* Butcher-Block Wooden Prep Board with Dough Ball -> Flat Dough & Physical Rolling Pin */}
            <div
              ref={rollBoardRef}
              onPointerDown={(e) => {
                e.preventDefault();
                setIsHoldingRoller(true);
                lastRollerYRef.current = e.clientY;
                if (rollBoardRef.current) {
                  const rect = rollBoardRef.current.getBoundingClientRect();
                  setRollerY(
                    Math.max(14, Math.min(86, ((e.clientY - rect.top) / rect.height) * 100))
                  );
                }
              }}
              onPointerMove={handleRollerPointerMove}
              className={`relative w-[340px] h-[340px] sm:w-[440px] sm:h-[380px] rounded-3xl bg-gradient-to-br from-[#DFBC8E] via-[#C69963] to-[#9E6E3B] border-8 border-[#5E3A1E] shadow-[0_24px_45px_rgba(0,0,0,0.7),inset_0_4px_12px_rgba(255,240,210,0.35)] flex items-center justify-center overflow-hidden touch-none ${
                isHoldingRoller ? 'cursor-ns-resize ring-8 ring-amber-400/50' : 'cursor-grab'
              }`}
            >
              {/* Wood flour dusting overlay */}
              <div
                className="absolute inset-0 pointer-events-none opacity-45"
                style={{
                  backgroundImage:
                    'radial-gradient(circle at 25% 30%, #FFFBEB 1px, transparent 10px), radial-gradient(circle at 75% 70%, #FFFBEB 2px, transparent 18px)',
                }}
              />

              {/* Up & Down guide rail */}
              <div className="absolute right-3 inset-y-6 w-2 bg-black/20 rounded-full flex flex-col justify-between items-center py-1 pointer-events-none">
                <span className="text-xs">⬆️</span>
                <span className="text-xs">⬇️</span>
              </div>

              {/* Expanding & Flattening Dough SVG */}
              <div
                style={{
                  transform: `scale(${doughScale})`,
                  filter: `drop-shadow(0px ${doughFlatnessShadow}px ${doughFlatnessShadow}px rgba(62,32,8,0.55))`,
                }}
                className="w-72 h-72 flex items-center justify-center pointer-events-none transition-transform duration-75"
              >
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <defs>
                    <radialGradient id="rolling-dough-grad" cx="42%" cy="38%" r="60%">
                      <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFF5D9'} />
                      <stop offset="65%" stopColor={isGreenNaan ? '#86EFAC' : '#F4D3A1'} />
                      <stop offset="100%" stopColor={isGreenNaan ? '#16A34A' : '#C98F49'} />
                    </radialGradient>
                  </defs>
                  <circle
                    cx="50"
                    cy="50"
                    r="44"
                    fill="url(#rolling-dough-grad)"
                    stroke={isGreenNaan ? '#15803D' : '#A16A28'}
                    strokeWidth={rollProgress > 60 ? 1.5 : 2.8}
                  />
                  <ellipse
                    cx="40"
                    cy="36"
                    rx="14"
                    ry="9"
                    fill="#FFFFFF"
                    opacity={Math.max(0.08, 0.55 - (rollProgress / 100) * 0.45)}
                  />
                </svg>
              </div>

              {/* 3D Shaded Physical Wooden Rolling Pin */}
              <div
                style={{ top: `${rollerY}%` }}
                className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-[86%] pointer-events-none transition-[top] duration-75 drop-shadow-[0_14px_14px_rgba(0,0,0,0.5)]"
              >
                <svg viewBox="0 0 360 64" className="w-full h-auto">
                  <defs>
                    <linearGradient id="roller-wood-cyl" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#F5D39F" />
                      <stop offset="28%" stopColor="#FCE7C2" />
                      <stop offset="65%" stopColor="#C68942" />
                      <stop offset="100%" stopColor="#7A4918" />
                    </linearGradient>
                    <linearGradient id="roller-handle-red" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#F87171" />
                      <stop offset="35%" stopColor="#DC2626" />
                      <stop offset="100%" stopColor="#7F1D1D" />
                    </linearGradient>
                  </defs>
                  {/* Left Handle & Brass Ferrule */}
                  <rect x="6" y="21" width="44" height="22" rx="11" fill="url(#roller-handle-red)" stroke="#450A0A" strokeWidth="2.5" />
                  <rect x="47" y="26" width="11" height="12" fill="#D97706" stroke="#78350F" strokeWidth="1.2" />
                  {/* Right Handle & Brass Ferrule */}
                  <rect x="310" y="21" width="44" height="22" rx="11" fill="url(#roller-handle-red)" stroke="#450A0A" strokeWidth="2.5" />
                  <rect x="302" y="26" width="11" height="12" fill="#D97706" stroke="#78350F" strokeWidth="1.2" />
                  {/* Central Shaded Wooden Roller Cylinder */}
                  <rect
                    x="56"
                    y="10"
                    width="248"
                    height="44"
                    rx="10"
                    fill="url(#roller-wood-cyl)"
                    stroke="#6B3D12"
                    strokeWidth="2.8"
                  />
                  {/* Rolling Woodgrain Band */}
                  <rect
                    x="60"
                    y={14 + ((Math.abs(rollerRollDeg) % 28))}
                    width="240"
                    height="5"
                    rx="2.5"
                    fill="#FFFBEB"
                    opacity="0.55"
                  />
                </svg>
              </div>

              {!isHoldingRoller && rollProgress < 100 && (
                <div className="absolute bottom-3 px-4 py-1.5 bg-stone-950/85 text-amber-100 text-xs font-bold rounded-full border border-amber-300/30 pointer-events-none animate-pulse shadow-lg">
                  Mantén clic sobre la masa y mueve el rodillo ARRIBA y ABAJO
                </div>
              )}
            </div>
          </div>
        )}

        {/* ==================== PHASE 4: GEOMETRIC MOLD SELECTION ==================== */}
        {phase === 'MOLD_SHAPE' && (
          <div className="w-full max-w-lg flex flex-col items-center">
            <div className="w-full bg-[#2B1D14]/95 backdrop-blur-md rounded-3xl border-4 border-[#5E3A1E] p-5 sm:p-6 shadow-2xl flex flex-col items-center text-amber-50">
              <h3 className="font-black text-base sm:text-lg text-amber-100 mb-2 text-center">
                {moldeAplicado
                  ? `¡Masa ${targetShape} (${targetSize}) Lista!`
                  : `4. Elige el Molde (${ICONOS_FORMA[targetShape]} ${targetShape})`}
              </h3>

              <div className="w-56 h-56 sm:w-64 sm:h-64 rounded-full bg-[#C89B66] border-4 border-[#7A5028] shadow-[inset_0_8px_20px_rgba(0,0,0,0.45)] flex items-center justify-center p-4 my-2">
                {moldeAplicado ? (
                  <svg
                    viewBox="0 0 100 100"
                    style={{ transform: `scale(${infoTamano.escalaVisual})` }}
                    className="w-full h-full drop-shadow-xl transition-transform duration-300"
                  >
                    <PizzaBaseLayers
                      shape={targetShape}
                      bakeLevel={0}
                      clipIdPrefix="mixing-final"
                      doughType={pizza.dough}
                    />
                  </svg>
                ) : (
                  <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md">
                    <circle
                      cx="50"
                      cy="50"
                      r="44"
                      fill={isGreenNaan ? '#86EFAC' : '#F4D3A1'}
                      stroke={isGreenNaan ? '#15803D' : '#A87232'}
                      strokeWidth="1.8"
                    />
                  </svg>
                )}
              </div>

              {/* 4 Tactile Steel Pastry Mold Cutters */}
              <div className="grid grid-cols-4 gap-2.5 w-full mt-2">
                {MOLD_OPTIONS.map((mold) => {
                  const isChosen = moldeAplicado && mold.shape === targetShape;
                  return (
                    <button
                      key={mold.shape}
                      onClick={() => aplicarMolde(mold.shape)}
                      disabled={moldeAplicado}
                      className={`p-2.5 border-2 rounded-2xl text-xs font-black flex flex-col items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-md ${
                        isChosen
                          ? 'bg-emerald-950/90 border-emerald-400 ring-2 ring-emerald-300/60 text-emerald-200'
                          : 'bg-[#3D2A1D] hover:bg-[#4F3626] border-[#785338] hover:border-amber-400 text-amber-100'
                      }`}
                    >
                      <svg viewBox="0 0 100 100" className="w-9 h-9 drop-shadow">
                        {mold.shape === 'Circular' && (
                          <circle cx="50" cy="50" r="38" fill="#E2E8F0" fillOpacity="0.18" stroke="#CBD5E1" strokeWidth="7" />
                        )}
                        {mold.shape === 'Cuadrado' && (
                          <rect x="14" y="14" width="72" height="72" rx="10" fill="#E2E8F0" fillOpacity="0.18" stroke="#CBD5E1" strokeWidth="7" />
                        )}
                        {mold.shape === 'Estrella' && (
                          <polygon points={STAR_POINTS_100} fill="#E2E8F0" fillOpacity="0.18" stroke="#CBD5E1" strokeWidth="6" strokeLinejoin="round" />
                        )}
                        {mold.shape === 'Corazón' && (
                          <path d={HEART_PATH_100} fill="#E2E8F0" fillOpacity="0.18" stroke="#CBD5E1" strokeWidth="6" strokeLinejoin="round" />
                        )}
                      </svg>
                      <span>{mold.label}</span>
                    </button>
                  );
                })}
              </div>

              {feedbackMolde && (
                <p
                  className={`text-xs sm:text-sm mt-3 font-extrabold text-center ${
                    feedbackMolde.tone === 'error' ? 'text-rose-300' : 'text-emerald-300'
                  }`}
                >
                  {feedbackMolde.text}
                </p>
              )}

              {moldeAplicado && (
                <button
                  onClick={() => {
                    sounds.playDoughSlap();
                    onMoveToKitchen();
                  }}
                  className="mt-4 w-full bg-amber-400 hover:bg-amber-300 active:scale-95 text-stone-950 font-black py-3.5 px-4 rounded-2xl text-sm sm:text-base shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>¡Ir a poner Salsa, Toppings, Horno y Corte!</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating Held Dimensional Ingredient Sprite Following Mouse Cursor */}
      {heldIng && phase === 'INGREDIENTS' && (
        <div
          style={{
            left: pointerPos.x,
            top: pointerPos.y,
            transform: `translate(-50%, -50%) rotate(${isHoveringBowl ? -24 : -10}deg) scale(1.18)`,
          }}
          className="fixed z-50 pointer-events-none flex flex-col items-center transition-transform duration-100"
        >
          <IngredientObjectSVG
            id={heldIng.id}
            idPrefix={`floating-${heldIng.id}`}
            isGreenNaan={isGreenNaan}
            className="w-20 h-20 drop-shadow-[0_14px_14px_rgba(0,0,0,0.55)]"
          />
          <span className="-mt-1 px-2.5 py-0.5 bg-stone-950/90 text-amber-200 text-[11px] font-black rounded-md border border-amber-300/40 shadow-lg">
            {heldIng.shortName}
          </span>
        </div>
      )}
    </div>
  );
};
