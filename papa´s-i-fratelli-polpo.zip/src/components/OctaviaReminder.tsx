import React from 'react';
import { CustomerOrder } from '../types/pizza';
import { ICONOS_FORMA } from '../utils/pizzaGeometry';
import { TOPPING_NAMES } from '../data/customers';
import { Clock } from 'lucide-react';
import { WoodParchmentBoard } from './WoodParchmentBoard';

interface OctaviaReminderProps {
  order: CustomerOrder;
  customerPatience: number;
  clarifiedOrder: boolean;
  isOpen: boolean;
  onToggle: () => void;
}

export const OctaviaReminder: React.FC<OctaviaReminderProps> = ({
  order,
  customerPatience,
  clarifiedOrder,
  isOpen,
  onToggle,
}) => {
  const patiencePercentage = Math.min(
    100,
    Math.max(0, (customerPatience / order.patienceTotal) * 100)
  );

  if (!isOpen) {
    return (
      <div className="absolute top-14 left-4 z-40 select-none">
        <button
          onClick={onToggle}
          className="text-left transition-transform hover:scale-105 active:scale-95 cursor-pointer group"
          title="Ver recordatorio de Octavia"
        >
          <WoodParchmentBoard variant="plank" compact showHerbs={false} showDoodles={false}>
            <div className="flex items-center gap-2.5 pr-1">
              <div className="w-9 h-9 rounded-full border-2 border-[#6B3B17] bg-[#FFF8E7] overflow-hidden shrink-0 shadow-sm flex items-center justify-center">
                <img
                  src="/assets/aistudio/image.png_eaf546b8_57de311c.jpg"
                  alt="Octavia"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[11px] font-display font-bold text-[#3A1E0D] leading-tight">
                  Octavia dice
                </span>
                <span className="text-[10px] font-semibold text-[#6E4427] leading-tight">
                  Ver pedido ({order.customerName.split(' ')[0]})
                </span>
              </div>
            </div>
          </WoodParchmentBoard>
        </button>
      </div>
    );
  }

  return (
    <div className="absolute top-13 left-2 sm:left-3 z-40 w-[calc(100vw-1rem)] max-w-[440px] sm:max-w-[560px] select-none transition-all duration-300 animate-in fade-in slide-in-from-top-2">
      <div className="relative flex items-start gap-2 sm:gap-2.5">
        {/* Octavia Character Figure */}
        <div className="relative shrink-0 flex flex-col items-center mt-2">
          <div className="w-14 sm:w-16 h-18 sm:h-22 rounded-xl overflow-hidden bg-[#FFF9EC] border-[3px] border-[#5D290D] shadow-lg relative flex items-center justify-center p-0.5">
            <img
              src="/assets/aistudio/image.png_eaf546b8_57de311c.jpg"
              alt="Octavia Chef"
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
            <div className="absolute bottom-0 inset-x-0 bg-[#5D290D] text-[#FEF3C7] text-[8px] font-display font-bold py-[1px] text-center tracking-wider uppercase">
              Octavia 🐙
            </div>
          </div>
        </div>

        {/* Wood Plank & Curled Parchment Reminder Board */}
        <WoodParchmentBoard
          variant="plank"
          compact
          pointerPosition="left"
          onClose={onToggle}
          closeTitle="Minimizar recordatorio"
          className="flex-1 min-w-0"
          innerClassName="text-[#3A1E0D]"
        >
          {/* Header Row: Name + Inline Patience */}
          <div className="flex items-center justify-between gap-2 border-b border-[#C8A16B]/60 pb-1.5 mb-2 pr-4">
            <div className="flex items-center gap-1.5 min-w-0">
              <span className="text-xs sm:text-sm font-display font-extrabold text-[#3A1E0D] truncate">
                {order.customerName}
              </span>
              {order.menuOrderTitle && (
                <span className="px-2 py-0.5 bg-amber-100/90 border border-[#C68E4E] rounded text-[11px] font-extrabold text-[#5D290D] shrink-0">
                  {order.customerType === 'cavernicola'
                    ? '🦴'
                    : order.customerType === 'faraon'
                    ? '👑'
                    : order.customerType === 'momia'
                    ? '🏺'
                    : order.customerType === 'sabio_india'
                    ? '🧘🏽‍♂️'
                    : '🍕'}{' '}
                  {order.menuOrderTitle}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Inline Mini Patience Meter */}
              <div className="flex items-center gap-1.5 bg-[#EFE0BA]/85 px-2 py-0.5 rounded-md border border-[#B88B52]">
                <Clock className="w-3 h-3 text-[#6E4427]" />
                <div className="w-10 h-1.5 bg-[#D4B98A] rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      customerPatience > 40
                        ? 'bg-emerald-600'
                        : customerPatience > 20
                        ? 'bg-amber-600'
                        : 'bg-rose-600 animate-pulse'
                    }`}
                    style={{ width: `${patiencePercentage}%` }}
                  />
                </div>
                <span className="font-mono text-[11px] font-extrabold text-[#3A1E0D] tabular-nums">
                  {Math.round(patiencePercentage)}%
                </span>
              </div>
            </div>
          </div>

          {/* Comfortable Stacked Reading Layout (Full-width quote + clear clue chips) */}
          <div className="flex flex-col gap-2">
            {/* Customer Dialogue Quote */}
            <div className="bg-[#FFFBF0]/80 px-3 py-2 rounded-lg border border-[#D4AE74]">
              <p
                className="text-[13px] sm:text-sm font-semibold leading-relaxed text-[#2F1608] tracking-[0.005em]"
                title={clarifiedOrder ? order.clarification : order.dialogue}
              >
                &ldquo;{clarifiedOrder ? order.clarification : order.dialogue}&rdquo;
              </p>
            </div>

            {/* Recipe Quick Clues Strip */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs leading-snug">
              {order.recipe.dough === 'naan_verde' && (
                <span className="px-2.5 py-0.5 bg-emerald-100 border border-emerald-400 rounded-md font-bold text-emerald-950">
                  🌿 Masa: Naan Verde
                </span>
              )}
              {order.recipe.size && order.recipe.shape && (
                <span className="px-2.5 py-0.5 bg-indigo-100 border border-indigo-300 rounded-md font-bold text-indigo-950">
                  {ICONOS_FORMA[order.recipe.shape]}{' '}
                  {(order.customerType === 'faraon' || order.customerType === 'momia') &&
                  !clarifiedOrder
                    ? `${order.iconoEgipcio || ''} ${order.medidaEgipcia || order.recipe.size}`
                    : order.recipe.size}{' '}
                  · {order.recipe.shape}
                </span>
              )}
              <span className="px-2.5 py-0.5 bg-stone-100 border border-stone-300 rounded-md font-bold text-stone-900">
                Salsa:{' '}
                {order.recipe.sauce === 'none'
                  ? 'No'
                  : order.recipe.sauce === 'whole'
                  ? 'Sí'
                  : order.recipe.sauce === 'left'
                  ? 'Izq.'
                  : 'Der.'}
              </span>
              <span className="px-2.5 py-0.5 bg-stone-100 border border-stone-300 rounded-md font-bold text-stone-900">
                Queso:{' '}
                {order.recipe.cheese === 'none'
                  ? 'No'
                  : order.recipe.cheese === 'whole'
                  ? 'Sí'
                  : order.recipe.cheese === 'left'
                  ? 'Izq.'
                  : 'Der.'}
              </span>
              <span className="px-2.5 py-0.5 bg-stone-100 border border-stone-300 rounded-md font-bold text-stone-900 font-mono">
                {order.recipe.cuts === 0
                  ? 'Sin cortar'
                  : order.customerType === 'cavernicola' && !clarifiedOrder
                  ? `[ ${Array(order.recipe.cuts).fill('|').join(' ')} ]`
                  : `${order.recipe.cuts} porc.`}
              </span>
              {order.recipe.bakeLevel === 2 && (
                <span className="px-2.5 py-0.5 bg-amber-100 border border-amber-400 rounded-md font-bold text-amber-950">
                  Horno x2
                </span>
              )}
              {order.toppingsDetail &&
                order.toppingsDetail.map((t) => (
                  <span
                    key={t.id}
                    className="px-2.5 py-0.5 bg-orange-100 border border-orange-300 rounded-md font-bold text-orange-950 font-mono"
                  >
                    {clarifiedOrder ? t.cantidadReal : t.simbolo} × {t.nombre}
                  </span>
                ))}
              {order.sabioZeroChallenge && !clarifiedOrder && (
                <>
                  <span className="px-2.5 py-0.5 bg-purple-200 border border-purple-400 rounded-md font-bold text-purple-950">
                    Lista del Sabio (Otros = {order.sabioZeroChallenge.cantidadPorCadaUno} c/u):
                  </span>
                  {order.sabioZeroChallenge.poolToppings.map((t) => {
                    const isZero = order.sabioZeroChallenge?.descartados.includes(t);
                    return (
                      <span
                        key={`sabio-pool-${t}`}
                        className={`px-2.5 py-0.5 rounded-md font-bold border capitalize ${
                          isZero
                            ? 'bg-rose-100 border-rose-300 text-rose-950'
                            : 'bg-purple-50 border-purple-300 text-purple-950'
                        }`}
                      >
                        {isZero ? '0 × ' : ''}
                        {TOPPING_NAMES[t] || t}
                      </span>
                    );
                  })}
                </>
              )}
              {order.sabioZeroChallenge && clarifiedOrder && (
                <>
                  {order.sabioZeroChallenge.requeridos.map((t) => (
                    <span
                      key={`sabio-req-${t}`}
                      className="px-2.5 py-0.5 bg-emerald-100 border border-emerald-400 rounded-md font-bold text-emerald-950 font-mono capitalize"
                    >
                      {order.sabioZeroChallenge?.cantidadPorCadaUno} × {TOPPING_NAMES[t] || t}
                    </span>
                  ))}
                </>
              )}
            </div>
          </div>
        </WoodParchmentBoard>
      </div>
    </div>
  );
};
