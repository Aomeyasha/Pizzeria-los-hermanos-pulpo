import React from 'react';
import { DayFinancials } from '../types/pizza';
import { sounds } from '../services/soundEffects';
import { WoodParchmentBoard } from './WoodParchmentBoard';
import { DollarSign, ShoppingBag, ArrowRight, TrendingUp, TrendingDown, Pizza } from 'lucide-react';

interface DaySummaryModalProps {
  dayNumber: number;
  financials: DayFinancials;
  totalCash: number;
  onOpenShop: () => void;
  onNextDay: () => void;
}

export const DaySummaryModal: React.FC<DaySummaryModalProps> = ({
  dayNumber,
  financials,
  totalCash,
  onOpenShop,
  onNextDay,
}) => {
  const isProfitable = financials.netProfit >= 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/65 backdrop-blur-xs select-none animate-in fade-in">
      <WoodParchmentBoard
        variant="vertical"
        className="w-full max-w-lg"
        innerClassName="max-h-[84vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="text-center border-b-2 border-[#C8A16B]/60 pb-4">
          <span className="text-xs font-bold uppercase tracking-wider text-[#9A231B]">
            Resumen Diario
          </span>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#3A1E0D] mt-0.5">
            Balance del Día {dayNumber}
          </h2>
          <p className="text-xs text-[#6E4427] mt-1 font-medium">
            La pizzería ha cerrado sus puertas por hoy. ¡Veamos los números!
          </p>
        </div>

        {/* Daily Stats counters */}
        <div className="grid grid-cols-2 gap-3 my-4">
          <div className="flex items-center gap-3 bg-[#EFE0BA]/85 p-3 rounded-xl border border-[#C69B61]">
            <div className="p-2 bg-emerald-100 rounded-lg text-emerald-800 border border-emerald-300">
              <Pizza className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-[#6E4427]">Pizzas Servidas</div>
              <div className="text-lg font-bold font-mono text-[#3A1E0D]">
                {financials.pizzasCompleted}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#EFE0BA]/85 p-3 rounded-xl border border-[#C69B61]">
            <div className="p-2 bg-amber-100 rounded-lg text-amber-800 border border-amber-300">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-[#6E4427]">Fondos Actuales</div>
              <div className="text-lg font-bold font-mono text-emerald-800">
                ${totalCash.toFixed(2)}
              </div>
            </div>
          </div>
        </div>

        {/* Financial Accounting ledger */}
        <div className="bg-[#FFFBF0]/85 rounded-xl border border-[#D4AE74] p-4 space-y-2 text-xs sm:text-sm">
          <div className="flex justify-between items-center text-[#5D290D]">
            <span>Ingresos por Pizzas:</span>
            <span className="font-mono font-semibold text-[#3A1E0D]">
              +${financials.grossIncome.toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between items-center text-[#5D290D]">
            <span>Propinas recibidas:</span>
            <span className="font-mono font-semibold text-emerald-700">
              +${financials.tipsIncome.toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between items-center text-[#5D290D]">
            <span>Gasto en Ingredientes:</span>
            <span className="font-mono font-semibold text-rose-700">
              -${financials.ingredientsCost.toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between items-center text-[#5D290D]">
            <span>Alquiler del Local:</span>
            <span className="font-mono font-semibold text-rose-700">
              -${financials.rent.toFixed(2)}
            </span>
          </div>

          {/* Divider */}
          <div className="border-t border-[#C8A16B] pt-2 flex justify-between items-center font-bold text-sm sm:text-base">
            <span className="text-[#3A1E0D]">Beneficio Neto:</span>
            <span
              className={`font-mono flex items-center gap-1 ${
                isProfitable ? 'text-emerald-800' : 'text-rose-700'
              }`}
            >
              {isProfitable ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
              {isProfitable ? '+' : ''}${financials.netProfit.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            onClick={() => {
              sounds.playChaChing();
              onOpenShop();
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#EFE0BA] hover:bg-[#E7D09B] text-[#5D290D] font-display font-bold text-xs sm:text-sm rounded-xl border border-[#B88B52] transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4 text-[#8C4D1E]" />
            Tienda de Mejoras
          </button>

          <button
            onClick={() => {
              sounds.playBellDing();
              onNextDay();
            }}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-xs sm:text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            Siguiente Día (Día {dayNumber + 1})
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </WoodParchmentBoard>
    </div>
  );
};
