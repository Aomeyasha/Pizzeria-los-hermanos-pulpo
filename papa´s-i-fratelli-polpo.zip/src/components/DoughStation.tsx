import React, { useState, useEffect, useRef } from 'react';
import { CustomerOrder, DoughType, GameUpgrades, PizzaShape, PizzaSize, PizzaState } from '../types/pizza';
import { CATALOGO_TAMANOS, ICONOS_FORMA } from '../utils/pizzaGeometry';
import { sounds } from '../services/soundEffects';
import { ArrowRight, RotateCcw, Lock } from 'lucide-react';
import { WoodParchmentBoard } from './WoodParchmentBoard';

interface DoughStationProps {
  pizza: PizzaState;
  order: CustomerOrder | null;
  upgrades?: GameUpgrades;
  restoredFromEgyptian?: boolean;
  onUpdatePizza: (updater: (prev: PizzaState) => PizzaState) => void;
  onMoveToMixing: () => void;
}

type SpoonSize = 5 | 10 | 50;

interface MeasuringSpoonDef {
  amount: SpoonSize;
  name: string;
  shortLabel: string;
  scaleFactor: number;
  widthPx: number;
  heightPx: number;
}

const MEASURING_SPOONS: MeasuringSpoonDef[] = [
  {
    amount: 5,
    name: 'Chica',
    shortLabel: '+5 g',
    scaleFactor: 0.82,
    widthPx: 92,
    heightPx: 148,
  },
  {
    amount: 10,
    name: 'Mediana',
    shortLabel: '+10 g',
    scaleFactor: 0.96,
    widthPx: 108,
    heightPx: 170,
  },
  {
    amount: 50,
    name: 'Grande',
    shortLabel: '+50 g',
    scaleFactor: 1.12,
    widthPx: 126,
    heightPx: 194,
  },
];

const SIZE_STANDARDS: {
  size: PizzaSize;
  grams: number;
  price: string;
  dotColor: string;
}[] = [
  { size: 'Pequeña', grams: 150, price: '$12.00', dotColor: 'bg-emerald-400' },
  { size: 'Mediana', grams: 300, price: '$22.00', dotColor: 'bg-sky-400' },
  { size: 'Familiar', grams: 450, price: '$34.00', dotColor: 'bg-violet-400' },
];

/**
 * Detailed 3D brushed stainless-steel measuring spoon SVG with flour scoop,
 * metallic speculars, neck curvature, eyelet stamp, and contact shadow.
 */
const MetallicSpoonSVG: React.FC<{
  amount: SpoonSize;
  idPrefix: string;
  className?: string;
  isPouring?: boolean;
  isGreenNaan?: boolean;
}> = ({ amount, idPrefix, className = '', isPouring = false, isGreenNaan = false }) => {
  const bowlRx = amount === 5 ? 20 : amount === 10 ? 25 : 31;
  const bowlRy = amount === 5 ? 25 : amount === 10 ? 31 : 37;
  const handleWidth = amount === 5 ? 9 : amount === 10 ? 11 : 13.5;
  const flourRx = bowlRx * 0.78;
  const flourRy = bowlRy * 0.72;

  return (
    <svg
      viewBox="0 0 120 200"
      className={className}
      aria-hidden="true"
    >
      <defs>
        {/* Brushed stainless-steel handle gradient */}
        <linearGradient id={`${idPrefix}-steel-handle`} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#64748B" />
          <stop offset="22%" stopColor="#E2E8F0" />
          <stop offset="45%" stopColor="#FFFFFF" />
          <stop offset="68%" stopColor="#94A3B8" />
          <stop offset="88%" stopColor="#CBD5E1" />
          <stop offset="100%" stopColor="#475569" />
        </linearGradient>

        {/* Outer metallic rim bevel */}
        <linearGradient id={`${idPrefix}-steel-rim`} x1="15%" y1="0%" x2="85%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="28%" stopColor="#CBD5E1" />
          <stop offset="55%" stopColor="#64748B" />
          <stop offset="80%" stopColor="#E2E8F0" />
          <stop offset="100%" stopColor="#334155" />
        </linearGradient>

        {/* Deep concave steel bowl */}
        <radialGradient id={`${idPrefix}-steel-bowl`} cx="38%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#475569" />
          <stop offset="42%" stopColor="#94A3B8" />
          <stop offset="76%" stopColor="#CBD5E1" />
          <stop offset="94%" stopColor="#64748B" />
          <stop offset="100%" stopColor="#334155" />
        </radialGradient>

        {/* Soft sifted flour mound (cream or vibrant green Naan) */}
        <radialGradient id={`${idPrefix}-flour-heap`} cx="40%" cy="34%" r="64%">
          <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFFFFF'} />
          <stop offset="55%" stopColor={isGreenNaan ? '#86EFAC' : '#FEF9EE'} />
          <stop offset="85%" stopColor={isGreenNaan ? '#4ADE80' : '#EFE3CA'} />
          <stop offset="100%" stopColor={isGreenNaan ? '#16A34A' : '#D6C3A0'} />
        </radialGradient>

        {/* Realistic table cast shadow */}
        <filter id={`${idPrefix}-drop`} x="-30%" y="-20%" width="160%" height="150%">
          <feDropShadow dx="3" dy="8" stdDeviation="4.5" floodColor="#090705" floodOpacity="0.62" />
        </filter>
      </defs>

      <g filter={`url(#${idPrefix}-drop)`}>
        {/* Back/lower handle silhouette for 3D thickness */}
        <path
          d={`M ${60 - handleWidth / 2 - 1} 76
             L ${60 - handleWidth / 2 - 0.5} 174
             Q ${60 - handleWidth / 2} 190 60 190
             Q ${60 + handleWidth / 2} 190 ${60 + handleWidth / 2 + 0.5} 174
             L ${60 + handleWidth / 2 + 1} 76 Z`}
          fill="#334155"
          transform="translate(1.5, 2.5)"
        />

        {/* Metallic Spoon Bowl Outer Rim (3D beveled edge) */}
        <ellipse
          cx="60"
          cy="52"
          rx={bowlRx + 4}
          ry={bowlRy + 4}
          fill={`url(#${idPrefix}-steel-rim)`}
          stroke="#1E293B"
          strokeWidth="1.2"
        />

        {/* Metallic Spoon Bowl Concave Cavity */}
        <ellipse
          cx="60"
          cy="53"
          rx={bowlRx}
          ry={bowlRy}
          fill={`url(#${idPrefix}-steel-bowl)`}
        />

        {/* Specular highlight arc inside metallic rim */}
        <path
          d={`M ${60 - bowlRx * 0.72} ${53 - bowlRy * 0.45}
             A ${bowlRx * 0.85} ${bowlRy * 0.85} 0 0 1 ${60 + bowlRx * 0.58} ${53 - bowlRy * 0.62}`}
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="1.8"
          strokeLinecap="round"
          opacity="0.7"
        />

        {/* Flour Heap Inside Spoon Bowl */}
        <g opacity={isPouring ? 0.45 : 1}>
          {/* Shadow beneath flour mound */}
          <ellipse
            cx="61.5"
            cy="56"
            rx={flourRx + 1.5}
            ry={flourRy + 1}
            fill="#1E293B"
            opacity="0.28"
          />
          {/* Main organic flour scoop */}
          <ellipse
            cx="60"
            cy="53"
            rx={flourRx}
            ry={flourRy}
            fill={`url(#${idPrefix}-flour-heap)`}
          />
          {/* Peak highlight */}
          <ellipse
            cx={60 - flourRx * 0.22}
            cy={53 - flourRy * 0.24}
            rx={flourRx * 0.48}
            ry={flourRy * 0.42}
            fill={isGreenNaan ? '#DCFCE7' : '#FFFFFF'}
            opacity="0.85"
          />
          {/* Fine flour grain flecks */}
          <circle cx={60 + flourRx * 0.35} cy={53 + flourRy * 0.22} r="1.2" fill={isGreenNaan ? '#15803D' : '#E7D7B9'} />
          <circle cx={60 - flourRx * 0.4} cy={53 + flourRy * 0.3} r="1" fill={isGreenNaan ? '#FEF08A' : '#E7D7B9'} />
          <circle cx={60 + flourRx * 0.12} cy={53 - flourRy * 0.48} r="1" fill={isGreenNaan ? '#FDE047' : '#FFFFFF'} />
        </g>

        {/* Contoured Neck Weld */}
        <path
          d={`M ${60 - handleWidth * 0.72} ${52 + bowlRy - 3}
             Q 60 ${52 + bowlRy + 7} ${60 + handleWidth * 0.72} ${52 + bowlRy - 3}
             L ${60 + handleWidth * 0.52} ${52 + bowlRy + 12}
             L ${60 - handleWidth * 0.52} ${52 + bowlRy + 12} Z`}
          fill={`url(#${idPrefix}-steel-handle)`}
          stroke="#475569"
          strokeWidth="0.9"
        />

        {/* Brushed Stainless Handle */}
        <path
          d={`M ${60 - handleWidth * 0.52} ${52 + bowlRy + 8}
             L ${60 - handleWidth * 0.62} 174
             Q ${60 - handleWidth * 0.62} 189 60 189
             Q ${60 + handleWidth * 0.62} 189 ${60 + handleWidth * 0.62} 174
             L ${60 + handleWidth * 0.52} ${52 + bowlRy + 8} Z`}
          fill={`url(#${idPrefix}-steel-handle)`}
          stroke="#334155"
          strokeWidth="1"
        />

        {/* Center Ridge Highlight along Metallic Handle */}
        <line
          x1="60"
          y1={52 + bowlRy + 12}
          x2="60"
          y2="167"
          stroke="#FFFFFF"
          strokeWidth="1.5"
          strokeLinecap="round"
          opacity="0.72"
        />

        {/* Engraved Capacity Stamp on Handle */}
        <rect
          x={60 - handleWidth * 0.42}
          y="134"
          width={handleWidth * 0.84}
          height="16"
          rx="3"
          fill="#1E293B"
          opacity="0.22"
        />

        {/* Hanging Eyelet Hole at End of Metallic Handle */}
        <circle cx="60" cy="178" r="3.4" fill="#1E293B" stroke="#E2E8F0" strokeWidth="1" />
        <circle cx="60" cy="178" r="2.2" fill="#0F172A" opacity="0.75" />
      </g>
    </svg>
  );
};

/**
 * Dotted Body-Part Silhouette SVG matching the 3 reference shapes in image_4a13d1bc.png:
 * - Pequeña: 1 Mano Extendida (open 5-finger hand)
 * - Mediana: 1 Codo (bent forearm-to-elbow)
 * - Familiar: 2 Codos (paired double-limb silhouette)
 * Progressively fills with golden-white sifted flour inside the dotted outline.
 */
const EgyptianSilhouetteSVG: React.FC<{
  size: PizzaSize;
  progress: number; // 0 to 1.2
  isOverfilled: boolean;
  isExact: boolean;
  isHoveringTarget: boolean;
}> = ({ size, progress, isOverfilled, isExact, isHoveringTarget }) => {
  const clamped = Math.max(0, Math.min(progress, 1));
  const fillHeight = Math.round(220 * clamped);
  const fillY = 220 - fillHeight;

  const renderShapePath = () => {
    if (size === 'Pequeña') {
      // Open 5-finger hand matching left silhouette of reference image
      return (
        <path
          d="M 118 206
             L 118 148
             C 104 134 86 112 88 102
             C 90 92 102 96 114 112
             L 106 58
             C 104 46 116 44 119 56
             L 130 98
             L 130 38
             C 130 26 144 26 144 38
             L 144 96
             L 156 34
             C 158 22 172 24 170 36
             L 162 98
             L 179 44
             C 183 32 196 36 192 48
             L 176 110
             L 196 92
             C 205 84 216 94 207 104
             L 176 148
             L 176 206 Z"
        />
      );
    }

    if (size === 'Mediana') {
      // Bent arm / 1 Codo matching center silhouette of reference image
      return (
        <path
          d="M 142 28
             Q 174 20 190 32
             L 202 88
             L 170 184
             L 176 200
             L 124 186
             L 134 172
             L 162 88
             L 142 36 Z"
        />
      );
    }

    // Paired double limbs / 2 Codos matching right silhouette of reference image
    return (
      <path
        d="M 92 34
           Q 122 22 150 38
           Q 178 22 208 34
           L 198 82
           L 216 178
           Q 216 204 192 204
           Q 168 204 166 178
           L 150 96
           L 128 178
           L 134 198
           L 78 188
           L 90 168
           L 108 86 Z"
      />
    );
  };

  const outlineColor = isOverfilled
    ? '#FB7185'
    : isExact
    ? '#34D399'
    : isHoveringTarget
    ? '#FBBF24'
    : '#1E293B';

  return (
    <svg viewBox="0 0 300 225" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="egypt-flour-fill" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="48%" stopColor="#FEF7E6" />
          <stop offset="85%" stopColor="#F3DCAC" />
          <stop offset="100%" stopColor="#D9B879" />
        </linearGradient>
        <filter id="egypt-silhouette-shadow" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="6" stdDeviation="5" floodColor="#0F0904" floodOpacity="0.45" />
        </filter>
        <clipPath id={`clip-egypt-${size}`}>
          <rect x="0" y={fillY} width="300" height={fillHeight + 10} />
        </clipPath>
      </defs>

      <g filter="url(#egypt-silhouette-shadow)">
        {/* Light frosted silhouette template fill (matching reference image tone) */}
        <g fill="#E0F2FE" fillOpacity="0.86" stroke="#BAE6FD" strokeWidth="7" strokeLinejoin="round">
          {renderShapePath()}
        </g>

        {/* Progressive sifted flour filling inside dotted outline */}
        {clamped > 0 && (
          <g clipPath={`url(#clip-egypt-${size})`}>
            <g
              fill={isOverfilled ? '#FECDD3' : 'url(#egypt-flour-fill)'}
              stroke={isOverfilled ? '#E11D48' : '#D97706'}
              strokeWidth="2.5"
              strokeLinejoin="round"
            >
              {renderShapePath()}
            </g>
            {/* Subtle sifted flour specks */}
            <g fill="#FFFFFF" opacity="0.85">
              <circle cx="145" cy="145" r="2.2" />
              <circle cx="162" cy="128" r="1.8" />
              <circle cx="136" cy="170" r="2" />
              <circle cx="155" cy="92" r="1.6" />
            </g>
          </g>
        )}

        {/* Crisp dashed outline matching reference image */}
        <g
          fill="none"
          stroke={outlineColor}
          strokeWidth="3.5"
          strokeDasharray="7 5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {renderShapePath()}
        </g>
      </g>
    </svg>
  );
};

export const DoughStation: React.FC<DoughStationProps> = ({
  pizza,
  order,
  upgrades,
  restoredFromEgyptian = false,
  onUpdatePizza,
  onMoveToMixing,
}) => {
  const isEgyptianVisitor =
    order?.customerType === 'faraon' || order?.customerType === 'momia';
  const isGreenNaan = pizza.dough === 'naan_verde';
  const naanVerdeUnlocked = Boolean(upgrades?.naanVerdeFlour);
  const targetSize: PizzaSize = order?.recipe.size || pizza.size || 'Mediana';
  const targetShape: PizzaShape = order?.recipe.shape || pizza.shape || 'Circular';
  const infoTamano = CATALOGO_TAMANOS[targetSize];

  const handleSelectDoughType = (nextType: DoughType) => {
    if (nextType === 'naan_verde' && !naanVerdeUnlocked) {
      sounds.playReaction('meh');
      setFeedbackGramera({
        text: '🔒 La Harina Naan Verde se compra primero en la Tienda de Mejoras (disponible desde el Día 4).',
        tone: 'error',
      });
      return;
    }
    sounds.playToppingPop(0.8);
    onUpdatePizza((prev) => ({
      ...prev,
      dough: nextType,
    }));
    setFeedbackGramera({
      text:
        nextType === 'naan_verde'
          ? '🌿 Seleccionaste Harina Naan Verde (pan plano con ghee y ajo). ¡Ahora pesa la harina!'
          : '🌾 Seleccionaste Harina Tradicional. ¡Ahora pesa la harina!',
      tone: 'success',
    });
  };

  const [harinaEnGramera, setHarinaEnGramera] = useState<number>(
    pizza.flourWeighed ? pizza.harinaEnGramera || infoTamano.harinaRequerida : 0
  );
  const [brokenHearts, setBrokenHearts] = useState<number>(
    pizza.doughScore < 100 ? Math.min(3, Math.round(((100 - pizza.doughScore) / 100) * 3)) : 0
  );
  const [toquesSilueta, setToquesSilueta] = useState<number>(
    pizza.flourWeighed && isEgyptianVisitor ? infoTamano.toquesSilueta : 0
  );
  const [holdingEgyptScoop, setHoldingEgyptScoop] = useState<boolean>(false);
  const [hoveringSilhouette, setHoveringSilhouette] = useState<boolean>(false);
  const silhouetteZoneRef = useRef<HTMLDivElement | null>(null);

  const [heartBreakFlash, setHeartBreakFlash] = useState<boolean>(false);
  const [pourFlash, setPourFlash] = useState<boolean>(false);
  const [feedbackGramera, setFeedbackGramera] = useState<{
    text: string;
    tone: 'neutral' | 'error' | 'success';
  }>({
    text: pizza.flourWeighed
      ? `¡Listo! Pesaste ${pizza.harinaEnGramera || infoTamano.harinaRequerida} g de harina.`
      : isEgyptianVisitor
      ? `Toca "+ Añadir Harina" o arrastra un puñado hasta cubrir toda la silueta punteada (${infoTamano.medidaEgipcia}).`
      : `Agarra una cuchara metálica (+5, +10 o +50 g) con el mouse y échala al tazón de la gramera.`,
    tone: pizza.flourWeighed ? 'success' : 'neutral',
  });

  // Mouse grab / drag-and-drop state for the 3 metallic spoons
  const [heldSpoon, setHeldSpoon] = useState<MeasuringSpoonDef | null>(null);
  const [pointerPos, setPointerPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isHoveringBowl, setIsHoveringBowl] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);
  const scaleBowlRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!pizza.flourWeighed && !pizza.doughCompleted) {
      setHarinaEnGramera(0);
      setToquesSilueta(0);
      setBrokenHearts(0);
      setHeldSpoon(null);
      setHoldingEgyptScoop(false);
      setIsHoveringBowl(false);
      setHoveringSilhouette(false);
      setFeedbackGramera({
        text: isEgyptianVisitor
          ? `Echa harina sobre la silueta punteada de "${infoTamano.medidaEgipcia}" (${infoTamano.toquesSilueta} puñados).`
          : `Agarra una cuchara metálica (+5, +10 o +50 g) con el mouse y échala al tazón de la gramera.`,
        tone: 'neutral',
      });
    }
  }, [pizza.id, pizza.flourWeighed, pizza.doughCompleted, isEgyptianVisitor, infoTamano.medidaEgipcia, infoTamano.toquesSilueta]);

  const heartsRemaining = Math.max(0, 3 - brokenHearts);
  const isOverweight = isEgyptianVisitor
    ? toquesSilueta > infoTamano.toquesSilueta
    : harinaEnGramera > infoTamano.harinaRequerida;
  const isExactWeight = isEgyptianVisitor
    ? toquesSilueta === infoTamano.toquesSilueta
    : harinaEnGramera === infoTamano.harinaRequerida;
  const fillRatio = Math.min(1.25, harinaEnGramera / infoTamano.harinaRequerida);
  const egyptProgress = toquesSilueta / infoTamano.toquesSilueta;
  const egyptPercent = Math.min(100, Math.round(egyptProgress * 100));

  const checkInsideScaleBowl = (clientX: number, clientY: number) => {
    if (!scaleBowlRef.current) return false;
    const rect = scaleBowlRef.current.getBoundingClientRect();
    const pad = 26;
    return (
      clientX >= rect.left - pad &&
      clientX <= rect.right + pad &&
      clientY >= rect.top - pad &&
      clientY <= rect.bottom + pad
    );
  };

  const agregarPorcionHarina = (amountToAdd: SpoonSize) => {
    sounds.playCheeseSprinkle();
    setPourFlash(true);
    setTimeout(() => setPourFlash(false), 380);

    const nextGrams = harinaEnGramera + amountToAdd;
    setHarinaEnGramera(nextGrams);

    if (nextGrams > infoTamano.harinaRequerida) {
      sounds.playReaction('angry');
      setHeartBreakFlash(true);
      setTimeout(() => setHeartBreakFlash(false), 600);

      const nextBroken = Math.min(3, brokenHearts + 1);
      setBrokenHearts(nextBroken);
      const nextScore = Math.round(((3 - nextBroken) / 3) * 100);
      onUpdatePizza((prev) => ({
        ...prev,
        doughScore: nextScore,
      }));
      setFeedbackGramera({
        text: `¡Te pasaste! La receta pedía ${infoTamano.harinaRequerida} g y llevas ${nextGrams} g. Se rompió un corazón de sabor (${3 - nextBroken}/3).`,
        tone: 'error',
      });
    } else if (nextGrams === infoTamano.harinaRequerida) {
      sounds.playChaChing();
      setFeedbackGramera({
        text: `¡Peso exacto (${nextGrams} g)! Ya puedes pasar a la Sala de Mezclas.`,
        tone: 'success',
      });
    } else {
      const faltan = infoTamano.harinaRequerida - nextGrams;
      setFeedbackGramera({
        text: `Echaste +${amountToAdd} g · Llevas ${nextGrams} g (faltan ${faltan} g).`,
        tone: 'neutral',
      });
    }
  };

  // Global window pointer tracking while carrying or dragging a metallic spoon
  useEffect(() => {
    if (!heldSpoon) return;

    const onWindowPointerMove = (e: PointerEvent) => {
      setPointerPos({ x: e.clientX, y: e.clientY });
      setIsHoveringBowl(checkInsideScaleBowl(e.clientX, e.clientY));
    };

    const onWindowPointerUp = (e: PointerEvent) => {
      const start = dragStartRef.current;
      const movedDist = start
        ? Math.hypot(e.clientX - start.x, e.clientY - start.y)
        : 0;
      const overBowl = checkInsideScaleBowl(e.clientX, e.clientY);

      if (overBowl) {
        agregarPorcionHarina(heldSpoon.amount);
        setHeldSpoon(null);
        setIsHoveringBowl(false);
        dragStartRef.current = null;
      } else if (movedDist >= 12) {
        // Released outside bowl after dragging -> drop back on table
        setHeldSpoon(null);
        setIsHoveringBowl(false);
        dragStartRef.current = null;
      }
      // If movedDist < 12 (quick click), keep spoon attached to pointer so clicking the bowl also pours!
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setHeldSpoon(null);
        setIsHoveringBowl(false);
        dragStartRef.current = null;
      }
    };

    window.addEventListener('pointermove', onWindowPointerMove);
    window.addEventListener('pointerup', onWindowPointerUp);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('pointermove', onWindowPointerMove);
      window.removeEventListener('pointerup', onWindowPointerUp);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [heldSpoon, harinaEnGramera, brokenHearts, infoTamano.harinaRequerida]);

  const checkInsideSilhouette = (clientX: number, clientY: number) => {
    if (!silhouetteZoneRef.current) return false;
    const rect = silhouetteZoneRef.current.getBoundingClientRect();
    const pad = 20;
    return (
      clientX >= rect.left - pad &&
      clientX <= rect.right + pad &&
      clientY >= rect.top - pad &&
      clientY <= rect.bottom + pad
    );
  };

  const anadirHarinaSilueta = () => {
    sounds.playCheeseSprinkle();
    setPourFlash(true);
    setTimeout(() => setPourFlash(false), 380);

    const nextToques = toquesSilueta + 1;
    setToquesSilueta(nextToques);

    if (nextToques > infoTamano.toquesSilueta) {
      sounds.playReaction('angry');
      setHeartBreakFlash(true);
      setTimeout(() => setHeartBreakFlash(false), 600);

      const nextBroken = Math.min(3, brokenHearts + 1);
      setBrokenHearts(nextBroken);
      const nextScore = Math.round(((3 - nextBroken) / 3) * 100);
      onUpdatePizza((prev) => ({
        ...prev,
        doughScore: nextScore,
      }));
      setFeedbackGramera({
        text: `⚠️ ¡Te pasaste de la silueta punteada (${nextToques}/${infoTamano.toquesSilueta})! Limpia la mesa e intenta de nuevo. (${3 - nextBroken}/3 ❤️)`,
        tone: 'error',
      });
    } else if (nextToques === infoTamano.toquesSilueta) {
      sounds.playChaChing();
      setFeedbackGramera({
        text: `👑 ¡Exacto! Llenaste la silueta de ${infoTamano.medidaEgipcia}. ¡Ahora ve a Mezcla!`,
        tone: 'success',
      });
    } else {
      const faltan = infoTamano.toquesSilueta - nextToques;
      setFeedbackGramera({
        text: `🌾 Puñado #${nextToques} añadido · Faltan ${faltan} para llenar ${infoTamano.medidaEgipcia}.`,
        tone: 'neutral',
      });
    }
  };

  const reiniciarSiluetaEgipcia = () => {
    sounds.playDoughSlap();
    setToquesSilueta(0);
    setFeedbackGramera({
      text: `Mesa limpia. Cubre la silueta de ${infoTamano.medidaEgipcia} con ${infoTamano.toquesSilueta} puñados de harina.`,
      tone: 'neutral',
    });
  };

  // Global window pointer tracking while dragging/carrying Egyptian wooden flour scoop
  useEffect(() => {
    if (!holdingEgyptScoop) return;

    const onMove = (e: PointerEvent) => {
      setPointerPos({ x: e.clientX, y: e.clientY });
      setHoveringSilhouette(checkInsideSilhouette(e.clientX, e.clientY));
    };

    const onUp = (e: PointerEvent) => {
      const start = dragStartRef.current;
      const movedDist = start ? Math.hypot(e.clientX - start.x, e.clientY - start.y) : 0;
      const overTarget = checkInsideSilhouette(e.clientX, e.clientY);

      if (overTarget) {
        anadirHarinaSilueta();
        setHoldingEgyptScoop(false);
        setHoveringSilhouette(false);
        dragStartRef.current = null;
      } else if (movedDist >= 12) {
        setHoldingEgyptScoop(false);
        setHoveringSilhouette(false);
        dragStartRef.current = null;
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setHoldingEgyptScoop(false);
        setHoveringSilhouette(false);
        dragStartRef.current = null;
      }
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [holdingEgyptScoop, toquesSilueta, brokenHearts, infoTamano.toquesSilueta, infoTamano.medidaEgipcia]);

  const reiniciarGramera = () => {
    sounds.playDoughSlap();
    setHarinaEnGramera(0);
    setFeedbackGramera({
      text: 'Gramera en 0 g. Agarra una cuchara metálica (+5, +10 o +50 g) para volver a pesar.',
      tone: 'neutral',
    });
  };

  const confirmarPesajeYIrAMezclar = () => {
    if (isEgyptianVisitor) {
      if (toquesSilueta < infoTamano.toquesSilueta) {
        sounds.playReaction('meh');
        setFeedbackGramera({
          text: `🤔 Todavía falta harina para llenar ${infoTamano.medidaEgipcia} (${toquesSilueta}/${infoTamano.toquesSilueta} puñados).`,
          tone: 'error',
        });
        return;
      }
      if (toquesSilueta > infoTamano.toquesSilueta) {
        sounds.playReaction('angry');
        setFeedbackGramera({
          text: `⚠️ ¡Te pasaste de la silueta punteada! Pulsa "Limpiar mesa" para medir justo ${infoTamano.toquesSilueta} puñados.`,
          tone: 'error',
        });
        return;
      }

      sounds.playChaChing();
      const score = Math.round((heartsRemaining / 3) * 100);
      onUpdatePizza((prev) => ({
        ...prev,
        flourWeighed: true,
        harinaEnGramera: infoTamano.harinaRequerida,
        doughScore: score,
      }));
      onMoveToMixing();
      return;
    }

    if (harinaEnGramera === 0) {
      sounds.playReaction('meh');
      setFeedbackGramera({
        text: `Primero agrega harina a la gramera (Meta: ${infoTamano.harinaRequerida} g).`,
        tone: 'error',
      });
      return;
    }

    if (harinaEnGramera < infoTamano.harinaRequerida) {
      sounds.playReaction('meh');
      setFeedbackGramera({
        text: `Todavía falta harina: llevas ${harinaEnGramera} g y la pizza ${targetSize} necesita ${infoTamano.harinaRequerida} g.`,
        tone: 'error',
      });
      return;
    }

    sounds.playChaChing();
    const score = Math.round((heartsRemaining / 3) * 100);
    onUpdatePizza((prev) => ({
      ...prev,
      flourWeighed: true,
      harinaEnGramera,
      doughScore: score,
    }));
    onMoveToMixing();
  };

  // Flour mound vertical growth inside the 3D steel bowl
  const flourScale = 0.35 + Math.min(1.05, fillRatio) * 0.65;

  return (
    <div className="relative flex-1 h-full overflow-y-auto overflow-x-hidden bg-[#140F0C] select-none flex flex-col justify-between">
      {/* FULL-BLEED KITCHEN PREP TABLE BACKGROUND (Unobstructed, no white box hiding it!) */}
      <img
        src="/assets/aistudio/kitcken_5d4796e4.jpg"
        alt="Mesa de preparación de masa"
        referrerPolicy="no-referrer"
        className="fixed inset-0 w-full h-full object-cover pointer-events-none opacity-95"
      />
      {/* Subtle perimeter vignette so foreground typography & tools have depth without obscuring the wood */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 52%, rgba(18,12,8,0.12) 25%, rgba(12,8,5,0.68) 100%)',
        }}
      />

      {/* TOP FLOATING HUD BAR (Translucent dark wood/slate scrim — NO white boxes) */}
      <header className="relative z-20 w-full max-w-6xl mx-auto px-4 pt-3 sm:pt-4 flex flex-wrap items-center justify-between gap-3">
        {/* 1. Octavia Character Commentary Sign (Wood Plank & Parchment) */}
        <WoodParchmentBoard
          variant="plank"
          compact
          showHerbs={true}
          className="max-w-md"
        >
          <div className="flex items-center gap-2.5" title="Comentario de Octavia">
            {/* Octavia Avatar Portrait */}
            <div className="relative shrink-0">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full border-2 border-[#6B4226] bg-[#FFF8E7] overflow-hidden shadow-md">
                <img
                  src="/assets/aistudio/image.png_eaf546b8_57de311c.jpg"
                  alt="Octavia"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-[1px] rounded bg-[#5C361B] text-amber-100 text-[9px] font-black tracking-wide border border-amber-300/40 shadow">
                Octavia
              </span>
            </div>

            {/* Octavia Speech Content */}
            <div className="bg-[#FFFBF0]/85 border border-[#D4AE74] rounded-lg px-3 py-1.5 shadow-inner leading-snug">
              <div className="text-[11px] font-black text-[#8C4D1E] flex items-center gap-1">
                <span>🐙 Octavia comenta:</span>
                {isEgyptianVisitor && (
                  <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 text-[10px] border border-amber-300">
                    Modo Egipcio
                  </span>
                )}
                {order?.recipe.dough === 'naan_verde' && (
                  <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-900 text-[10px] border border-emerald-400">
                    🌿 Naan Verde
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm font-bold text-[#3A1E0D] mt-0.5">
                {isEgyptianVisitor ? (
                  <>
                    &ldquo;¡Ojo! {order?.customerName} pide {ICONOS_FORMA[targetShape]} {targetShape} de{' '}
                    <span className="text-[#9A231B] font-black">
                      {infoTamano.iconoEgipcio} {infoTamano.medidaEgipcia}
                    </span>
                    .&rdquo;
                  </>
                ) : (
                  <>
                    &ldquo;{order?.customerName || 'El cliente'} quiere{' '}
                    {order?.recipe.dough === 'naan_verde' && (
                      <span className="text-emerald-800 font-black">Harina Naan Verde · </span>
                    )}
                    {ICONOS_FORMA[targetShape]} {targetSize} ({targetShape}). ¡Pesa{' '}
                    <span className="text-[#9A231B] font-mono font-black">
                      {infoTamano.harinaRequerida} g
                    </span>
                    !&rdquo;
                  </>
                )}
              </p>
            </div>
          </div>
        </WoodParchmentBoard>

        {/* 2. Detailed Carved Wood Plaque for Size Standards / Egyptian Measures */}
        {isEgyptianVisitor ? (
          <div
            aria-label="Medidas del Faraón en letrero de madera"
            className="relative overflow-hidden flex flex-wrap items-center gap-2 sm:gap-2.5 px-5 py-2.5 rounded-xl bg-gradient-to-b from-[#7C4A22] via-[#5E3516] to-[#41220B] border-2 border-[#2A1405] shadow-[0_12px_26px_rgba(0,0,0,0.65),inset_0_2px_2px_rgba(255,214,158,0.4),inset_0_-3px_4px_rgba(20,9,2,0.75)] text-xs sm:text-sm text-amber-100"
          >
            {/* Wood Grain SVG Overlay */}
            <svg
              viewBox="0 0 360 60"
              preserveAspectRatio="none"
              className="absolute inset-0 w-full h-full pointer-events-none opacity-25"
              aria-hidden="true"
            >
              <path d="M 0 12 Q 90 6 180 14 T 360 10" fill="none" stroke="#241003" strokeWidth="1.6" />
              <path d="M 0 28 Q 110 34 220 24 T 360 30" fill="none" stroke="#241003" strokeWidth="1.4" />
              <path d="M 0 46 Q 80 40 190 48 T 360 44" fill="none" stroke="#241003" strokeWidth="1.8" />
              <ellipse cx="295" cy="28" rx="18" ry="6" fill="none" stroke="#241003" strokeWidth="1.2" />
              <path d="M 0 20 Q 140 16 260 22 T 360 18" fill="none" stroke="#E7B982" strokeWidth="0.8" opacity="0.6" />
            </svg>
            {/* Inner Beveled Carved Groove */}
            <div
              aria-hidden="true"
              className="absolute inset-1 rounded-lg border border-amber-300/25 pointer-events-none"
            />
            {/* Brass Corner Rivets */}
            <span aria-hidden="true" className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute bottom-1.5 left-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute bottom-1.5 right-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />

            {(['Pequeña', 'Mediana', 'Familiar'] as PizzaSize[]).map((sz, idx) => {
              const entry = CATALOGO_TAMANOS[sz];
              const isTarget = sz === targetSize;
              return (
                <React.Fragment key={sz}>
                  {idx > 0 && (
                    <span className="relative z-10 text-amber-400/50 hidden sm:inline font-black" aria-hidden="true">
                      |
                    </span>
                  )}
                  <div
                    className={`relative z-10 flex items-center gap-1.5 font-bold tabular-nums px-2.5 py-1 rounded-lg transition-colors ${
                      isTarget
                        ? 'bg-[#2B1506]/80 text-amber-200 border border-amber-400/75 shadow-inner'
                        : 'text-amber-100/85'
                    }`}
                  >
                    <span>{entry.iconoEgipcio}</span>
                    <span className="drop-shadow-xs">{entry.medidaEgipcia}</span>
                    <span className="font-mono text-amber-300">({entry.toquesSilueta} puñ.)</span>
                  </div>
                </React.Fragment>
              );
            })}
          </div>
        ) : (
          <div
            aria-label="Estándares de masa por tamaño en letrero de madera"
            className="relative overflow-hidden flex flex-wrap items-center gap-2 sm:gap-3 px-5 py-2.5 rounded-xl bg-gradient-to-b from-[#7C4A22] via-[#5E3516] to-[#41220B] border-2 border-[#2A1405] shadow-[0_12px_26px_rgba(0,0,0,0.65),inset_0_2px_2px_rgba(255,214,158,0.4),inset_0_-3px_4px_rgba(20,9,2,0.75)] text-xs sm:text-sm text-amber-100"
          >
            {/* Wood Grain SVG Overlay */}
            <svg
              viewBox="0 0 360 60"
              preserveAspectRatio="none"
              className="absolute inset-0 w-full h-full pointer-events-none opacity-25"
              aria-hidden="true"
            >
              <path d="M 0 12 Q 90 6 180 14 T 360 10" fill="none" stroke="#241003" strokeWidth="1.6" />
              <path d="M 0 28 Q 110 34 220 24 T 360 30" fill="none" stroke="#241003" strokeWidth="1.4" />
              <path d="M 0 46 Q 80 40 190 48 T 360 44" fill="none" stroke="#241003" strokeWidth="1.8" />
              <ellipse cx="75" cy="30" rx="16" ry="5.5" fill="none" stroke="#241003" strokeWidth="1.2" />
              <ellipse cx="285" cy="24" rx="14" ry="5" fill="none" stroke="#241003" strokeWidth="1.2" />
              <path d="M 0 20 Q 140 16 260 22 T 360 18" fill="none" stroke="#E7B982" strokeWidth="0.8" opacity="0.6" />
            </svg>
            {/* Inner Beveled Carved Groove */}
            <div
              aria-hidden="true"
              className="absolute inset-1 rounded-lg border border-amber-300/25 pointer-events-none"
            />
            {/* Brass Corner Rivets */}
            <span aria-hidden="true" className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute bottom-1.5 left-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />
            <span aria-hidden="true" className="absolute bottom-1.5 right-1.5 w-2 h-2 rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-900 border border-amber-950 shadow-sm" />

            {SIZE_STANDARDS.map((item, idx) => {
              const isTarget = item.size === targetSize;
              return (
                <React.Fragment key={item.size}>
                  {idx > 0 && (
                    <span className="relative z-10 text-amber-400/50 hidden sm:inline font-black" aria-hidden="true">
                      |
                    </span>
                  )}
                  <div
                    className={`relative z-10 flex items-center gap-1.5 font-bold tabular-nums transition-colors px-2.5 py-1 rounded-lg ${
                      isTarget
                        ? 'bg-[#2B1506]/80 text-amber-200 border border-amber-400/75 shadow-inner'
                        : 'text-amber-100/85'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${item.dotColor} shadow-xs`} aria-hidden="true" />
                    <span className="drop-shadow-xs">{item.size}</span>
                    <span className="font-mono text-amber-300">{item.grams} g</span>
                  </div>
                </React.Fragment>
              );
            })}
          </div>
        )}

        {/* 3 Flavor Hearts Indicator */}
        <div
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl backdrop-blur-md border shadow-xl transition-transform duration-200 ${
            heartBreakFlash
              ? 'bg-rose-950/85 border-rose-400 scale-110'
              : 'bg-stone-950/65 border-rose-300/25'
          }`}
          title="Calificación del Sabor: si agregas más harina de la indicada, se rompe un corazón"
        >
          <span className="text-xs font-bold text-rose-200">Sabor</span>
          <span className="text-lg sm:text-xl flex items-center gap-0.5 leading-none">
            {[0, 1, 2].map((i) => (
              <span key={i}>{i < heartsRemaining ? '❤️' : '💔'}</span>
            ))}
          </span>
          <span className="font-mono text-xs font-black text-rose-200 tabular-nums">
            {heartsRemaining}/3
          </span>
        </div>
      </header>

      {/* RESTORATION BANNER (Shown when kitchen automatically returns to normal gramera after serving Faraón/Momia) */}
      {!isEgyptianVisitor && restoredFromEgyptian && (
        <div className="relative z-20 max-w-2xl mx-auto mt-2 px-4 py-1.5 rounded-2xl bg-sky-950/85 border border-sky-400/60 text-sky-100 text-xs sm:text-sm font-bold text-center shadow-lg backdrop-blur-md animate-in fade-in">
          🧑‍🍳 ¡Pedido egipcio entregado! La cocina volvió automáticamente a su gramera normal para el siguiente cliente.
        </div>
      )}

      {/* COUNTER FLOUR TYPE SELECTOR BAR (Harina Tradicional vs Harina Naan Verde) */}
      <div className="relative z-20 w-full max-w-3xl mx-auto px-4 mt-2">
        <div className="bg-stone-950/75 backdrop-blur-md border border-amber-300/30 rounded-2xl p-2 flex flex-wrap items-center justify-between gap-2 shadow-xl">
          <div className="flex items-center gap-2 px-2">
            <span className="text-xs font-black uppercase tracking-wider text-amber-200">
              🌾 Harina en Mostrador:
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleSelectDoughType('normal')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                !isGreenNaan
                  ? 'bg-amber-100 text-amber-950 border-amber-400 ring-2 ring-amber-300/60 shadow'
                  : 'bg-stone-900/80 text-stone-200 border-stone-600 hover:bg-stone-800'
              }`}
            >
              <span className="w-3.5 h-3.5 rounded-full bg-[#FFFDF5] border border-amber-700 shrink-0" />
              <span>Harina Tradicional</span>
            </button>

            <button
              type="button"
              onClick={() => handleSelectDoughType('naan_verde')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                isGreenNaan
                  ? 'bg-emerald-400 text-emerald-950 border-emerald-200 ring-2 ring-emerald-300/80 shadow-lg'
                  : naanVerdeUnlocked
                  ? 'bg-emerald-950/80 text-emerald-100 border-emerald-500/60 hover:bg-emerald-900'
                  : 'bg-stone-900/65 text-stone-400 border-stone-700 opacity-80'
              }`}
              title="Pan plano Naan con ghee y ajo picado (Color Verde)"
            >
              <span className="w-3.5 h-3.5 rounded-full bg-emerald-400 border border-emerald-900 shrink-0" />
              <span>Harina Naan Verde (Ghee y Ajo)</span>
              {!naanVerdeUnlocked && (
                <span className="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded bg-stone-800 text-amber-300 border border-stone-600">
                  <Lock className="w-2.5 h-2.5" /> Tienda · Día 4+
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* CENTER WORKBENCH STAGE: EGYPTIAN SILHOUETTE MODE vs. NORMAL 3D GRAMERA MODE */}
      {isEgyptianVisitor ? (
        <main className="relative z-10 flex-1 w-full max-w-6xl mx-auto px-4 py-3 flex flex-col lg:flex-row items-center justify-center gap-6 lg:gap-10">
          {/* LEFT / CENTER HERO: DOTTED BODY SILHOUETTE MEASURING MAT */}
          <section className="flex flex-col items-center w-full max-w-xl">
            <div
              ref={silhouetteZoneRef}
              onClick={() => {
                if (holdingEgyptScoop) {
                  anadirHarinaSilueta();
                  setHoldingEgyptScoop(false);
                  setHoveringSilhouette(false);
                  dragStartRef.current = null;
                }
              }}
              className={`relative w-full rounded-3xl p-5 sm:p-6 border-4 shadow-[0_22px_50px_rgba(0,0,0,0.7)] transition-all duration-200 backdrop-blur-sm ${
                hoveringSilhouette
                  ? 'border-amber-300 scale-[1.02] bg-[#8FB8CF]/90'
                  : 'border-[#C69C6D] bg-gradient-to-b from-[#BFE3F7]/90 via-[#D6EEFA]/90 to-[#B0DAEF]/90'
              } ${holdingEgyptScoop ? 'cursor-pointer' : ''}`}
            >
              {/* Top Tag inside measuring slate */}
              <div className="flex items-center justify-between mb-2">
                <span className="px-3 py-1 rounded-full bg-slate-900/80 text-amber-200 text-xs font-black tracking-wide">
                  1️⃣ Mide con el Cuerpo · {infoTamano.iconoEgipcio} {infoTamano.medidaEgipcia}
                </span>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-mono font-black tabular-nums ${
                    isOverweight
                      ? 'bg-rose-700 text-white'
                      : isExactWeight
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-900/75 text-sky-100'
                  }`}
                >
                  {toquesSilueta} / {infoTamano.toquesSilueta} puñados ({egyptPercent}%)
                </span>
              </div>

              {/* Dotted Silhouette Canvas matching image_4a13d1bc.png */}
              <div className="relative w-full h-56 sm:h-64 flex items-center justify-center">
                <EgyptianSilhouetteSVG
                  size={targetSize}
                  progress={egyptProgress}
                  isOverfilled={isOverweight}
                  isExact={isExactWeight}
                  isHoveringTarget={hoveringSilhouette || holdingEgyptScoop}
                />

                {pourFlash && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-24 h-24 rounded-full bg-amber-100/70 animate-ping" />
                  </div>
                )}
              </div>

              {/* Progress Bar */}
              <div className="mt-2">
                <div className="flex justify-between text-xs font-black text-slate-800 mb-1">
                  <span>Silueta punteada: {infoTamano.medidaEgipcia}</span>
                  <span className="font-mono">{egyptPercent}% lleno</span>
                </div>
                <div className="w-full h-3.5 bg-slate-900/20 rounded-full overflow-hidden border border-slate-700/30">
                  <div
                    className={`h-full transition-all duration-300 ${
                      isOverweight
                        ? 'bg-rose-500'
                        : isExactWeight
                        ? 'bg-emerald-500'
                        : 'bg-amber-500'
                    }`}
                    style={{ width: `${egyptPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Feedback Banner */}
            <p
              className={`mt-3 max-w-lg text-center text-xs sm:text-sm font-bold px-4 py-1.5 rounded-xl backdrop-blur-md shadow-md ${
                feedbackGramera.tone === 'error'
                  ? 'bg-rose-950/85 text-rose-200 border border-rose-400/40'
                  : feedbackGramera.tone === 'success'
                  ? 'bg-emerald-950/85 text-emerald-200 border border-emerald-400/40'
                  : 'bg-stone-950/70 text-amber-100 border border-white/10'
              }`}
            >
              {holdingEgyptScoop
                ? 'Llevando puñado de harina — suéltalo o haz clic sobre la silueta punteada'
                : feedbackGramera.text}
            </p>

            {/* Egyptian Action Buttons */}
            <div className="mt-3 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={anadirHarinaSilueta}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-sm shadow-xl transition flex items-center gap-2 cursor-pointer"
              >
                <span>🌾</span>
                <span>+ Añadir Harina (1 puñado)</span>
              </button>

              <button
                type="button"
                onClick={reiniciarSiluetaEgipcia}
                className="px-4 py-2.5 rounded-xl bg-stone-900/80 hover:bg-stone-800 active:scale-95 text-stone-200 font-bold text-xs sm:text-sm border border-stone-500/40 shadow-lg backdrop-blur-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                Limpiar mesa
              </button>

              <button
                type="button"
                onClick={confirmarPesajeYIrAMezclar}
                className={`px-6 py-2.5 rounded-xl font-black text-sm sm:text-base shadow-xl transition active:scale-95 flex items-center gap-2 cursor-pointer ${
                  isExactWeight
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 ring-4 ring-emerald-300/50'
                    : 'bg-amber-300/90 hover:bg-amber-200 text-slate-950'
                }`}
              >
                <span>¡Silueta Llena! Ir a Mezcla</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </section>

          {/* RIGHT: REFERENCE GUIDE CARD + DRAGGABLE WOODEN FLOUR SCOOP */}
          <section className="flex flex-col items-center gap-4 max-w-xs w-full">
            {/* Reference Illustration Card using user's uploaded chart */}
            <WoodParchmentBoard variant="plank" compact className="w-full">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-black uppercase tracking-wider text-[#5D290D]">
                  🏛️ Guía de Medidas Egipcias
                </h3>
                <span className="text-[10px] font-bold text-[#6E4427]">Sin Gramera</span>
              </div>
              <div className="rounded-xl overflow-hidden border border-[#B38651] bg-[#BCE3F7]">
                <img
                  src="/assets/aistudio/image_4a13d1bc.png"
                  alt="Siluetas de medición egipcias: Mano extendida, 1 Codo y 2 Codos"
                  className="w-full h-36 object-cover"
                />
              </div>
              <div className="grid grid-cols-3 gap-1.5 mt-2 text-center text-[11px] font-bold text-[#3A1E0D]">
                <div
                  className={`p-1.5 rounded-lg border ${
                    targetSize === 'Pequeña'
                      ? 'bg-amber-200/80 border-[#8C4D1E] text-[#3A1E0D]'
                      : 'bg-[#FFFBF0]/60 border-[#D4AE74]'
                  }`}
                >
                  <div>🖐️ Mano</div>
                  <div className="text-[10px] text-[#8C4D1E]">2 puñados</div>
                </div>
                <div
                  className={`p-1.5 rounded-lg border ${
                    targetSize === 'Mediana'
                      ? 'bg-amber-200/80 border-[#8C4D1E] text-[#3A1E0D]'
                      : 'bg-[#FFFBF0]/60 border-[#D4AE74]'
                  }`}
                >
                  <div>💪 1 Codo</div>
                  <div className="text-[10px] text-[#8C4D1E]">4 puñados</div>
                </div>
                <div
                  className={`p-1.5 rounded-lg border ${
                    targetSize === 'Familiar'
                      ? 'bg-amber-200/80 border-[#8C4D1E] text-[#3A1E0D]'
                      : 'bg-[#FFFBF0]/60 border-[#D4AE74]'
                  }`}
                >
                  <div>💪💪 2 Codos</div>
                  <div className="text-[10px] text-[#8C4D1E]">6 puñados</div>
                </div>
              </div>
            </WoodParchmentBoard>

            {/* Draggable Wooden/Clay Scoop with Flour */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                dragStartRef.current = { x: e.clientX, y: e.clientY };
                setPointerPos({ x: e.clientX, y: e.clientY });
                setHoldingEgyptScoop(true);
                sounds.playToppingPop(0.75);
              }}
              className={`group flex flex-col items-center p-3 rounded-2xl bg-stone-950/65 backdrop-blur-md border border-amber-300/30 shadow-xl transition-all touch-none ${
                holdingEgyptScoop
                  ? 'opacity-40 scale-90 cursor-grabbing'
                  : 'cursor-grab hover:-translate-y-1 hover:border-amber-300'
              }`}
              title="Arrastra un puñado de harina hacia la silueta punteada"
            >
              <svg viewBox="0 0 110 85" className="w-24 h-18 overflow-visible" aria-hidden="true">
                <defs>
                  <linearGradient id="egypt-clay-bowl" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#D99B66" />
                    <stop offset="55%" stopColor="#A86533" />
                    <stop offset="100%" stopColor="#693818" />
                  </linearGradient>
                  <radialGradient id="egypt-scoop-flour" cx="42%" cy="35%" r="62%">
                    <stop offset="0%" stopColor="#FFFFFF" />
                    <stop offset="65%" stopColor="#FEF3C7" />
                    <stop offset="100%" stopColor="#D6B57A" />
                  </radialGradient>
                </defs>
                <ellipse cx="55" cy="72" rx="34" ry="8" fill="#000000" opacity="0.4" />
                <path
                  d="M 20 38 Q 22 72 55 72 Q 88 72 90 38 Z"
                  fill="url(#egypt-clay-bowl)"
                  stroke="#451A03"
                  strokeWidth="2"
                />
                <ellipse cx="55" cy="38" rx="35" ry="12" fill="#8C4F24" stroke="#451A03" strokeWidth="2" />
                <path
                  d="M 26 38 Q 40 12 55 10 Q 70 12 84 38 Q 55 46 26 38 Z"
                  fill="url(#egypt-scoop-flour)"
                />
                <ellipse cx="48" cy="24" rx="10" ry="5" fill="#FFFFFF" opacity="0.8" />
              </svg>
              <span className="text-xs font-black text-amber-100 mt-1">
                🥣 Puñado de Harina
              </span>
              <span className="text-[10px] text-amber-300/90 font-semibold">
                Arrastra o haz clic en la silueta
              </span>
            </button>
          </section>
        </main>
      ) : (
        <main className="relative z-10 flex-1 w-full max-w-6xl mx-auto px-4 py-4 flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-14">
        {/* LEFT / CENTER HERO: 3D TEXTURED STAINLESS & GRAPHITE GRAMERA */}
        <section className="flex flex-col items-center">
          {/* Interactive Weighing Drop Zone wrapping the 3D SVG Scale */}
          <div
            ref={scaleBowlRef}
            onClick={() => {
              if (heldSpoon) {
                agregarPorcionHarina(heldSpoon.amount);
                setHeldSpoon(null);
                setIsHoveringBowl(false);
                dragStartRef.current = null;
              }
            }}
            className={`relative w-[320px] sm:w-[370px] transition-transform duration-200 ${
              isHoveringBowl ? 'scale-[1.03]' : ''
            } ${heldSpoon ? 'cursor-pointer' : ''}`}
          >
            {/* 3D Textured Kitchen Scale SVG */}
            <svg
              viewBox="0 0 380 340"
              className="w-full h-auto overflow-visible"
              role="img"
              aria-label={`Gramera digital marcando ${harinaEnGramera} gramos de ${infoTamano.harinaRequerida} gramos`}
            >
              <defs>
                {/* Brushed dark gunmetal / titanium chassis gradients */}
                <linearGradient id="scale-deck-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#64748B" />
                  <stop offset="30%" stopColor="#334155" />
                  <stop offset="70%" stopColor="#1E293B" />
                  <stop offset="100%" stopColor="#0F172A" />
                </linearGradient>

                <linearGradient id="scale-front-bevel" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#475569" />
                  <stop offset="20%" stopColor="#1E293B" />
                  <stop offset="85%" stopColor="#0F172A" />
                  <stop offset="100%" stopColor="#020617" />
                </linearGradient>

                <linearGradient id="scale-chrome-ring" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#F8FAFC" />
                  <stop offset="25%" stopColor="#94A3B8" />
                  <stop offset="50%" stopColor="#E2E8F0" />
                  <stop offset="75%" stopColor="#475569" />
                  <stop offset="100%" stopColor="#CBD5E1" />
                </linearGradient>

                {/* Deep Brushed Stainless-Steel Mixing Bowl Interior */}
                <radialGradient id="bowl-steel-cavity" cx="42%" cy="38%" r="62%">
                  <stop offset="0%" stopColor="#475569" />
                  <stop offset="35%" stopColor="#94A3B8" />
                  <stop offset="68%" stopColor="#CBD5E1" />
                  <stop offset="90%" stopColor="#64748B" />
                  <stop offset="100%" stopColor="#1E293B" />
                </radialGradient>

                {/* Outer brushed stainless steel rim wall */}
                <linearGradient id="bowl-outer-wall" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#334155" />
                  <stop offset="20%" stopColor="#CBD5E1" />
                  <stop offset="42%" stopColor="#FFFFFF" />
                  <stop offset="68%" stopColor="#94A3B8" />
                  <stop offset="88%" stopColor="#E2E8F0" />
                  <stop offset="100%" stopColor="#1E293B" />
                </linearGradient>

                {/* Sifted Flour Heap Radial Texture (Cream or Vibrant Green Naan) */}
                <radialGradient id="bowl-flour-mound" cx="42%" cy="35%" r="65%">
                  <stop offset="0%" stopColor={isGreenNaan ? '#DCFCE7' : '#FFFFFF'} />
                  <stop offset="48%" stopColor={isGreenNaan ? '#86EFAC' : '#FFFDF7'} />
                  <stop offset="80%" stopColor={isGreenNaan ? '#4ADE80' : '#EFE3CB'} />
                  <stop offset="100%" stopColor={isGreenNaan ? '#16A34A' : '#CBB692'} />
                </radialGradient>

                {/* Recessed LCD screen background */}
                <linearGradient id="lcd-glass-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#050A0E" />
                  <stop offset="100%" stopColor="#0C171E" />
                </linearGradient>

                {/* Ambient wood-table shadow */}
                <radialGradient id="table-ambient-shadow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#000000" stopOpacity="0.72" />
                  <stop offset="65%" stopColor="#000000" stopOpacity="0.38" />
                  <stop offset="100%" stopColor="#000000" stopOpacity="0" />
                </radialGradient>

                {/* Soft shadow filters */}
                <filter id="scale-heavy-shadow" x="-20%" y="-20%" width="140%" height="150%">
                  <feDropShadow dx="0" dy="14" stdDeviation="10" floodColor="#050302" floodOpacity="0.72" />
                </filter>
                <filter id="bowl-cast-shadow" x="-20%" y="-20%" width="140%" height="150%">
                  <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#020617" floodOpacity="0.65" />
                </filter>
              </defs>

              {/* Soft ambient shadow on kitchen table */}
              <ellipse cx="190" cy="298" rx="166" ry="38" fill="url(#table-ambient-shadow)" />

              {/* === 1. 3D SCALE HOUSING & FRONT CONSOLE === */}
              <g filter="url(#scale-heavy-shadow)">
                {/* Rubber feet */}
                <rect x="64" y="294" width="32" height="10" rx="4" fill="#090D16" />
                <rect x="284" y="294" width="32" height="10" rx="4" fill="#090D16" />

                {/* Lower 3D Front Beveled Console Face */}
                <path
                  d="M 42 214 L 338 214 L 352 276 Q 354 298 326 298 L 54 298 Q 26 298 28 276 Z"
                  fill="url(#scale-front-bevel)"
                  stroke="#020617"
                  strokeWidth="2"
                />

                {/* Top Brushed Metal Weighing Deck (Perspective Rounded Trapezoid) */}
                <path
                  d="M 70 112 Q 74 96 96 96 L 284 96 Q 306 96 310 112 L 340 212 Q 342 226 322 226 L 58 226 Q 38 226 40 212 Z"
                  fill="url(#scale-deck-grad)"
                  stroke="#94A3B8"
                  strokeWidth="1.4"
                />

                {/* Machined chamfer highlight line across front edge */}
                <line
                  x1="48"
                  y1="224"
                  x2="332"
                  y2="224"
                  stroke="#CBD5E1"
                  strokeWidth="1.5"
                  opacity="0.45"
                />

                {/* Brushed Texture Micro-lines across Metal Deck */}
                <g opacity="0.12" stroke="#E2E8F0" strokeWidth="0.8">
                  <line x1="78" y1="126" x2="302" y2="126" />
                  <line x1="68" y1="150" x2="312" y2="150" />
                  <line x1="58" y1="176" x2="322" y2="176" />
                  <line x1="50" y1="202" x2="330" y2="202" />
                </g>

                {/* Recessed Load-Cell Platter Ring */}
                <ellipse
                  cx="190"
                  cy="158"
                  rx="102"
                  ry="40"
                  fill="#0F172A"
                  stroke="url(#scale-chrome-ring)"
                  strokeWidth="3.5"
                />
                <ellipse
                  cx="190"
                  cy="158"
                  rx="92"
                  ry="34"
                  fill="#1E293B"
                  stroke="#475569"
                  strokeWidth="1"
                />

                {/* === RECESSED DIGITAL LCD READOUT ON FRONT FACE === */}
                <g>
                  {/* Outer metal bezel */}
                  <rect
                    x="82"
                    y="236"
                    width="216"
                    height="50"
                    rx="10"
                    fill="#090D16"
                    stroke="#64748B"
                    strokeWidth="1.6"
                  />
                  {/* Inner recessed dark glass screen */}
                  <rect
                    x="88"
                    y="241"
                    width="204"
                    height="40"
                    rx="7"
                    fill="url(#lcd-glass-grad)"
                    stroke={
                      isOverweight
                        ? '#F43F5E'
                        : isExactWeight
                        ? '#34D399'
                        : '#1E293B'
                    }
                    strokeWidth="1.4"
                  />
                  {/* Micro label inside LCD */}
                  <text
                    x="100"
                    y="255"
                    fill="#94A3B8"
                    fontSize="8.5"
                    fontWeight="700"
                    letterSpacing="1.2"
                  >
                    GRAMERA · META {infoTamano.harinaRequerida}G
                  </text>
                  {/* Digital Gram Readout */}
                  <text
                    x="190"
                    y="274"
                    textAnchor="middle"
                    fontFamily="ui-monospace, SFMono-Regular, Menlo, monospace"
                    fontWeight="900"
                    fontSize="22"
                    fill={
                      isOverweight
                        ? '#FB7185'
                        : isExactWeight
                        ? '#6EE7B7'
                        : '#34D399'
                    }
                  >
                    {harinaEnGramera} g
                  </text>
                  {/* Diagonal glass glare highlight */}
                  <polygon
                    points="92,242 150,242 122,280 92,280"
                    fill="#FFFFFF"
                    opacity="0.06"
                  />
                </g>

                {/* Engraved side micro-buttons (visual hardware depth) */}
                <circle cx="58" cy="261" r="7" fill="#334155" stroke="#64748B" strokeWidth="1" />
                <text x="58" y="264" textAnchor="middle" fill="#CBD5E1" fontSize="6" fontWeight="800">
                  T
                </text>
                <circle cx="322" cy="261" r="7" fill="#334155" stroke="#64748B" strokeWidth="1" />
                <text x="322" y="264" textAnchor="middle" fill="#CBD5E1" fontSize="6" fontWeight="800">
                  g
                </text>
              </g>

              {/* === 2. 3D STAINLESS STEEL BOWL SITTING ON SCALE PLATTER === */}
              <g filter="url(#bowl-cast-shadow)">
                {/* Bowl Pedestal Base Shadow */}
                <ellipse cx="190" cy="160" rx="82" ry="26" fill="#020617" opacity="0.65" />

                {/* Curved Outer Stainless Steel Bowl Skirt */}
                <path
                  d="M 52 94
                     C 56 154, 108 176, 190 176
                     C 272 176, 324 154, 328 94
                     Z"
                  fill="url(#bowl-outer-wall)"
                  stroke="#334155"
                  strokeWidth="1.5"
                />

                {/* Rolled Lip Rim Highlight (3D Bevel) */}
                <ellipse
                  cx="190"
                  cy="94"
                  rx="138"
                  ry="54"
                  fill="url(#scale-chrome-ring)"
                  stroke={
                    isHoveringBowl
                      ? '#34D399'
                      : heldSpoon
                      ? '#FBBF24'
                      : '#475569'
                  }
                  strokeWidth={isHoveringBowl ? 4 : heldSpoon ? 2.8 : 1.5}
                />

                {/* Deep Concave Brushed Steel Interior */}
                <ellipse
                  cx="190"
                  cy="96"
                  rx="128"
                  ry="47"
                  fill="url(#bowl-steel-cavity)"
                />

                {/* Lathe-turned concentric brushed steel reflections inside bowl */}
                <ellipse
                  cx="190"
                  cy="99"
                  rx="108"
                  ry="37"
                  fill="none"
                  stroke="#FFFFFF"
                  strokeWidth="1"
                  opacity="0.22"
                />
                <ellipse
                  cx="190"
                  cy="102"
                  rx="82"
                  ry="27"
                  fill="none"
                  stroke="#0F172A"
                  strokeWidth="1.5"
                  opacity="0.16"
                />

                {/* Magnetic Drop Target Ring when dragging/holding a metallic spoon */}
                {heldSpoon && (
                  <ellipse
                    cx="190"
                    cy="96"
                    rx="124"
                    ry="45"
                    fill="none"
                    stroke={isHoveringBowl ? '#34D399' : '#FBBF24'}
                    strokeWidth="2.5"
                    strokeDasharray="8 6"
                    opacity={isHoveringBowl ? 0.95 : 0.65}
                  />
                )}

                {/* === 3. TEXTURED SIFTED FLOUR MOUND INSIDE BOWL === */}
                {harinaEnGramera > 0 && (
                  <g
                    style={{
                      transformOrigin: '190px 104px',
                      transform: `scale(${flourScale})`,
                      transition: 'transform 220ms cubic-bezier(0.16, 1, 0.3, 1)',
                    }}
                  >
                    {/* Soft shadow cast onto steel floor */}
                    <ellipse
                      cx="194"
                      cy="112"
                      rx="94"
                      ry="30"
                      fill="#1E293B"
                      opacity="0.34"
                    />
                    {/* Base organic flour dome */}
                    <path
                      d="M 98 108
                         Q 125 60 190 54
                         Q 255 60 282 108
                         Q 240 132 190 132
                         Q 140 132 98 108 Z"
                      fill="url(#bowl-flour-mound)"
                    />
                    {/* Sculpted ridge / soft peak highlight */}
                    <path
                      d="M 134 94 Q 186 58 232 88 Q 190 102 134 94 Z"
                      fill={isGreenNaan ? '#DCFCE7' : '#FFFFFF'}
                      opacity="0.65"
                    />
                    {/* Fine flour particles / garlic & herb specks */}
                    <g fill={isGreenNaan ? '#15803D' : '#E7D7B9'} opacity="0.85">
                      <circle cx="152" cy="96" r="1.8" />
                      <circle cx="222" cy="90" r="1.5" />
                      <circle cx="204" cy="112" r="2" />
                      <circle cx="168" cy="114" r="1.4" />
                      <circle cx="188" cy="76" r="1.6" />
                    </g>
                    <g fill={isGreenNaan ? '#FEF08A' : '#FFFFFF'} opacity="0.9">
                      <circle cx="176" cy="84" r="1.8" />
                      <circle cx="208" cy="82" r="1.4" />
                      <circle cx="144" cy="105" r="1.5" />
                      <circle cx="236" cy="103" r="1.6" />
                    </g>
                  </g>
                )}

                {/* Pouring Flour Dust Puff Effect */}
                {pourFlash && (
                  <g className="animate-ping" style={{ transformOrigin: '190px 88px' }}>
                    <circle cx="170" cy="82" r="5" fill="#FFFFFF" opacity="0.7" />
                    <circle cx="206" cy="78" r="6" fill="#FEF3C7" opacity="0.7" />
                    <circle cx="190" cy="68" r="4" fill="#FFFFFF" opacity="0.8" />
                  </g>
                )}
              </g>
            </svg>

            {/* Subtle Weight Percentage Badge Floating Over Bowl Rim */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 pointer-events-none">
              <span
                className={`px-3 py-1 rounded-full text-xs font-black tabular-nums shadow-lg backdrop-blur-md border ${
                  isOverweight
                    ? 'bg-rose-950/85 text-rose-200 border-rose-400/60'
                    : isExactWeight
                    ? 'bg-emerald-950/85 text-emerald-200 border-emerald-400/70'
                    : 'bg-stone-950/70 text-amber-100 border-white/15'
                }`}
              >
                {harinaEnGramera === 0
                  ? 'Tazón vacío · Meta ' + infoTamano.harinaRequerida + ' g'
                  : isOverweight
                  ? `Exceso: ${harinaEnGramera} / ${infoTamano.harinaRequerida} g`
                  : `${Math.round((harinaEnGramera / infoTamano.harinaRequerida) * 100)}% (${harinaEnGramera}/${infoTamano.harinaRequerida} g)`}
              </span>
            </div>
          </div>

          {/* Floating Feedback Text directly on background (NO white box) */}
          <p
            className={`mt-1 max-w-md text-center text-xs sm:text-sm font-bold px-4 py-1.5 rounded-xl backdrop-blur-md shadow-md ${
              feedbackGramera.tone === 'error'
                ? 'bg-rose-950/80 text-rose-200 border border-rose-400/40'
                : feedbackGramera.tone === 'success'
                ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-400/40'
                : 'bg-stone-950/60 text-amber-100 border border-white/10'
            }`}
          >
            {heldSpoon
              ? `Llevando cuchara ${heldSpoon.shortLabel} — suéltala o haz clic sobre el tazón metálico`
              : feedbackGramera.text}
          </p>

          {/* Action Buttons Floating Cleanly Below Gramera */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={reiniciarGramera}
              className="px-4 py-2.5 rounded-xl bg-stone-900/80 hover:bg-stone-800 active:scale-95 text-stone-200 font-bold text-xs sm:text-sm border border-stone-500/40 shadow-lg backdrop-blur-md transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              Vaciar tazón
            </button>

            <button
              type="button"
              onClick={confirmarPesajeYIrAMezclar}
              className={`px-6 py-3 rounded-xl font-black text-sm sm:text-base shadow-xl transition active:scale-95 flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                isExactWeight
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 ring-4 ring-emerald-300/50'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
              }`}
            >
              <span>¡Listo! Ir a Sala de Mezclas</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* RIGHT: 3 METALLIC MEASURING SPOONS RESTING DIRECTLY ON THE WOOD TABLE (NO WHITE BOX!) */}
        <section
          aria-label="Cucharas medidoras metálicas"
          className="flex flex-col items-center gap-3"
        >
          <div className="text-center px-3 py-1 rounded-xl bg-stone-950/55 backdrop-blur-sm border border-amber-200/15">
            <h3 className="text-sm sm:text-base font-black text-amber-100 tracking-tight">
              Cucharas Medidoras Metálicas
            </h3>
            <p className="text-xs text-amber-200/80 font-medium">
              Arrastra con el mouse hasta la gramera
            </p>
          </div>

          <div className="flex items-end justify-center gap-3 sm:gap-5 py-2">
            {MEASURING_SPOONS.map((spoon) => {
              const isBeingDragged = heldSpoon?.amount === spoon.amount;
              return (
                <button
                  key={spoon.amount}
                  type="button"
                  onPointerDown={(e) => {
                    e.preventDefault();
                    dragStartRef.current = { x: e.clientX, y: e.clientY };
                    setPointerPos({ x: e.clientX, y: e.clientY });
                    setHeldSpoon(spoon);
                    sounds.playToppingPop(0.75);
                  }}
                  className={`group relative flex flex-col items-center justify-end p-2 rounded-2xl transition-all duration-200 select-none touch-none focus-visible:outline-2 focus-visible:outline-amber-400 ${
                    isBeingDragged
                      ? 'opacity-35 scale-90 cursor-grabbing'
                      : 'cursor-grab hover:-translate-y-2 hover:scale-105 active:scale-95'
                  }`}
                  title={`Agarrar ${spoon.name} (${spoon.shortLabel}) y echar harina a la gramera`}
                >
                  {/* Realistic 3D Metallic Spoon SVG */}
                  <div
                    style={{ width: spoon.widthPx, height: spoon.heightPx }}
                    className="flex items-center justify-center transition-transform duration-200 group-hover:rotate-[-4deg]"
                  >
                    <MetallicSpoonSVG
                      amount={spoon.amount}
                      idPrefix={`table-spoon-${spoon.amount}`}
                      isGreenNaan={isGreenNaan}
                      className="w-full h-full overflow-visible"
                    />
                  </div>

                  {/* Clean floating dark-steel label underneath spoon */}
                  <div className="mt-1 flex flex-col items-center px-2.5 py-1 rounded-lg bg-stone-950/75 backdrop-blur-sm border border-slate-400/25 shadow-md">
                    <span className="text-xs font-extrabold text-slate-100 whitespace-nowrap">
                      {spoon.name}
                    </span>
                    <span className="font-mono text-xs font-black text-amber-300 tabular-nums">
                      {spoon.shortLabel}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </main>
      )}

      {/* FLOATING 3D METALLIC SPOON FOLLOWING POINTER WHILE GRABBED */}
      {heldSpoon && !isEgyptianVisitor && (
        <div
          style={{
            left: pointerPos.x,
            top: pointerPos.y,
            transform: `translate(-48%, -34%) rotate(${isHoveringBowl ? -38 : -14}deg) scale(1.12)`,
          }}
          className="fixed z-50 pointer-events-none flex flex-col items-center transition-transform duration-100"
        >
          <div style={{ width: heldSpoon.widthPx, height: heldSpoon.heightPx }}>
            <MetallicSpoonSVG
              amount={heldSpoon.amount}
              idPrefix="floating-held-spoon"
              isPouring={isHoveringBowl}
              isGreenNaan={isGreenNaan}
              className="w-full h-full overflow-visible"
            />
          </div>
          <span className=" -mt-3 px-2.5 py-0.5 rounded-md bg-stone-950/90 text-amber-200 font-mono text-xs font-black border border-amber-300/40 shadow-xl">
            {heldSpoon.shortLabel}
          </span>
        </div>
      )}

      {/* FLOATING EGYPTIAN FLOUR SCOOP FOLLOWING POINTER WHILE GRABBED */}
      {holdingEgyptScoop && isEgyptianVisitor && (
        <div
          style={{
            left: pointerPos.x,
            top: pointerPos.y,
            transform: `translate(-50%, -45%) rotate(${hoveringSilhouette ? -28 : -8}deg) scale(1.12)`,
          }}
          className="fixed z-50 pointer-events-none flex flex-col items-center transition-transform duration-100"
        >
          <div className="w-24 h-20 rounded-full bg-amber-100/20 backdrop-blur-[1px] flex items-center justify-center drop-shadow-2xl">
            <span className="text-5xl">🌾</span>
          </div>
          <span className="px-2.5 py-0.5 rounded-md bg-amber-950/90 text-amber-200 font-mono text-xs font-black border border-amber-300/50 shadow-xl">
            +1 puñado
          </span>
        </div>
      )}
    </div>
  );
};
