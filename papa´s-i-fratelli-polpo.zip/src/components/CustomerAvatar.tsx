import React from 'react';
import { CustomerAvatarConfig } from '../types/pizza';

interface CustomerAvatarProps {
  config: CustomerAvatarConfig;
  emotion?: 'happy' | 'neutral' | 'impatient' | 'angry' | 'ecstatic' | 'meh';
  size?: number;
}

export const CustomerAvatar: React.FC<CustomerAvatarProps> = ({
  config,
  emotion = 'neutral',
  size = 180,
}) => {
  const { skinColor, hairStyle, hairColor, shirtColor, accessory } = config;

  // Determine eye and mouth coordinates based on emotion
  const isHappy = emotion === 'happy' || emotion === 'ecstatic';
  const isAngry = emotion === 'angry';
  const isImpatient = emotion === 'impatient';

  return (
    <div
      style={{ width: size, height: size }}
      className={`relative inline-flex items-center justify-center transition-transform duration-300 ${
        isHappy ? 'hover:scale-105 animate-float' : ''
      }`}
    >
      <svg
        viewBox="0 0 200 200"
        width="100%"
        height="100%"
        className="drop-shadow-md overflow-visible select-none"
      >
        <defs>
          <radialGradient id={`blush-${config.skinColor}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#F43F5E" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#F43F5E" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Neck */}
        <path
          d="M 85 130 L 85 160 Q 100 165 115 160 L 115 130 Z"
          fill={skinColor}
          stroke="#451A03"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />

        {/* Shoulders / Shirt */}
        <path
          d="M 40 195 C 40 155 70 148 100 148 C 130 148 160 155 160 195 Z"
          fill={shirtColor}
          stroke="#451A03"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />

        {/* Shirt Collar Detail, Caveman Leopard Pelt, Pharaoh Wesekh Collar, or Mummy Bandages */}
        {hairStyle === 'caveman' ? (
          <g>
            {/* Prehistoric asymmetric pelt strap & leopard spots */}
            <path
              d="M 48 164 L 152 178 L 158 195 L 42 195 Z"
              fill="#D97706"
              opacity="0.35"
            />
            <circle cx="72" cy="176" r="5" fill="#451A03" opacity="0.65" />
            <circle cx="96" cy="184" r="4" fill="#451A03" opacity="0.65" />
            <circle cx="122" cy="172" r="5.5" fill="#451A03" opacity="0.65" />
            <circle cx="136" cy="188" r="3.8" fill="#451A03" opacity="0.65" />
          </g>
        ) : hairStyle === 'pharaoh' ? (
          <g>
            {/* Royal Egyptian Wesekh Golden Collar */}
            <path
              d="M 58 156 Q 100 188 142 156 L 150 174 Q 100 202 50 174 Z"
              fill="#F59E0B"
              stroke="#78350F"
              strokeWidth="2.5"
            />
            <path
              d="M 65 162 Q 100 188 135 162"
              fill="none"
              stroke="#1D4ED8"
              strokeWidth="4"
              strokeDasharray="6 4"
            />
            <circle cx="100" cy="178" r="4" fill="#0EA5E9" stroke="#78350F" strokeWidth="1.2" />
            <circle cx="80" cy="172" r="3" fill="#EF4444" stroke="#78350F" strokeWidth="1.2" />
            <circle cx="120" cy="172" r="3" fill="#EF4444" stroke="#78350F" strokeWidth="1.2" />
          </g>
        ) : hairStyle === 'mummy' ? (
          <g>
            {/* Mummy shoulder wrappings */}
            <path
              d="M 48 164 L 152 178 L 156 188 L 44 176 Z"
              fill="#EFE7D6"
              stroke="#8C7A5B"
              strokeWidth="2"
            />
            <path
              d="M 44 185 L 154 166 L 158 178 L 42 195 Z"
              fill="#E2D5BC"
              stroke="#8C7A5B"
              strokeWidth="2"
            />
          </g>
        ) : hairStyle === 'sage' ? (
          <g>
            {/* Saffron & Violet Sage Meditation Shawl + Rudraksha Mala Beads */}
            <path
              d="M 44 176 L 156 158 L 160 195 L 40 195 Z"
              fill="#F59E0B"
              stroke="#78350F"
              strokeWidth="2.5"
              opacity="0.92"
            />
            <path
              d="M 74 150 Q 100 184 126 150"
              fill="none"
              stroke="#78350F"
              strokeWidth="2.5"
            />
            {[
              [82, 160],
              [90, 167],
              [100, 170],
              [110, 167],
              [118, 160],
            ].map(([bx, by], idx) => (
              <circle
                key={`mala-${idx}`}
                cx={bx}
                cy={by}
                r="3.8"
                fill="#92400E"
                stroke="#451A03"
                strokeWidth="1.2"
              />
            ))}
          </g>
        ) : (
          <path
            d="M 88 150 L 100 166 L 112 150"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3"
            strokeLinecap="round"
          />
        )}

        {/* Head / Face */}
        <circle
          cx="100"
          cy="95"
          r="48"
          fill={skinColor}
          stroke="#451A03"
          strokeWidth="3.5"
        />

        {/* Ears */}
        <circle cx="52" cy="95" r="9" fill={skinColor} stroke="#451A03" strokeWidth="3" />
        <circle cx="148" cy="95" r="9" fill={skinColor} stroke="#451A03" strokeWidth="3" />

        {/* Hair Styles */}
        {hairStyle === 'short' && (
          <path
            d="M 50 85 C 50 48 70 42 100 42 C 130 42 150 48 150 85 C 145 65 130 55 100 55 C 70 55 55 65 50 85 Z"
            fill={hairColor}
            stroke="#451A03"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />
        )}

        {hairStyle === 'curly' && (
          <g fill={hairColor} stroke="#451A03" strokeWidth="3">
            <circle cx="65" cy="60" r="18" />
            <circle cx="95" cy="50" r="22" />
            <circle cx="130" cy="58" r="19" />
            <circle cx="145" cy="80" r="15" />
            <circle cx="55" cy="80" r="15" />
          </g>
        )}

        {hairStyle === 'afro' && (
          <path
            d="M 45 105 C 30 50 70 25 100 25 C 130 25 170 50 155 105 C 145 70 135 55 100 55 C 65 55 55 70 45 105 Z"
            fill={hairColor}
            stroke="#451A03"
            strokeWidth="3.5"
          />
        )}

        {hairStyle === 'bun' && (
          <g>
            <circle cx="100" cy="38" r="18" fill={hairColor} stroke="#451A03" strokeWidth="3.5" />
            <path
              d="M 54 85 C 54 52 75 48 100 48 C 125 48 146 52 146 85 C 135 62 120 58 100 58 C 80 58 65 62 54 85 Z"
              fill={hairColor}
              stroke="#451A03"
              strokeWidth="3.5"
            />
          </g>
        )}

        {hairStyle === 'beanie' && (
          <g>
            <path
              d="M 52 82 C 52 46 72 38 100 38 C 128 38 148 46 148 82 Z"
              fill="#374151"
              stroke="#111827"
              strokeWidth="3.5"
            />
            <rect x="48" y="76" width="104" height="14" rx="6" fill="#4B5563" stroke="#111827" strokeWidth="3" />
          </g>
        )}

        {hairStyle === 'chef' && (
          <g>
            {/* Chef Hat puffs */}
            <path
              d="M 55 75 C 35 45 60 20 85 28 C 95 15 115 15 125 28 C 150 20 165 45 145 75 Z"
              fill="#FFFFFF"
              stroke="#451A03"
              strokeWidth="3.5"
            />
            <rect x="56" y="70" width="88" height="14" rx="2" fill="#F3F4F6" stroke="#451A03" strokeWidth="3" />
          </g>
        )}

        {hairStyle === 'caveman' && (
          <g>
            {/* Wild Shaggy Caveman Mane */}
            <path
              d="M 46 105 C 34 72 48 34 74 36 L 84 22 L 98 34 L 114 20 L 126 36 C 152 34 166 72 154 105 C 148 76 135 58 100 58 C 65 58 52 76 46 105 Z"
              fill={hairColor}
              stroke="#29170B"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />
            {/* Rugged prehistoric beard outline around jaw */}
            <path
              d="M 54 106 Q 60 148 100 152 Q 140 148 146 106 Q 134 128 100 130 Q 66 128 54 106 Z"
              fill={hairColor}
              opacity="0.88"
              stroke="#29170B"
              strokeWidth="2.5"
            />
          </g>
        )}

        {hairStyle === 'pharaoh' && (
          <g>
            {/* Pharaoh Nemes Royal Striped Headdress */}
            <path
              d="M 52 62 C 56 32 144 32 148 62 L 166 144 Q 150 156 138 144 L 138 82 Q 100 70 62 82 L 62 144 Q 50 156 34 144 Z"
              fill="#FBBF24"
              stroke="#78350F"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            {/* Lapis-lazuli royal stripes */}
            <g stroke="#1D4ED8" strokeWidth="4.5" strokeLinecap="round" opacity="0.9">
              <line x1="60" y1="54" x2="140" y2="54" />
              <line x1="56" y1="64" x2="144" y2="64" />
              <line x1="48" y1="95" x2="60" y2="95" />
              <line x1="44" y1="112" x2="60" y2="112" />
              <line x1="40" y1="129" x2="60" y2="129" />
              <line x1="140" y1="95" x2="152" y2="95" />
              <line x1="140" y1="112" x2="156" y2="112" />
              <line x1="140" y1="129" x2="160" y2="129" />
            </g>
            {/* Golden forehead band & Uraeus Cobra Crest */}
            <path
              d="M 55 72 Q 100 62 145 72"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="5"
              strokeLinecap="round"
            />
            <path
              d="M 100 66 C 95 54 92 42 100 36 C 108 42 105 54 100 66 Z"
              fill="#F59E0B"
              stroke="#78350F"
              strokeWidth="2"
            />
            <circle cx="100" cy="45" r="3" fill="#EF4444" />
            {/* Ceremonial Pharaoh Beard */}
            <path
              d="M 94 140 L 106 140 L 104 166 Q 100 172 96 166 Z"
              fill="#1E3A8A"
              stroke="#FBBF24"
              strokeWidth="2"
            />
          </g>
        )}

        {hairStyle === 'mummy' && (
          <g>
            {/* Crisp Linen Mummy Wrappings across forehead, crown & cheeks */}
            <path
              d="M 52 84 C 52 44 148 44 148 84 Q 100 72 52 84 Z"
              fill="#F3ECE0"
              stroke="#8C7A5B"
              strokeWidth="2.8"
            />
            <path
              d="M 54 70 L 146 58 L 148 70 L 52 82 Z"
              fill="#E5D9C3"
              stroke="#8C7A5B"
              strokeWidth="2"
            />
            <path
              d="M 56 54 L 138 66 L 144 54 L 64 44 Z"
              fill="#F5EFE4"
              stroke="#8C7A5B"
              strokeWidth="2"
            />
            {/* Lower jaw mummy bandage wrap */}
            <path
              d="M 55 112 Q 100 126 145 112 Q 140 144 100 146 Q 60 144 55 112 Z"
              fill="#EFE7D6"
              stroke="#8C7A5B"
              strokeWidth="2.2"
            />
            <path
              d="M 62 126 L 138 134"
              stroke="#8C7A5B"
              strokeWidth="1.8"
            />
            {/* Loose trailing bandage tail */}
            <path
              d="M 145 64 Q 168 72 162 96"
              fill="none"
              stroke="#EFE7D6"
              strokeWidth="7"
              strokeLinecap="round"
            />
            <path
              d="M 145 64 Q 168 72 162 96"
              fill="none"
              stroke="#8C7A5B"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </g>
        )}

        {hairStyle === 'sage' && (
          <g>
            {/* Ornate Indian Sage Turban (Pagri) with draped folds and golden forehead gem */}
            <path
              d="M 46 84 C 42 40 74 22 100 22 C 126 22 158 40 154 84 C 134 68 114 66 100 72 C 86 66 66 68 46 84 Z"
              fill="#7C3AED"
              stroke="#4C1D95"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            {/* Turban diagonal cloth folds */}
            <path
              d="M 52 66 Q 92 42 146 58"
              fill="none"
              stroke="#C4B5FD"
              strokeWidth="3"
              strokeLinecap="round"
              opacity="0.7"
            />
            <path
              d="M 54 52 Q 100 32 144 48"
              fill="none"
              stroke="#DDD6FE"
              strokeWidth="2.5"
              strokeLinecap="round"
              opacity="0.6"
            />
            <path
              d="M 48 76 Q 86 58 110 70"
              fill="none"
              stroke="#F59E0B"
              strokeWidth="3"
              strokeLinecap="round"
            />
            {/* Golden Kalgi Crest & Ruby Centerpiece */}
            <path
              d="M 100 62 L 94 42 Q 100 32 106 42 Z"
              fill="#FBBF24"
              stroke="#78350F"
              strokeWidth="1.8"
            />
            <circle cx="100" cy="54" r="4.5" fill="#F59E0B" stroke="#78350F" strokeWidth="1.5" />
            <circle cx="100" cy="54" r="2.2" fill="#EF4444" />

            {/* Wise Silver-Gray Flowing Beard & Mustache */}
            <path
              d="M 56 108 Q 62 156 100 162 Q 138 156 144 108 Q 132 128 100 130 Q 68 128 56 108 Z"
              fill={hairColor}
              stroke="#475569"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />
            <path
              d="M 80 116 Q 100 110 120 116 Q 112 125 100 122 Q 88 125 80 116 Z"
              fill="#F1F5F9"
              stroke="#64748B"
              strokeWidth="1.5"
            />
          </g>
        )}

        {/* Eyebrows */}
        {isAngry ? (
          <g stroke="#451A03" strokeWidth="3.5" strokeLinecap="round">
            <line x1="72" y1="78" x2="88" y2="85" />
            <line x1="128" y1="78" x2="112" y2="85" />
          </g>
        ) : isImpatient ? (
          <g stroke="#451A03" strokeWidth="3.5" strokeLinecap="round">
            <line x1="72" y1="80" x2="90" y2="83" />
            <line x1="110" y1="80" x2="128" y2="76" />
          </g>
        ) : (
          <g stroke="#451A03" strokeWidth="3" strokeLinecap="round">
            <path d="M 72 80 Q 80 75 88 80" fill="none" />
            <path d="M 112 80 Q 120 75 128 80" fill="none" />
          </g>
        )}

        {/* Eyes */}
        {isHappy ? (
          // Joyful smiling eyes (arcs)
          <g stroke="#451A03" strokeWidth="3.5" fill="none" strokeLinecap="round">
            <path d="M 74 96 Q 81 88 88 96" />
            <path d="M 112 96 Q 119 88 126 96" />
          </g>
        ) : isAngry ? (
          // Sharp annoyed eyes
          <g fill="#1F2937">
            <circle cx="81" cy="94" r="4.5" />
            <circle cx="119" cy="94" r="4.5" />
          </g>
        ) : (
          // Regular big friendly eyes
          <g fill="#1F2937">
            <ellipse cx="81" cy="94" rx="4.5" ry="6" />
            <ellipse cx="119" cy="94" rx="4.5" ry="6" />
            <circle cx="83" cy="92" r="1.8" fill="#FFFFFF" />
            <circle cx="121" cy="92" r="1.8" fill="#FFFFFF" />
          </g>
        )}

        {/* Cute blush cheeks */}
        <circle cx="68" cy="104" r="10" fill={`url(#blush-${config.skinColor})`} />
        <circle cx="132" cy="104" r="10" fill={`url(#blush-${config.skinColor})`} />

        {/* Nose */}
        <path
          d="M 97 98 Q 102 104 100 106"
          fill="none"
          stroke="#451A03"
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Mouth */}
        {emotion === 'ecstatic' ? (
          <path
            d="M 82 112 Q 100 134 118 112 Z"
            fill="#DC2626"
            stroke="#451A03"
            strokeWidth="3"
            strokeLinejoin="round"
          />
        ) : isHappy ? (
          <path
            d="M 85 114 Q 100 126 115 114"
            fill="none"
            stroke="#451A03"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        ) : isAngry ? (
          <path
            d="M 86 122 Q 100 114 114 122"
            fill="none"
            stroke="#451A03"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        ) : isImpatient ? (
          <path
            d="M 88 118 L 112 116"
            fill="none"
            stroke="#451A03"
            strokeWidth="3"
            strokeLinecap="round"
          />
        ) : (
          <path
            d="M 89 116 Q 100 122 111 116"
            fill="none"
            stroke="#451A03"
            strokeWidth="3"
            strokeLinecap="round"
          />
        )}

        {/* Glasses Accessory */}
        {accessory === 'glasses' && (
          <g stroke="#1E293B" strokeWidth="3.5" fill="none">
            <rect x="68" y="86" width="26" height="18" rx="4" />
            <rect x="106" y="86" width="26" height="18" rx="4" />
            <line x1="94" y1="94" x2="106" y2="94" />
            <line x1="56" y1="92" x2="68" y2="92" />
            <line x1="132" y1="92" x2="144" y2="92" />
          </g>
        )}

        {/* Mustache Accessory */}
        {accessory === 'mustache' && (
          <path
            d="M 85 112 C 90 106 98 110 100 113 C 102 110 110 106 115 112 C 120 118 108 122 100 116 C 92 122 80 118 85 112 Z"
            fill={hairColor}
            stroke="#451A03"
            strokeWidth="2"
          />
        )}

        {/* Earring Accessory */}
        {accessory === 'earring' && (
          <circle cx="51" cy="102" r="3.5" fill="#F59E0B" stroke="#78350F" strokeWidth="1" />
        )}

        {/* Prehistoric Bone Accessory */}
        {accessory === 'bone' && (
          <g transform="translate(132, 42) rotate(-25)">
            <rect x="-14" y="-3.5" width="28" height="7" rx="3" fill="#FEF3C7" stroke="#78350F" strokeWidth="2" />
            <circle cx="-14" cy="-3.5" r="4" fill="#FEF3C7" stroke="#78350F" strokeWidth="1.8" />
            <circle cx="-14" cy="3.5" r="4" fill="#FEF3C7" stroke="#78350F" strokeWidth="1.8" />
            <circle cx="14" cy="-3.5" r="4" fill="#FEF3C7" stroke="#78350F" strokeWidth="1.8" />
            <circle cx="14" cy="3.5" r="4" fill="#FEF3C7" stroke="#78350F" strokeWidth="1.8" />
            <rect x="-12" y="-2.5" width="24" height="5" fill="#FEF3C7" />
          </g>
        )}

        {/* Traditional Tilak / Bindi Mark */}
        {accessory === 'bindi' && (
          <g>
            <path
              d="M 96 71 Q 100 77 104 71"
              fill="none"
              stroke="#F59E0B"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
            <circle cx="100" cy="79" r="3.2" fill="#DC2626" stroke="#7F1D1D" strokeWidth="0.9" />
          </g>
        )}

        {/* Sweat drop if impatient */}
        {isImpatient && (
          <path
            d="M 140 76 Q 146 84 140 88 Q 134 84 140 76 Z"
            fill="#38BDF8"
            stroke="#0284C7"
            strokeWidth="1.5"
            className="animate-bounce"
          />
        )}
      </svg>
    </div>
  );
};
