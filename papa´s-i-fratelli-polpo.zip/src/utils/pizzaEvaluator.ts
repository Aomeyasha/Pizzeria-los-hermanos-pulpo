import { CustomerOrder, EvaluationResult, PizzaState } from '../types/pizza';
import { TOPPING_NAMES } from '../data/customers';

export function evaluatePizza(
  pizza: PizzaState,
  order: CustomerOrder,
  patienceRemainingRatio: number
): EvaluationResult {
  const recipe = order.recipe;
  let totalPoints = 0;
  const breakdown: EvaluationResult['breakdown'] = {
    doughOk: true,
    sauceOk: true,
    cheeseOk: true,
    toppingsOk: true,
    bakeOk: true,
    cutsOk: true,
  };

  const feedbackNotes: string[] = [];

  // 0. Dough, Size & Geometric Mold Evaluation (Weight: 20 pts)
  let doughPoints = 20;
  const targetSize = recipe.size || pizza.size;
  const targetShape = recipe.shape || pizza.shape;

  if (!pizza.doughCompleted) {
    doughPoints = 0;
    breakdown.doughOk = false;
    breakdown.doughFeedback = 'Faltó pesar, mezclar y moldear la masa';
    feedbackNotes.push('No preparaste la masa ni usaste el molde');
  } else if (recipe.dough && pizza.dough !== recipe.dough) {
    doughPoints = 4;
    breakdown.doughOk = false;
    breakdown.doughFeedback =
      recipe.dough === 'naan_verde'
        ? 'Pedí masa de Harina Naan Verde con ghee y ajo'
        : 'Usaste el tipo de harina equivocado';
    feedbackNotes.push(
      recipe.dough === 'naan_verde'
        ? 'No usaste la Harina Naan Verde en el mostrador de Masa'
        : 'Usaste un tipo de harina incorrecto'
    );
  } else if (pizza.size !== targetSize || pizza.shape !== targetShape) {
    doughPoints = 5;
    breakdown.doughOk = false;
    breakdown.doughFeedback = `Pedí ${targetSize} de ${targetShape}`;
    feedbackNotes.push(`Pedí pizza ${targetSize} de ${targetShape}`);
  } else if (pizza.doughScore < 60) {
    doughPoints = 4;
    breakdown.doughOk = false;
    breakdown.doughFeedback = 'Sabor alterado por exceso/desorden en la masa';
    feedbackNotes.push('El sabor de la masa quedó alterado (corazones rotos)');
  } else if (pizza.doughScore < 100) {
    doughPoints = Math.round((pizza.doughScore / 100) * 20);
    breakdown.doughFeedback = `Sabor de masa: ${pizza.doughScore}%`;
  }
  totalPoints += doughPoints;

  // 1. Sauce Evaluation (Weight: 15 pts)
  let saucePoints = 15;
  const hasSauce = pizza.sauce.applied && pizza.sauce.coverage >= 30;

  if (recipe.sauce === 'none') {
    if (hasSauce) {
      saucePoints = 0;
      breakdown.sauceOk = false;
      breakdown.sauceFeedback = '¡Te pedí que no le pusieras salsa!';
      feedbackNotes.push('¡Tiene salsa de tomate y no la pedí!');
    }
  } else if (recipe.sauce === 'whole') {
    if (!hasSauce) {
      saucePoints = 0;
      breakdown.sauceOk = false;
      breakdown.sauceFeedback = '¿Dónde está la salsa de tomate?';
      feedbackNotes.push('Le falta la salsa roja');
    } else if (pizza.sauce.coverage < 50) {
      saucePoints = 9;
      breakdown.sauceFeedback = 'La salsa está un poco escasa';
    }
  }
  totalPoints += saucePoints;

  // 2. Cheese Evaluation (Weight: 15 pts)
  let cheesePoints = 15;
  const hasCheese = pizza.cheese.applied && pizza.cheese.coverage >= 30;

  if (recipe.cheese === 'none') {
    if (hasCheese) {
      cheesePoints = 0;
      breakdown.cheeseOk = false;
      breakdown.cheeseFeedback = '¡Pedí explícitamente sin queso!';
      feedbackNotes.push('¡Tiene queso y soy intolerante/vegano!');
    }
  } else if (recipe.cheese === 'whole') {
    if (!hasCheese) {
      cheesePoints = 0;
      breakdown.cheeseOk = false;
      breakdown.cheeseFeedback = '¡Olvidaste ponerle el queso derretido!';
      feedbackNotes.push('Le falta el queso mozzarella');
    } else if (pizza.cheese.coverage < 50) {
      cheesePoints = 9;
      breakdown.cheeseFeedback = 'Podría tener un poco más de queso';
    }
  }
  totalPoints += cheesePoints;

  // 3. Toppings Evaluation (Weight: 25 pts)
  let toppingPoints = 25;
  const requestedTypes = new Set(recipe.toppings.map((t) => t.type));
  
  // A. Check for unwanted toppings
  const unwantedToppingsPlaced = pizza.toppings.filter((t) => !requestedTypes.has(t.type));
  if (unwantedToppingsPlaced.length > 0) {
    const penalty = Math.min(20, unwantedToppingsPlaced.length * 4);
    toppingPoints = Math.max(0, toppingPoints - penalty);
    breakdown.toppingsOk = false;
    const unwantedName = TOPPING_NAMES[unwantedToppingsPlaced[0].type] || unwantedToppingsPlaced[0].type;
    feedbackNotes.push(`¿Por qué hay ${unwantedName} aquí?`);
  }

  // B. Check each requested topping
  if (recipe.toppings.length === 0) {
    // If no toppings were requested, but some were placed
    if (pizza.toppings.length > 0) {
      toppingPoints = 5;
      breakdown.toppingsOk = false;
      feedbackNotes.push('¡No pedí ningún ingrediente extra!');
    }
  } else {
    for (const req of recipe.toppings) {
      const placedForThisType = pizza.toppings.filter((t) => t.type === req.type);
      const toppingLabel = TOPPING_NAMES[req.type] || req.type;

      // Filter by placement side (x < 50 is left, x >= 50 is right)
      let sideCount = placedForThisType.length;
      let wrongSideCount = 0;

      if (req.placement === 'left') {
        const leftCount = placedForThisType.filter((t) => t.x < 50).length;
        const rightCount = placedForThisType.filter((t) => t.x >= 50).length;
        sideCount = leftCount;
        wrongSideCount = rightCount;
      } else if (req.placement === 'right') {
        const rightCount = placedForThisType.filter((t) => t.x >= 50).length;
        const leftCount = placedForThisType.filter((t) => t.x < 50).length;
        sideCount = rightCount;
        wrongSideCount = leftCount;
      }

      if (wrongSideCount > 3) {
        toppingPoints = Math.max(0, toppingPoints - 8);
        feedbackNotes.push(`Pusiste ${toppingLabel} en la mitad equivocada`);
      }

      if (req.exactCount !== undefined) {
        // Exact unit count evaluation (e.g., 1..6 units in Pizza de Mamut orders)
        if (sideCount === 0) {
          toppingPoints = Math.max(0, toppingPoints - 12);
          breakdown.toppingsOk = false;
          feedbackNotes.push(`¡Faltaron ${req.exactCount} de ${toppingLabel}!`);
        } else if (sideCount < req.exactCount) {
          toppingPoints = Math.max(0, toppingPoints - 5);
          breakdown.toppingsOk = false;
          feedbackNotes.push(`Pedí ${req.exactCount} de ${toppingLabel}, pero pusiste ${sideCount}`);
        } else if (sideCount > req.exactCount) {
          toppingPoints = Math.max(0, toppingPoints - 5);
          breakdown.toppingsOk = false;
          feedbackNotes.push(`Pedí exactamente ${req.exactCount} de ${toppingLabel}, y pusiste ${sideCount}`);
        }
      } else {
        const minReq = req.minCount || 10;
        const recommended = req.recommendedCount || 16;

        if (sideCount === 0) {
          toppingPoints = Math.max(0, toppingPoints - 15);
          breakdown.toppingsOk = false;
          feedbackNotes.push(`¡No pusiste nada de ${toppingLabel}!`);
        } else if (sideCount < minReq) {
          toppingPoints = Math.max(0, toppingPoints - 6);
          feedbackNotes.push(`Un poco tacaño con ${toppingLabel}`);
        } else if (sideCount >= recommended * 1.6) {
          toppingPoints = Math.max(0, toppingPoints - 3);
          feedbackNotes.push(`Hay demasiado ${toppingLabel}`);
        }
      }
    }
  }
  totalPoints += toppingPoints;

  // 4. Baking Evaluation (Weight: 15 pts)
  let bakePoints = 15;
  if (pizza.bakeLevel === 0) {
    // Completely raw
    bakePoints = 0;
    breakdown.bakeOk = false;
    feedbackNotes.push('¡La pizza está completamente cruda!');
  } else if (pizza.bakeLevel === 3) {
    // Burnt
    bakePoints = 0;
    breakdown.bakeOk = false;
    feedbackNotes.push('¡La masa está carbonizada y quemada!');
  } else if (pizza.bakeLevel === recipe.bakeLevel) {
    // Perfect bake match
    bakePoints = 15;
  } else if (recipe.bakeLevel === 2 && pizza.bakeLevel === 1) {
    // Customer wanted double-bake (well done) but got normal
    bakePoints = 7;
    breakdown.bakeOk = false;
    feedbackNotes.push('Te pedí que la hornearas dos veces para que quede crujiente');
  } else if (recipe.bakeLevel === 1 && pizza.bakeLevel === 2) {
    // Normal requested, but baked twice
    bakePoints = 9;
    feedbackNotes.push('Está un poco más tostada de lo que quería');
  }
  totalPoints += bakePoints;

  // 5. Cuts Evaluation (Weight: 10 pts)
  let cutPoints = 10;
  const actualSlices = pizza.slicesCount;
  const requestedSlices = recipe.cuts;

  if (requestedSlices === 0) {
    if (actualSlices > 1) {
      cutPoints = 0;
      breakdown.cutsOk = false;
      feedbackNotes.push('¡Te pedí explícitamente sin cortar!');
    }
  } else {
    if (actualSlices <= 1) {
      cutPoints = 2;
      breakdown.cutsOk = false;
      feedbackNotes.push(`Olvidaste cortarla en ${requestedSlices} porciones`);
    } else if (actualSlices === requestedSlices) {
      cutPoints = 10;
    } else if (Math.abs(actualSlices - requestedSlices) <= 2) {
      cutPoints = 6;
      feedbackNotes.push(`Pedí ${requestedSlices} porciones, pero hiciste ${actualSlices}`);
    } else {
      cutPoints = 3;
      breakdown.cutsOk = false;
      feedbackNotes.push(`El número de cortes no es el que pedí (${requestedSlices})`);
    }
  }
  totalPoints += cutPoints;

  // Calculate final score percentage (clamp 0..100)
  const finalScore = Math.min(100, Math.max(0, Math.round(totalPoints)));
  const passed = finalScore >= 60;

  // Calculate earnings and tips
  let basePriceEarned = 0;
  let tipEarned = 0;
  let customerReaction: EvaluationResult['customerReaction'] = 'meh';
  let feedbackDialogue = '';

  if (finalScore >= 90) {
    customerReaction = 'ecstatic';
    basePriceEarned = order.basePrice;
    const patienceBonus = 0.5 + 0.5 * Math.max(0, patienceRemainingRatio);
    tipEarned = Math.round((order.basePrice * 0.35 * order.tipMultiplier * patienceBonus) * 100) / 100;
    feedbackDialogue = '¡Increíble! ¡Es una de las mejores pizzas que he probado en mi vida!';
  } else if (finalScore >= 75) {
    customerReaction = 'happy';
    basePriceEarned = order.basePrice;
    const patienceBonus = 0.4 + 0.4 * Math.max(0, patienceRemainingRatio);
    tipEarned = Math.round((order.basePrice * 0.18 * order.tipMultiplier * patienceBonus) * 100) / 100;
    feedbackDialogue = feedbackNotes.length > 0
      ? `¡Muy rica! Aunque: ${feedbackNotes[0]}. ¡Buen trabajo!`
      : '¡Justo lo que quería! Muchas gracias.';
  } else if (finalScore >= 50) {
    customerReaction = 'meh';
    basePriceEarned = Math.round((order.basePrice * 0.8) * 100) / 100;
    tipEarned = 0.25;
    feedbackDialogue = feedbackNotes.length > 0
      ? `Hmm... ${feedbackNotes.join('. ')}. Pero bueno, comeré.`
      : 'No es exactamente lo que esperaba, pero supongo que sirve.';
  } else {
    customerReaction = 'angry';
    basePriceEarned = 0; // Customer refuses to pay!
    tipEarned = 0;
    feedbackDialogue = feedbackNotes.length > 0
      ? `¡Qué desastre! ${feedbackNotes.join('. ')}. ¡No pienso pagar por esto!`
      : '¡Esto no se parece en nada a lo que pedí! ¡Adiós!';
  }

  return {
    score: finalScore,
    passed,
    basePriceEarned,
    tipEarned,
    feedbackDialogue,
    customerReaction,
    breakdown,
  };
}
