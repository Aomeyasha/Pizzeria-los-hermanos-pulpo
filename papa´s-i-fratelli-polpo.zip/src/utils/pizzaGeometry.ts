import { PizzaMagnitudes, PizzaShape, PizzaSize } from '../types/pizza';

export interface SizeCatalogEntry {
  tazas: number;
  harinaRequerida: number;
  medidaEgipcia: string;
  iconoEgipcio: string;
  toquesSilueta: number;
  dimensionCm: number;
  grosorCm: number;
  precio: number;
  escalaVisual: number;
  colorBadge: string;
}

export const CATALOGO_TAMANOS: Record<PizzaSize, SizeCatalogEntry> = {
  Pequeña: {
    tazas: 1,
    harinaRequerida: 150,
    medidaEgipcia: '1 Mano Extendida',
    iconoEgipcio: '🖐️',
    toquesSilueta: 2,
    dimensionCm: 20,
    grosorCm: 0.5,
    precio: 12,
    escalaVisual: 0.78,
    colorBadge: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  },
  Mediana: {
    tazas: 2,
    harinaRequerida: 300,
    medidaEgipcia: '1 Codo',
    iconoEgipcio: '💪',
    toquesSilueta: 4,
    dimensionCm: 30,
    grosorCm: 0.5,
    precio: 22,
    escalaVisual: 0.9,
    colorBadge: 'bg-sky-100 text-sky-800 border-sky-300',
  },
  Familiar: {
    tazas: 3,
    harinaRequerida: 450,
    medidaEgipcia: '2 Codos',
    iconoEgipcio: '💪💪',
    toquesSilueta: 6,
    dimensionCm: 40,
    grosorCm: 0.5,
    precio: 34,
    escalaVisual: 1.0,
    colorBadge: 'bg-purple-100 text-purple-800 border-purple-300',
  },
};

export const ICONOS_FORMA: Record<PizzaShape, string> = {
  Circular: '⭕',
  Cuadrado: '🟧',
  Estrella: '⭐',
  Corazón: '❤️',
};

export const ORDEN_RECETA = ['Harina', 'Agua', 'Levadura', 'Azúcar', 'Aceite', 'Sal'] as const;

export function calculatePizzaMagnitudes(
  tamano: PizzaSize,
  forma: PizzaShape,
  calificacionMasa: number
): PizzaMagnitudes {
  const datos = CATALOGO_TAMANOS[tamano];
  const d = datos.dimensionCm;
  const r = d / 2;
  let longitudCm = 0;
  let areaCm2 = 0;

  switch (forma) {
    case 'Circular':
      longitudCm = 2 * Math.PI * r;
      areaCm2 = Math.PI * r * r;
      break;
    case 'Cuadrado':
      longitudCm = 4 * d;
      areaCm2 = d * d;
      break;
    case 'Estrella':
      longitudCm = 10 * (r * 0.45);
      areaCm2 = 1.122 * r * r;
      break;
    case 'Corazón': {
      const lado = d * 0.6;
      longitudCm = 2 * lado + Math.PI * lado;
      areaCm2 = lado * lado + Math.PI * Math.pow(lado / 2, 2);
      break;
    }
  }

  const volumenCm3 = areaCm2 * datos.grosorCm;
  const masaTotalGramos = datos.harinaRequerida + 283;
  const pesoNewtons = (masaTotalGramos / 1000) * 9.81;

  return {
    tamano,
    forma,
    precio: datos.precio,
    calificacionMasa,
    longitudCm: longitudCm.toFixed(0),
    areaCm2: areaCm2.toFixed(0),
    volumenCm3: volumenCm3.toFixed(0),
    capacidadMl: 270,
    masaGramos: masaTotalGramos,
    pesoNewtons: pesoNewtons.toFixed(1),
  };
}

export function generateAudiovisualScript(
  tamano: PizzaSize,
  forma: PizzaShape,
  harinaEnGramera: number
): string {
  return `PROMPT ESCENA — PREPARACIÓN DE PIZZA ${forma.toUpperCase()} (${tamano.toUpperCase()})
- Formato técnico: 16:9 / 9:16, 1080p, 30 fps, estética infantil educativa luminosa.
- Continuidad obligatoria: Masa de pizza tamaño ${tamano} con forma geométrica exacta de ${forma}, paleta cálida (amarillo masa #FDE68A, rojo salsa #DC2626, madera clara).
- Acción cronológica: Pesaje de ${harinaEnGramera} g de harina en gramera digital, mezcla secuencial en bowl, amasado con rodillo y moldeado en figura de ${forma}.
- Cámara y luz: Plano cenital (top-down) y plano medio sobre mesón de cocina infantil, luz natural suave, sin parpadeos ni deformaciones de manos u objetos.
- Estado de control de calidad: APROBADO (Coherencia de escala y forma mantenida en Salsa, Toppings, Horno y Corte).`;
}

// SVG path / element properties inside a 0..100 viewBox centered at (50, 50)
export const STAR_POINTS_100 =
  '50,6 62,34 93,37 69.5,57.5 76.5,88 50,72 23.5,88 30.5,57.5 7,37 38,34';

export const HEART_PATH_100 =
  'M50 88 C50 88 10 62 10 34 C10 20 21 10 34 10 C42 10 47.5 14.5 50 20 C52.5 14.5 58 10 66 10 C79 10 90 20 90 34 C90 62 50 88 50 88 Z';
