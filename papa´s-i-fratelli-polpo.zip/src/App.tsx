import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  CustomerOrder,
  DayFinancials,
  EvaluationResult,
  GameUpgrades,
  PizzaShape,
  PizzaSize,
  PizzaState,
  ToppingType,
  SaveSlot,
} from './types/pizza';
import {
  CUSTOMER_POOL,
  BASE_COSTS,
  TOPPING_NAMES,
  createMamutCustomerOrder,
  createEgyptianCustomerOrder,
  createPizzaEgipciaOrder,
  createSabioIndiaOrder,
  createRuedaMaharajaOrder,
  isEgyptianPizzaEnabled,
  isRuedaMaharajaEnabled,
} from './data/customers';
import { PNN_NEWS_ARCHIVE } from './data/news';
import { evaluatePizza } from './utils/pizzaEvaluator';
import { CATALOGO_TAMANOS, ICONOS_FORMA } from './utils/pizzaGeometry';
import { sounds } from './services/soundEffects';

import { CustomerAvatar } from './components/CustomerAvatar';
import { ToppingSprite } from './components/ToppingSprite';
import { DoughStation } from './components/DoughStation';
import { MixingStation } from './components/MixingStation';
import { KitchenStation } from './components/KitchenStation';
import { OvenStation } from './components/OvenStation';
import { CuttingStation } from './components/CuttingStation';
import { PnnBroadcast } from './components/PnnBroadcast';
import { CustomerReactionModal } from './components/CustomerReactionModal';
import { DaySummaryModal } from './components/DaySummaryModal';
import { UpgradesShop } from './components/UpgradesShop';
import { RecipeBookModal } from './components/RecipeBookModal';
import { OctaviaReminder } from './components/OctaviaReminder';
import { SaveSlotsSelector } from './components/SaveSlotsSelector';
import { WoodParchmentBoard } from './components/WoodParchmentBoard';

import {
  Volume2,
  VolumeX,
  Music,
  BookOpen,
  ShoppingBag,
  HelpCircle,
  Play,
  RotateCcw,
  Sparkles,
  Clock,
  DollarSign,
  ChefHat,
  Receipt,
  Home,
} from 'lucide-react';

const INITIAL_PIZZA: PizzaState = {
  id: 'pizza-initial',
  dough: 'normal',
  size: 'Mediana',
  shape: 'Circular',
  doughCompleted: false,
  flourWeighed: false,
  doughScore: 100,
  harinaEnGramera: 0,
  magnitudes: null,
  sauce: {
    applied: false,
    coverage: 0,
    points: [],
    half: 'whole',
  },
  cheese: {
    applied: false,
    coverage: 0,
    points: [],
    half: 'whole',
  },
  toppings: [],
  bakeLevel: 0,
  cuts: [],
  slicesCount: 1,
};

const DEFAULT_UPGRADES: GameUpgrades = {
  fastOven: false,
  cutterGuide: false,
  toppingGuide: false,
  autoSauceCheese: false,
  warmBox: false,
  cozyDecorLevel: 0,
  naanVerdeFlour: false,
  unlockedToppings: ['pepperoni', 'mushroom', 'olive'],
};

const DEFAULT_SLOTS: SaveSlot[] = [
  {
    id: 1,
    title: 'Partida 1',
    day: 1,
    cash: 55.0,
    upgrades: DEFAULT_UPGRADES,
    lastPlayed: 'Nueva Partida',
    isUsed: false,
  },
  {
    id: 2,
    title: 'Partida 2',
    day: 1,
    cash: 55.0,
    upgrades: DEFAULT_UPGRADES,
    lastPlayed: 'Nueva Partida',
    isUsed: false,
  },
  {
    id: 3,
    title: 'Partida 3',
    day: 1,
    cash: 55.0,
    upgrades: DEFAULT_UPGRADES,
    lastPlayed: 'Nueva Partida',
    isUsed: false,
  },
];

const loadInitialSlots = (): {
  slots: SaveSlot[];
  activeSlotId: number;
  day: number;
  cash: number;
  upgrades: GameUpgrades;
} => {
  try {
    const savedSlotsRaw = localStorage.getItem('gpgp_save_slots');
    const savedActiveRaw = localStorage.getItem('gpgp_active_slot_id');
    const activeId = savedActiveRaw ? parseInt(savedActiveRaw, 10) : 1;

    let slotsList: SaveSlot[] = DEFAULT_SLOTS;

    if (savedSlotsRaw) {
      const parsed = JSON.parse(savedSlotsRaw);
      if (Array.isArray(parsed) && parsed.length === 3) {
        slotsList = parsed;
      }
    } else {
      // Legacy single-save migration
      const legacyDay = localStorage.getItem('gpgp_day');
      const legacyCash = localStorage.getItem('gpgp_cash');
      const legacyUpgrades = localStorage.getItem('gpgp_upgrades');

      if (legacyDay || legacyCash) {
        slotsList = [
          {
            id: 1,
            title: 'Partida 1',
            day: legacyDay ? Math.max(1, parseInt(legacyDay, 10)) : 1,
            cash: legacyCash ? parseFloat(legacyCash) : 55.0,
            upgrades: legacyUpgrades ? JSON.parse(legacyUpgrades) : DEFAULT_UPGRADES,
            lastPlayed: 'Guardado previo',
            isUsed: true,
          },
          DEFAULT_SLOTS[1],
          DEFAULT_SLOTS[2],
        ];
      }
    }

    const currentSlot = slotsList.find((s) => s.id === activeId) || slotsList[0];
    const ensuredToppings = Array.from(
      new Set<ToppingType>([
        ...(currentSlot.upgrades?.unlockedToppings || []),
        'pepperoni',
        'mushroom',
        'olive',
      ])
    );
    return {
      slots: slotsList,
      activeSlotId: currentSlot.id,
      day: currentSlot.day,
      cash: currentSlot.cash,
      upgrades: {
        ...DEFAULT_UPGRADES,
        ...currentSlot.upgrades,
        unlockedToppings: ensuredToppings,
      },
    };
  } catch {
    return {
      slots: DEFAULT_SLOTS,
      activeSlotId: 1,
      day: 1,
      cash: 55.0,
      upgrades: DEFAULT_UPGRADES,
    };
  }
};

export default function App() {
  const initial = useRef(loadInitialSlots()).current;

  // 3 Save Slots state
  const [slots, setSlots] = useState<SaveSlot[]>(initial.slots);
  const [activeSlotId, setActiveSlotId] = useState<number>(initial.activeSlotId);

  // Active game state
  const [day, setDay] = useState<number>(initial.day);
  const [cash, setCash] = useState<number>(initial.cash);
  const [upgrades, setUpgrades] = useState<GameUpgrades>(initial.upgrades);

  // Game state navigation
  type ScreenMode =
    | 'TITLE'
    | 'PNN_NEWS'
    | 'COUNTER'
    | 'DOUGH'
    | 'MIXING'
    | 'KITCHEN'
    | 'OVEN'
    | 'CUTTING'
    | 'CUSTOMER_REACTION'
    | 'DAY_SUMMARY';

  const [screen, setScreen] = useState<ScreenMode>('TITLE');
  const [showShop, setShowShop] = useState(false);
  const [showRecipeBook, setShowRecipeBook] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isMusicOn, setIsMusicOn] = useState(false);

  // Day simulation state
  const [dayMinutes, setDayMinutes] = useState<number>(540); // 9:00 AM (9 * 60)
  const [dayCustomersQueue, setDayCustomersQueue] = useState<CustomerOrder[]>([]);
  const [currentOrder, setCurrentOrder] = useState<CustomerOrder | null>(null);
  const [customerPatience, setCustomerPatience] = useState<number>(100);
  const [clarifiedOrder, setClarifiedOrder] = useState<boolean>(false);
  const [orderTicketOpen, setOrderTicketOpen] = useState<boolean>(true);
  const [restoredFromEgyptian, setRestoredFromEgyptian] = useState<boolean>(false);

  // Active Pizza
  const [pizza, setPizza] = useState<PizzaState>(INITIAL_PIZZA);
  const [lastEvaluation, setLastEvaluation] = useState<EvaluationResult | null>(null);

  // Day Financials ledger
  const [dayFinancials, setDayFinancials] = useState<DayFinancials>({
    pizzasCompleted: 0,
    pizzasFailed: 0,
    grossIncome: 0,
    tipsIncome: 0,
    ingredientsCost: 0,
    rent: 10.0,
    netProfit: 0,
  });

  // Save to localStorage & sync active slot
  useEffect(() => {
    const now = new Date();
    const formattedTime = `${now.getDate()}/${now.getMonth() + 1} ${now.getHours()}:${now.getMinutes() < 10 ? '0' : ''}${now.getMinutes()}`;

    setSlots((prevSlots) => {
      const updated = prevSlots.map((s) => {
        if (s.id === activeSlotId) {
          return {
            ...s,
            day,
            cash,
            upgrades,
            lastPlayed: formattedTime,
            isUsed: true,
          };
        }
        return s;
      });
      try {
        localStorage.setItem('gpgp_save_slots', JSON.stringify(updated));
        localStorage.setItem('gpgp_active_slot_id', activeSlotId.toString());
        localStorage.setItem('gpgp_day', day.toString());
        localStorage.setItem('gpgp_cash', cash.toFixed(2));
        localStorage.setItem('gpgp_upgrades', JSON.stringify(upgrades));
      } catch {}
      return updated;
    });
  }, [day, cash, upgrades, activeSlotId]);

  // Audio toggles
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sounds.setMuted(nextMuted);
    if (nextMuted) setIsMusicOn(false);
  };

  const handleToggleMusic = () => {
    if (isMuted) return;
    const nextMusic = !isMusicOn;
    setIsMusicOn(nextMusic);
    sounds.toggleMusic(nextMusic);
  };

  // Format time of day from minutes (540 = 9:00 AM to 1260 = 9:00 PM) - sin segundos
  const formatTime = (totalMins: number) => {
    const hours = Math.floor(totalMins / 60);
    const mins = Math.floor(totalMins % 60);
    const period = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
    const displayMins = mins < 10 ? `0${mins}` : `${mins}`;
    return `${displayHours}:${displayMins} ${period}`;
  };

  // Select slot without starting
  const handleSelectSlot = (slotId: number) => {
    setActiveSlotId(slotId);
    const target = slots.find((s) => s.id === slotId);
    if (target) {
      setDay(target.day);
      setCash(target.cash);
      setUpgrades(target.upgrades);
      try {
        localStorage.setItem('gpgp_active_slot_id', slotId.toString());
      } catch {}
    }
  };

  // Play immediately with selected slot
  const handlePlaySlot = (slotId: number) => {
    const target = slots.find((s) => s.id === slotId) || slots[0];
    const now = new Date();
    const formattedTime = `${now.getDate()}/${now.getMonth() + 1} ${now.getHours()}:${now.getMinutes() < 10 ? '0' : ''}${now.getMinutes()}`;

    const updatedTarget: SaveSlot = {
      ...target,
      isUsed: true,
      lastPlayed: formattedTime,
    };

    setActiveSlotId(slotId);
    setDay(updatedTarget.day);
    setCash(updatedTarget.cash);
    setUpgrades(updatedTarget.upgrades);

    const updatedSlots = slots.map((s) => (s.id === slotId ? updatedTarget : s));
    setSlots(updatedSlots);
    try {
      localStorage.setItem('gpgp_save_slots', JSON.stringify(updatedSlots));
      localStorage.setItem('gpgp_active_slot_id', slotId.toString());
    } catch {}

    sounds.playChaChing();
    setScreen('PNN_NEWS');
  };

  // Reset a specific slot
  const handleResetSlot = (slotId: number) => {
    const cleanSlot: SaveSlot = {
      id: slotId,
      title: `Partida ${slotId}`,
      day: 1,
      cash: 55.0,
      upgrades: DEFAULT_UPGRADES,
      lastPlayed: 'Nueva Partida',
      isUsed: false,
    };

    const nextSlots = slots.map((s) => (s.id === slotId ? cleanSlot : s));
    setSlots(nextSlots);
    try {
      localStorage.setItem('gpgp_save_slots', JSON.stringify(nextSlots));
    } catch {}

    if (activeSlotId === slotId) {
      setDay(1);
      setCash(55.0);
      setUpgrades(DEFAULT_UPGRADES);
      try {
        localStorage.setItem('gpgp_day', '1');
        localStorage.setItem('gpgp_cash', '55.00');
        localStorage.setItem('gpgp_upgrades', JSON.stringify(DEFAULT_UPGRADES));
      } catch {}
    }
  };

  // Start active Day from title
  const startDayFromTitle = () => {
    handlePlaySlot(activeSlotId);
  };

  // Reset active slot to Day 1
  const handleResetToDay1 = () => {
    handleResetSlot(activeSlotId);
    sounds.playChaChing();
  };

  const startDayWork = () => {
    setRestoredFromEgyptian(false);
    // Pick customers for the day:
    // - Day 1: Moderno + classic customers
    // - Day 2+: Cavernícola joins (Day 2..∞)
    // - Day 3+: Visitantes Egipcios (Faraón / Momia) join (Day 3..∞) with temporary body-measurement mode
    // - Day 4+: Sabio Matemático de la India (El Cero) debuts on Day 4 and stays permanently for all following days (Day 4..∞)
    let selectedCustomers: CustomerOrder[] = [];
    if (day === 1) {
      selectedCustomers = [
        createMamutCustomerOrder('moderno', upgrades.unlockedToppings),
        CUSTOMER_POOL[0],
        CUSTOMER_POOL[1],
        CUSTOMER_POOL[9],
      ];
    } else if (day === 2) {
      const available = CUSTOMER_POOL.filter((c) =>
        c.recipe.toppings.every((t) => upgrades.unlockedToppings.includes(t.type))
      );
      const poolSample = [...available].sort(() => 0.5 - Math.random()).slice(0, 2);
      selectedCustomers = [
        createMamutCustomerOrder('cavernicola', upgrades.unlockedToppings),
        createMamutCustomerOrder('moderno', upgrades.unlockedToppings),
        ...poolSample,
      ].sort(() => 0.5 - Math.random());
    } else if (day === 3) {
      const available = CUSTOMER_POOL.filter((c) =>
        c.recipe.toppings.every((t) => upgrades.unlockedToppings.includes(t.type))
      );
      const poolSample = [...available].sort(() => 0.5 - Math.random()).slice(0, 1);
      const firstEgyptType: 'faraon' | 'momia' = Math.random() < 0.5 ? 'faraon' : 'momia';
      const secondEgyptType: 'faraon' | 'momia' = firstEgyptType === 'faraon' ? 'momia' : 'faraon';
      const egyptianPizzaUnlocked = isEgyptianPizzaEnabled(upgrades.unlockedToppings);

      selectedCustomers = [
        createEgyptianCustomerOrder(firstEgyptType, upgrades.unlockedToppings),
        createMamutCustomerOrder('cavernicola', upgrades.unlockedToppings),
        createEgyptianCustomerOrder(secondEgyptType, upgrades.unlockedToppings),
        createMamutCustomerOrder('moderno', upgrades.unlockedToppings),
        ...(egyptianPizzaUnlocked
          ? [createPizzaEgipciaOrder(), ...(Math.random() < 0.5 ? [createPizzaEgipciaOrder()] : [])]
          : []),
        ...poolSample,
      ].sort(() => 0.5 - Math.random());
    } else {
      // Day 4+: Sabio Matemático de la India arrives on Day 4 and stays for all following days
      // Also Rueda de Maharajá becomes available from Day 4+ once its flour & toppings are purchased
      const available = CUSTOMER_POOL.filter((c) =>
        c.recipe.toppings.every((t) => upgrades.unlockedToppings.includes(t.type))
      );
      const poolSample = [...available].sort(() => 0.5 - Math.random()).slice(0, 1);
      const firstEgyptType: 'faraon' | 'momia' = Math.random() < 0.5 ? 'faraon' : 'momia';
      const egyptianPizzaUnlocked = isEgyptianPizzaEnabled(upgrades.unlockedToppings);
      const ruedaMaharajaUnlocked = isRuedaMaharajaEnabled(upgrades);

      const restOfDay = [
        createEgyptianCustomerOrder(firstEgyptType, upgrades.unlockedToppings),
        createMamutCustomerOrder('cavernicola', upgrades.unlockedToppings),
        createMamutCustomerOrder('moderno', upgrades.unlockedToppings),
        ...(egyptianPizzaUnlocked
          ? [createPizzaEgipciaOrder(), ...(Math.random() < 0.5 ? [createPizzaEgipciaOrder()] : [])]
          : []),
        ...(ruedaMaharajaUnlocked
          ? [createRuedaMaharajaOrder(), ...(Math.random() < 0.5 ? [createRuedaMaharajaOrder()] : [])]
          : []),
        ...poolSample,
      ].sort(() => 0.5 - Math.random());

      const sabioOrder = createSabioIndiaOrder(upgrades.unlockedToppings);
      selectedCustomers =
        day === 4
          ? [sabioOrder, ...restOfDay]
          : [sabioOrder, ...restOfDay].sort(() => 0.5 - Math.random());
    }

    if (selectedCustomers.length === 0) {
      selectedCustomers.push(createMamutCustomerOrder('moderno', upgrades.unlockedToppings));
    }

    setDayCustomersQueue(selectedCustomers);
    setDayMinutes(540); // 9:00 AM
    setDayFinancials({
      pizzasCompleted: 0,
      pizzasFailed: 0,
      grossIncome: 0,
      tipsIncome: 0,
      ingredientsCost: 0,
      rent: 10.0,
      netProfit: 0,
    });

    // Spawn first customer
    loadCustomer(selectedCustomers[0]);
    setScreen('COUNTER');
  };

  const loadCustomer = (order: CustomerOrder) => {
    const tamanos: PizzaSize[] = ['Pequeña', 'Mediana', 'Familiar'];
    const formas: PizzaShape[] = ['Circular', 'Cuadrado', 'Estrella', 'Corazón'];
    const chosenSize: PizzaSize =
      order.recipe.size || tamanos[Math.floor(Math.random() * tamanos.length)];
    const chosenShape: PizzaShape =
      order.recipe.shape || formas[Math.floor(Math.random() * formas.length)];

    const enrichedOrder: CustomerOrder = {
      ...order,
      basePrice: CATALOGO_TAMANOS[chosenSize].precio,
      recipe: {
        ...order.recipe,
        size: chosenSize,
        shape: chosenShape,
      },
    };

    setCurrentOrder(enrichedOrder);
    setCustomerPatience(enrichedOrder.patienceTotal + upgrades.cozyDecorLevel * 10);
    setClarifiedOrder(false);
    setOrderTicketOpen(true);
    setPizza({
      ...INITIAL_PIZZA,
      id: `pizza-${Date.now()}`,
      size: chosenSize,
      shape: chosenShape,
      doughCompleted: false,
      flourWeighed: false,
      doughScore: 100,
    });
    // Charge for the fresh dough base
    deductCost(BASE_COSTS.dough);
    sounds.playBellDing();
  };

  const deductCost = (amount: number) => {
    setCash((prev) => Math.max(0, prev - amount));
    setDayFinancials((prev) => ({
      ...prev,
      ingredientsCost: prev.ingredientsCost + amount,
    }));
  };

  // Timer: day progression and customer patience tick
  useEffect(() => {
    if (
      screen !== 'COUNTER' &&
      screen !== 'DOUGH' &&
      screen !== 'MIXING' &&
      screen !== 'KITCHEN' &&
      screen !== 'OVEN' &&
      screen !== 'CUTTING'
    ) {
      return;
    }

    const timer = setInterval(() => {
      // 1. Advance day clock (1 real second = ~1.8 game minutes)
      setDayMinutes((prev) => {
        const next = prev + 1.8;
        if (next >= 1260) {
          // 9:00 PM - Closing time!
          clearInterval(timer);
          endDay();
          return 1260;
        }
        return next;
      });

      // 2. Reduce customer patience (paused while carefully weighing/mixing in DOUGH or MIXING stations)
      if (currentOrder && screen !== 'DOUGH' && screen !== 'MIXING') {
        setCustomerPatience((prev) => {
          if (prev <= 1) {
            // Customer got fed up and left!
            sounds.playReaction('angry');
            handleCustomerWalkout();
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [screen, currentOrder]);

  const handleCustomerWalkout = () => {
    alert(`${currentOrder?.customerName || 'El cliente'} se ha cansado de esperar y se fue furioso.`);
    setDayFinancials((prev) => ({
      ...prev,
      pizzasFailed: prev.pizzasFailed + 1,
    }));
    advanceQueue();
  };

  // Advance to next customer or end day if queue empty
  const advanceQueue = () => {
    const cameFromEgyptian =
      currentOrder?.customerType === 'faraon' || currentOrder?.customerType === 'momia';

    setDayCustomersQueue((prev) => {
      const remaining = prev.slice(1);
      if (remaining.length > 0) {
        const nextIsEgyptian =
          remaining[0].customerType === 'faraon' || remaining[0].customerType === 'momia';
        setRestoredFromEgyptian(cameFromEgyptian && !nextIsEgyptian);
        loadCustomer(remaining[0]);
        setScreen('COUNTER');
      } else {
        setRestoredFromEgyptian(false);
        endDay();
      }
      return remaining;
    });
  };

  // End of Day calculation
  const endDay = () => {
    sounds.playChaChing();
    setDayFinancials((prev) => {
      const totalEarned = prev.grossIncome + prev.tipsIncome;
      const totalExpenses = prev.ingredientsCost + prev.rent;
      const net = Math.round((totalEarned - totalExpenses) * 100) / 100;
      return {
        ...prev,
        netProfit: net,
      };
    });
    setScreen('DAY_SUMMARY');
  };

  // Player asks "¿Qué?" to clarify order
  const handleAskClarification = () => {
    if (clarifiedOrder) return;
    setClarifiedOrder(true);
    // Slight patience penalty for asking
    setCustomerPatience((prev) => Math.max(15, prev - 12));
    sounds.playSauceSquirt();
  };

  // Player completes pizza at Cutting Station
  const handleServePizza = () => {
    if (!currentOrder) return;

    const patienceRatio = customerPatience / currentOrder.patienceTotal;
    const result = evaluatePizza(pizza, currentOrder, patienceRatio);

    setLastEvaluation(result);

    // Update financials
    setCash((prev) => prev + result.basePriceEarned + result.tipEarned);
    setDayFinancials((prev) => ({
      ...prev,
      pizzasCompleted: result.passed ? prev.pizzasCompleted + 1 : prev.pizzasCompleted,
      pizzasFailed: !result.passed ? prev.pizzasFailed + 1 : prev.pizzasFailed,
      grossIncome: prev.grossIncome + result.basePriceEarned,
      tipsIncome: prev.tipsIncome + result.tipEarned,
    }));

    setScreen('CUSTOMER_REACTION');
  };

  // Discard pizza and roll new dough
  const handleDiscardPizza = () => {
    sounds.playDoughSlap();
    setPizza({
      ...INITIAL_PIZZA,
      id: `pizza-${Date.now()}`,
      size: currentOrder?.recipe.size || 'Mediana',
      shape: currentOrder?.recipe.shape || 'Circular',
      doughCompleted: false,
      flourWeighed: false,
      doughScore: 100,
    });
    deductCost(BASE_COSTS.dough);
    setScreen('DOUGH');
  };

  // Upgrades shop purchases
  const handleBuyUpgrade = (cost: number, key: keyof GameUpgrades, value: any) => {
    if (cash < cost) return;
    const nextUpgrades = {
      ...upgrades,
      [key]: value,
    };
    const wasMaharajaEnabled = isRuedaMaharajaEnabled(upgrades);
    const nowMaharajaEnabled = isRuedaMaharajaEnabled(nextUpgrades);

    setCash((c) => c - cost);
    setUpgrades(nextUpgrades);

    if (
      day >= 4 &&
      !wasMaharajaEnabled &&
      nowMaharajaEnabled &&
      screen !== 'TITLE' &&
      screen !== 'PNN_NEWS' &&
      screen !== 'DAY_SUMMARY'
    ) {
      setDayCustomersQueue((prev) => [...prev, createRuedaMaharajaOrder()]);
    }

    sounds.playChaChing();
  };

  const handleUnlockTopping = (cost: number, topping: ToppingType) => {
    if (cash < cost) return;
    if (upgrades.unlockedToppings.includes(topping)) return;
    const nextUnlocked = [...upgrades.unlockedToppings, topping];
    const nextUpgrades = {
      ...upgrades,
      unlockedToppings: nextUnlocked,
    };
    const wasEnabled = isEgyptianPizzaEnabled(upgrades.unlockedToppings);
    const nowEnabled = isEgyptianPizzaEnabled(nextUnlocked);
    const wasMaharajaEnabled = isRuedaMaharajaEnabled(upgrades);
    const nowMaharajaEnabled = isRuedaMaharajaEnabled(nextUpgrades);

    setCash((c) => c - cost);
    setUpgrades(nextUpgrades);

    if (
      day >= 3 &&
      !wasEnabled &&
      nowEnabled &&
      screen !== 'TITLE' &&
      screen !== 'PNN_NEWS' &&
      screen !== 'DAY_SUMMARY'
    ) {
      setDayCustomersQueue((prev) => [...prev, createPizzaEgipciaOrder()]);
    }

    if (
      day >= 4 &&
      !wasMaharajaEnabled &&
      nowMaharajaEnabled &&
      screen !== 'TITLE' &&
      screen !== 'PNN_NEWS' &&
      screen !== 'DAY_SUMMARY'
    ) {
      setDayCustomersQueue((prev) => [...prev, createRuedaMaharajaOrder()]);
    }

    sounds.playChaChing();
  };

  // Get current PNN news item for day
  const currentNews =
    PNN_NEWS_ARCHIVE.find((n) => n.day === day) ||
    PNN_NEWS_ARCHIVE[PNN_NEWS_ARCHIVE.length - 1];

  // Render Patience meter emotion
  const getPatienceEmotion = (patience: number) => {
    if (patience > 60) return 'happy';
    if (patience > 30) return 'neutral';
    if (patience > 10) return 'impatient';
    return 'angry';
  };

  return (
    <div className="flex flex-col w-screen h-screen bg-[#2A2321] text-stone-900 select-none overflow-hidden font-sans">
      {/* 1. Global Game Header HUD (Only shown during active gameplay) */}
      {screen !== 'TITLE' && screen !== 'PNN_NEWS' && (
        <header className="flex items-center justify-between px-4 py-2 bg-[#8C6D52] text-amber-50 border-b-2 border-[#6E533D] shadow-md z-30 shrink-0">
          {/* Left: Day & Time */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-[#6F543E] rounded-lg text-xs font-bold border border-[#9A7A5D]">
              <span className="text-amber-300">DÍA {day}</span>
              <span className="text-stone-300">·</span>
              <span className="flex items-center gap-1 font-mono">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                {formatTime(dayMinutes)}
              </span>
            </div>

            {/* Cash readout */}
            <div className="flex items-center gap-1 px-3 py-1 bg-[#3E653A] text-emerald-100 rounded-lg text-xs font-bold font-mono border border-emerald-600 shadow-2xs">
              <DollarSign className="w-3.5 h-3.5 text-emerald-300" />
              ${cash.toFixed(2)}
            </div>
          </div>

          {/* Center: Pizzeria Navigation Tabs (Counter / Dough / Kitchen / Oven / Cut) */}
          <div className="flex items-center gap-1 bg-[#6F543E] p-1 rounded-xl border border-[#9A7A5D]">
            <button
              onClick={() => setScreen('COUNTER')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'COUNTER'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Mostrador
            </button>
            <button
              onClick={() => setScreen('DOUGH')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'DOUGH'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Masa
            </button>
            <button
              onClick={() => setScreen('MIXING')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'MIXING'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Mezcla
            </button>
            <button
              onClick={() => setScreen('KITCHEN')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'KITCHEN'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Cocina
            </button>
            <button
              onClick={() => setScreen('OVEN')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'OVEN'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Horno
            </button>
            <button
              onClick={() => setScreen('CUTTING')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                screen === 'CUTTING'
                  ? 'bg-amber-100 text-amber-950 shadow-xs'
                  : 'text-amber-100 hover:text-white hover:bg-white/10'
              }`}
            >
              Corte
            </button>
          </div>

          {/* Right: Quick Tools (Recipe Book, Shop, Sound, Music, Home) */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setScreen('TITLE')}
              className="p-1.5 bg-[#6F543E] hover:bg-[#5E4633] text-amber-200 rounded-lg border border-[#9A7A5D] transition-colors cursor-pointer"
              title="Volver a la Portada / Partidas"
            >
              <Home className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowRecipeBook(true)}
              className="p-1.5 bg-[#6F543E] hover:bg-[#5E4633] text-amber-200 rounded-lg border border-[#9A7A5D] transition-colors cursor-pointer"
              title="Libro de Recetas"
            >
              <BookOpen className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowShop(true)}
              className="p-1.5 bg-[#6F543E] hover:bg-[#5E4633] text-amber-200 rounded-lg border border-[#9A7A5D] transition-colors cursor-pointer"
              title="Tienda de Mejoras"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>

            <button
              onClick={handleToggleMusic}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                isMusicOn
                  ? 'bg-amber-500 text-amber-950 border-amber-300'
                  : 'bg-[#6F543E] text-amber-200 border-[#9A7A5D] hover:bg-[#5E4633]'
              }`}
              title="Música Cozy"
            >
              <Music className="w-4 h-4" />
            </button>

            <button
              onClick={handleToggleMute}
              className="p-1.5 bg-[#6F543E] hover:bg-[#5E4633] text-amber-200 rounded-lg border border-[#9A7A5D] transition-colors cursor-pointer"
              title={isMuted ? 'Activar Sonidos' : 'Silenciar'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </header>
      )}

      {/* Octavia Character Speech Bubble Reminder (Accessible in Kitchen, Oven, and Cutting stations) */}
      {currentOrder &&
        screen !== 'TITLE' &&
        screen !== 'PNN_NEWS' &&
        screen !== 'COUNTER' &&
        screen !== 'DOUGH' &&
        screen !== 'MIXING' && (
          <OctaviaReminder
            order={currentOrder}
            customerPatience={customerPatience}
            clarifiedOrder={clarifiedOrder}
            isOpen={orderTicketOpen}
            onToggle={() => setOrderTicketOpen(!orderTicketOpen)}
          />
        )}

      {/* 2. Main Viewport Switcher */}
      <main className="flex-1 relative overflow-hidden flex flex-col">
        {/* VIEW 1: TITLE SCREEN */}
        {screen === 'TITLE' && (
          <div className="relative w-full h-full flex flex-col justify-between p-4 sm:p-8 select-none overflow-hidden">
            {/* User Custom Storefront Background */}
            <img
              src="/assets/aistudio/Papa_s_i_fratelli_Polpo_9e13c323.jpg"
              alt="Papa´s i fratelli Polpo Fachada"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center"
            />

            {/* Subtle vignette for UI readability while preserving neon sign & octopus */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/35 pointer-events-none" />

            {/* Top Brand Tag */}
            <div className="relative z-10 flex items-center justify-between w-full max-w-5xl mx-auto">
              <div className="flex items-center gap-2 px-4 py-2 bg-black/60 backdrop-blur-md rounded-2xl border border-white/15 text-amber-100 shadow-lg">
                <span className="text-xl animate-float">🐙</span>
                <span className="font-display font-bold text-sm tracking-wide">
                  Papa´s i fratelli Polpo
                </span>
              </div>
              <div className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-white/15 text-xs text-amber-200 font-mono shadow-lg">
                <span>Partida {activeSlotId} · Fondos:</span>
                <strong className="text-emerald-400 font-bold">${cash.toFixed(2)}</strong>
              </div>
            </div>

            {/* Bottom / Side Menu Card with 3 Save Slots (Wooden Cutting Board & Parchment) */}
            <WoodParchmentBoard
              variant="vertical"
              className="relative z-10 w-full max-w-lg self-center md:self-start md:ml-6 mt-auto"
              innerClassName="max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 via-amber-500 to-rose-500 border-2 border-[#B38651] flex items-center justify-center text-2xl shadow-md shrink-0">
                  🐙
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-display font-extrabold text-[#3A1E0D] leading-tight">
                    Papa´s <span className="text-cyan-800">i fratelli Polpo</span>
                  </h1>
                  <p className="text-xs text-[#6E4427] font-semibold">
                    Simulador de Pizzería · Partida {activeSlotId} (Día {day})
                  </p>
                </div>
              </div>

              {/* 3 Apartados para Guardar Diferentes Partidas */}
              <div className="my-2">
                <SaveSlotsSelector
                  slots={slots}
                  activeSlotId={activeSlotId}
                  onSelectSlot={handleSelectSlot}
                  onPlaySlot={handlePlaySlot}
                  onResetSlot={handleResetSlot}
                />
              </div>

              {/* Actions Button Cluster */}
              <div className="w-full flex flex-col gap-2 mt-1">
                <button
                  onClick={startDayFromTitle}
                  className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm sm:text-base rounded-2xl shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  {day === 1 ? `¡Comenzar Día 1 en Partida ${activeSlotId}!` : `¡Continuar Partida ${activeSlotId} (Día ${day})!`}
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setShowRecipeBook(true)}
                    className="flex items-center justify-center gap-1.5 py-2 bg-[#FFFBF0] hover:bg-white border border-[#C69B61] text-[#3A1E0D] font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-[#8C4D1E]" />
                    Libro de Recetas
                  </button>

                  <button
                    onClick={() => setShowShop(true)}
                    className="flex items-center justify-center gap-1.5 py-2 bg-[#FFFBF0] hover:bg-white border border-[#C69B61] text-[#3A1E0D] font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-[#8C4D1E]" />
                    Tienda de Mejoras
                  </button>
                </div>
              </div>

              {/* Audio & Settings strip */}
              <div className="mt-3 pt-2.5 border-t border-[#C8A16B]/60 w-full flex items-center justify-between text-xs text-[#6E4427]">
                <span className="font-mono text-emerald-800 font-bold text-[11px]">Ranura {activeSlotId} Activa</span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleToggleMusic}
                    className="hover:text-[#3A1E0D] transition-colors cursor-pointer flex items-center gap-1 font-semibold text-[11px]"
                  >
                    <Music className="w-3 h-3" />
                    {isMusicOn ? 'Música On' : 'Música'}
                  </button>
                  <button
                    onClick={handleToggleMute}
                    className="hover:text-[#3A1E0D] transition-colors cursor-pointer flex items-center gap-1 font-semibold text-[11px]"
                  >
                    {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                    {isMuted ? 'Mudo' : 'Audio'}
                  </button>
                </div>
              </div>
            </WoodParchmentBoard>
          </div>
        )}

        {/* VIEW 2: PNN NEWSROOM BROADCAST */}
        {screen === 'PNN_NEWS' && (
          <PnnBroadcast
            news={currentNews}
            dayNumber={day}
            onStartDay={startDayWork}
          />
        )}

        {/* VIEW 3: COUNTER STATION (Mostrador de Clientes con Fondo Personalizado) */}
        {screen === 'COUNTER' && currentOrder && (
          <div className="relative w-full h-full flex flex-col items-center justify-between p-4 select-none overflow-hidden">
            {/* Custom Kitchen Background with service window to street */}
            <img
              src="/assets/aistudio/KICHEND_e3d7c80b.jpg"
              alt="Cocina y Ventana de Clientes"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover"
            />
            {/* Soft vignette/scrim for top/bottom legibility */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/45 pointer-events-none" />

            {/* Top Bar / Sign */}
            <div className="relative z-10 w-full max-w-3xl flex items-center justify-between px-6 pt-2">
              <div className="px-4 py-1.5 bg-[#8C6D52]/90 backdrop-blur-xs text-amber-100 rounded-xl text-xs font-bold border border-[#6E533D] shadow-md">
                Papa´s i fratelli Polpo · Mostrador
              </div>
              <div className="px-3.5 py-1.5 bg-black/60 backdrop-blur-xs text-amber-200 rounded-xl text-xs font-semibold border border-white/10 shadow-md flex items-center gap-1.5">
                <span>Precio del pedido:</span>
                <span className="font-mono font-bold text-emerald-400">${currentOrder.basePrice.toFixed(2)}</span>
              </div>
            </div>

            {/* Restoration banner when returning automatically to normal gramera after serving an Egyptian visitor */}
            {restoredFromEgyptian &&
              currentOrder.customerType !== 'faraon' &&
              currentOrder.customerType !== 'momia' && (
                <div className="relative z-10 w-full max-w-2xl mt-2 px-4 py-2 rounded-2xl bg-sky-100/95 border-2 border-sky-400 text-sky-950 text-xs sm:text-sm font-black text-center shadow-lg">
                  🧑‍🍳 ¡Pedido egipcio entregado! La cocina volvió automáticamente a su gramera normal para el siguiente cliente.
                </div>
              )}

            {/* Customer Centerpiece in Window & Dialogue Box */}
            <div className="relative z-10 flex flex-col items-center justify-center my-auto w-full max-w-lg">
              <div className="relative filter drop-shadow-xl">
                <CustomerAvatar
                  config={currentOrder.avatar}
                  emotion={getPatienceEmotion(customerPatience)}
                  size={200}
                />
              </div>

              {/* Dialogue Box (Wooden Rolling-Pin Cutting Board & Curled Parchment) */}
              <WoodParchmentBoard
                variant="horizontal"
                pointerPosition="top"
                className="w-full mt-2"
                innerClassName="text-[#3A1E0D]"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-display font-bold text-base text-amber-950">
                      {currentOrder.customerName}
                    </span>
                    {currentOrder.customerType && (
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                          currentOrder.customerType === 'faraon'
                            ? 'bg-amber-200 text-amber-950 border border-amber-400'
                            : currentOrder.customerType === 'momia'
                            ? 'bg-stone-200 text-stone-900 border border-stone-400'
                            : currentOrder.customerType === 'sabio_india'
                            ? 'bg-purple-200 text-purple-950 border border-purple-400'
                            : 'bg-stone-200/80 text-stone-700'
                        }`}
                      >
                        {currentOrder.customerType === 'cavernicola'
                          ? '🦴 Cavernícola'
                          : currentOrder.customerType === 'faraon'
                          ? '👑 Faraón (Medida Corporal)'
                          : currentOrder.customerType === 'momia'
                          ? '🏺 Momia (Medida Corporal)'
                          : currentOrder.customerType === 'sabio_india'
                          ? '🧘🏽‍♂️ Sabio de la India (El Cero)'
                          : '🏙️ Moderno'}
                      </span>
                    )}
                  </div>
                  {/* Patience Indicator */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-bold text-stone-500">Paciencia:</span>
                    <span
                      className={`text-xs font-bold font-mono ${
                        customerPatience > 40
                          ? 'text-emerald-700'
                          : customerPatience > 20
                          ? 'text-amber-700'
                          : 'text-rose-600 animate-pulse'
                      }`}
                    >
                      {Math.round((customerPatience / currentOrder.patienceTotal) * 100)}%
                    </span>
                  </div>
                </div>

                {/* Size, Dough & Geometric Shape Pill */}
                {currentOrder.recipe.size && currentOrder.recipe.shape && (
                  <div className="mb-2 flex flex-wrap items-center gap-1.5">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-amber-100 border border-amber-300 text-xs font-extrabold text-amber-950">
                      <span>{ICONOS_FORMA[currentOrder.recipe.shape]}</span>
                      <span>
                        {currentOrder.customerType === 'faraon' ||
                        currentOrder.customerType === 'momia'
                          ? `${
                              currentOrder.menuOrderTitle === 'Pizza Egipcia'
                                ? '🏺 Pizza Egipcia · '
                                : ''
                            }Medida: ${currentOrder.iconoEgipcio || ''} ${
                              currentOrder.medidaEgipcia ||
                              CATALOGO_TAMANOS[currentOrder.recipe.size].medidaEgipcia
                            } · Molde ${currentOrder.recipe.shape}`
                          : `${currentOrder.menuOrderTitle ? `${currentOrder.menuOrderTitle} · ` : 'Pizza '}${currentOrder.recipe.size} (${currentOrder.recipe.shape})`}
                      </span>
                    </div>
                    {currentOrder.recipe.dough === 'naan_verde' && (
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-100 border border-emerald-400 text-xs font-extrabold text-emerald-950">
                        <span>🌿 Harina Naan Verde</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Customer line */}
                <p className="text-sm sm:text-base font-medium leading-relaxed text-stone-800 min-h-[46px] whitespace-pre-wrap">
                  "{clarifiedOrder ? currentOrder.clarification : currentOrder.dialogue}"
                </p>

                {/* Sabio de la India: Cartilla Visual Clara */}
                {currentOrder.customerType === 'sabio_india' && currentOrder.sabioZeroChallenge && (
                  <div className="mt-3 p-3 rounded-2xl bg-purple-50 border-2 border-purple-300 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] font-extrabold uppercase tracking-wider text-purple-950">
                        🧘🏽‍♂️ Ingredientes de la Lista del Sabio
                      </span>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-purple-200 text-purple-950">
                        0 = Ninguno · Otros = {currentOrder.sabioZeroChallenge.cantidadPorCadaUno} c/u
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {currentOrder.sabioZeroChallenge.poolToppings.map((t) => {
                        const isZero = currentOrder.sabioZeroChallenge?.descartados.includes(t);
                        return (
                          <div
                            key={`counter-sabio-${t}`}
                            className={`flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold ${
                              clarifiedOrder
                                ? isZero
                                  ? 'bg-rose-50 border-rose-300 text-rose-900'
                                  : 'bg-emerald-50 border-emerald-400 text-emerald-950'
                                : 'bg-white border-purple-200 text-stone-800'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 min-w-0">
                              <svg viewBox="-18 -18 36 36" className="w-5 h-5 shrink-0">
                                <ToppingSprite type={t} />
                              </svg>
                              <span className="capitalize truncate">{TOPPING_NAMES[t] || t}</span>
                            </div>
                            {clarifiedOrder && (
                              <span
                                className={`font-mono text-[11px] px-1.5 py-0.5 rounded ${
                                  isZero
                                    ? 'bg-rose-200 text-rose-950'
                                    : 'bg-emerald-200 text-emerald-950'
                                }`}
                              >
                                {isZero
                                  ? '0'
                                  : `${currentOrder.sabioZeroChallenge?.cantidadPorCadaUno}`}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Customer Action Buttons */}
                <div className="mt-4 pt-3 border-t border-[#C8A16B]/60 flex items-center justify-between gap-2">
                  <button
                    onClick={handleAskClarification}
                    disabled={clarifiedOrder}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-[#5D290D] bg-[#EFE0BA] hover:bg-[#E7D09B] disabled:opacity-50 rounded-xl border border-[#B88B52] transition-colors cursor-pointer"
                    title="Pide al cliente que explique su pedido con palabras claras"
                  >
                    <HelpCircle className="w-4 h-4 text-[#8C4D1E]" />
                    {clarifiedOrder ? 'Aclarado' : '¿Qué? (Aclarar)'}
                  </button>

                  <button
                    onClick={() => {
                      sounds.playDoughSlap();
                      setScreen('DOUGH');
                    }}
                    className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-b from-[#74B82E] to-[#4E8917] hover:from-[#82C938] hover:to-[#5A9C1D] border-2 border-[#365314] text-white font-display font-bold text-sm rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
                  >
                    <ChefHat className="w-4 h-4" />
                    ¡Preparar Masa!
                  </button>
                </div>
              </WoodParchmentBoard>
            </div>

            {/* Bottom Status strip */}
            <div className="relative z-10 w-full max-w-3xl flex items-center justify-between px-6 py-1.5 bg-black/50 backdrop-blur-xs text-amber-100 rounded-full border border-white/10 text-xs font-semibold shadow-md">
              <span className="flex items-center gap-1.5">
                <span>🔔 Mostrador de atención</span>
                <span className="text-stone-400">·</span>
                <span>Cliente #{dayFinancials.pizzasCompleted + dayFinancials.pizzasFailed + 1} de hoy</span>
              </span>
              <span className="text-amber-200 font-mono">Día {day}</span>
            </div>
          </div>
        )}

        {/* VIEW 3.5: DOUGH WEIGHING STATION */}
        {screen === 'DOUGH' && (
          <DoughStation
            pizza={pizza}
            order={currentOrder}
            upgrades={upgrades}
            restoredFromEgyptian={restoredFromEgyptian}
            onUpdatePizza={setPizza}
            onMoveToMixing={() => setScreen('MIXING')}
          />
        )}

        {/* VIEW 3.75: MIXING, SPOON STIRRING & ROLLING PIN STATION */}
        {screen === 'MIXING' && (
          <MixingStation
            pizza={pizza}
            order={currentOrder}
            onUpdatePizza={setPizza}
            onBackToDough={() => setScreen('DOUGH')}
            onMoveToKitchen={() => setScreen('KITCHEN')}
          />
        )}

        {/* VIEW 4: KITCHEN PREP STATION */}
        {screen === 'KITCHEN' && (
          <KitchenStation
            pizza={pizza}
            order={currentOrder}
            upgrades={upgrades}
            onUpdatePizza={setPizza}
            onDeductMoney={deductCost}
            onMoveToOven={() => {
              sounds.playOvenSizzle();
              setScreen('OVEN');
            }}
            onDiscardPizza={handleDiscardPizza}
          />
        )}

        {/* VIEW 5: OVEN STATION */}
        {screen === 'OVEN' && (
          <OvenStation
            pizza={pizza}
            upgrades={upgrades}
            onUpdatePizza={setPizza}
            onMoveToCut={() => {
              sounds.playPizzaCut();
              setScreen('CUTTING');
            }}
            onBackToKitchen={() => setScreen('KITCHEN')}
          />
        )}

        {/* VIEW 6: CUTTING BOARD STATION */}
        {screen === 'CUTTING' && (
          <CuttingStation
            pizza={pizza}
            order={currentOrder}
            upgrades={upgrades}
            onUpdatePizza={setPizza}
            onServePizza={handleServePizza}
            onBackToOven={() => setScreen('OVEN')}
          />
        )}

        {/* VIEW 7: CUSTOMER REACTION / RECEIPT MODAL */}
        {screen === 'CUSTOMER_REACTION' && lastEvaluation && currentOrder && (
          <CustomerReactionModal
            evaluation={lastEvaluation}
            customerName={currentOrder.customerName}
            avatar={currentOrder.avatar}
            onNextCustomer={advanceQueue}
          />
        )}

        {/* VIEW 8: END OF DAY FINANCIAL SUMMARY MODAL */}
        {screen === 'DAY_SUMMARY' && (
          <DaySummaryModal
            dayNumber={day}
            financials={dayFinancials}
            totalCash={cash}
            onOpenShop={() => setShowShop(true)}
            onNextDay={() => {
              setDay((d) => d + 1);
              setScreen('PNN_NEWS');
            }}
          />
        )}
      </main>

      {/* Upgrades Shop Modal */}
      {showShop && (
        <UpgradesShop
          cash={cash}
          day={day}
          upgrades={upgrades}
          onBuyUpgrade={handleBuyUpgrade}
          onUnlockTopping={handleUnlockTopping}
          onClose={() => setShowShop(false)}
        />
      )}

      {/* Recipe Book Guidebook Modal */}
      {showRecipeBook && (
        <RecipeBookModal
          day={day}
          unlockedToppings={upgrades.unlockedToppings}
          naanVerdeFlour={upgrades.naanVerdeFlour}
          onClose={() => setShowRecipeBook(false)}
        />
      )}
    </div>
  );
}
