import {
  CustomerAvatarConfig,
  CustomerOrder,
  GameUpgrades,
  PizzaShape,
  PizzaSize,
  ToppingType,
} from '../types/pizza';
import { CATALOGO_TAMANOS } from '../utils/pizzaGeometry';

export const TOPPING_COSTS: Record<ToppingType, number> = {
  pepperoni: 0.15,
  mushroom: 0.12,
  olive: 0.12,
  carne_mamut: 0.22,
  pina: 0.14,
  queso_extra: 0.16,
  puerro_cebolla: 0.16,
  higos_datiles: 0.18,
  pato_pescado: 0.24,
  miel_sesamo: 0.14,
  queso_paneer: 0.18,
  pollo_tandoori: 0.22,
  cilantro_menta: 0.12,
  basil: 0.10,
  onion: 0.10,
  sausage: 0.18,
  bell_pepper: 0.12,
};

export const TOPPING_NAMES: Record<ToppingType, string> = {
  pepperoni: 'pepperoni',
  mushroom: 'champiñones',
  olive: 'aceitunas',
  carne_mamut: 'carne de mamut',
  pina: 'piña',
  queso_extra: 'queso extra',
  puerro_cebolla: 'puerros y cebollas moradas caramelizadas',
  higos_datiles: 'higos frescos y dátiles',
  pato_pescado: 'pato asado y pescado ahumado del Nilo',
  miel_sesamo: 'miel pura y sésamo tostado',
  queso_paneer: 'queso paneer',
  pollo_tandoori: 'pollo tandoori y garbanzos especiados',
  cilantro_menta: 'hojas de cilantro y menta',
  basil: 'albahaca',
  onion: 'cebolla',
  sausage: 'salchicha italiana',
  bell_pepper: 'pimiento',
};

export const EGYPTIAN_PIZZA_TOPPINGS: ToppingType[] = [
  'puerro_cebolla',
  'higos_datiles',
  'pato_pescado',
  'miel_sesamo',
];

export function isEgyptianPizzaEnabled(unlockedToppings: ToppingType[]): boolean {
  return EGYPTIAN_PIZZA_TOPPINGS.every((t) => unlockedToppings.includes(t));
}

export const RUEDA_MAHARAJA_TOPPINGS: ToppingType[] = [
  'queso_paneer',
  'pollo_tandoori',
  'cilantro_menta',
];

export function isRuedaMaharajaEnabled(upgrades: GameUpgrades): boolean {
  return (
    upgrades.naanVerdeFlour &&
    RUEDA_MAHARAJA_TOPPINGS.every((t) => upgrades.unlockedToppings.includes(t))
  );
}

export const BASE_COSTS = {
  dough: 1.00,
  sauce: 0.50,
  cheese: 0.75,
};

// 1. MENÚ DE TOPPINGS DISPONIBLES
export const menuToppings: { id: string; type: ToppingType; nombre: string }[] = [
  { id: 'pepperoni', type: 'pepperoni', nombre: 'pepperoni' },
  { id: 'aceitunas', type: 'olive', nombre: 'aceitunas' },
  { id: 'carne_mamut', type: 'carne_mamut', nombre: 'carne de mamut' },
  { id: 'champinones', type: 'mushroom', nombre: 'champiñones' },
  { id: 'pina', type: 'pina', nombre: 'piña' },
  { id: 'queso_extra', type: 'queso_extra', nombre: 'queso extra' },
];

export type TipoCliente = 'cavernicola' | 'moderno';

export interface MamutToppingItem {
  id: string;
  type: ToppingType;
  nombre: string;
  cantidadReal: number;
  simbolo: string | number;
}

export interface GeneratedClienteDialogue {
  cliente: TipoCliente;
  porcionesRequeridas: number;
  toppingsRequeridos: MamutToppingItem[];
  dialogoEnPantalla: string;
}

// 2. GENERADOR DE DIÁLOGO DEL CLIENTE (Porciones + Toppings variados; carne de mamut obligatoria cuando está desbloqueada)
export function generarDialogoCliente(
  tipoCliente: TipoCliente,
  unlockedToppings?: ToppingType[]
): GeneratedClienteDialogue {
  // Porciones posibles para cortar la pizza (2, 4, 6 u 8 rebanadas)
  const opcionesPorciones = [2, 4, 6, 8];
  const cantidadPorciones =
    opcionesPorciones[Math.floor(Math.random() * opcionesPorciones.length)];

  const availablePool = unlockedToppings
    ? menuToppings.filter((t) => unlockedToppings.includes(t.type))
    : menuToppings;
  const safePool = availablePool.length > 0 ? availablePool : menuToppings.slice(0, 3);

  const carneMamut = safePool.find((t) => t.id === 'carne_mamut');
  const otrosToppings = safePool
    .filter((t) => t.id !== 'carne_mamut')
    .sort(() => 0.5 - Math.random());

  const extrasCount = Math.min(otrosToppings.length, Math.random() < 0.35 ? 1 : 2);
  const elegidos = carneMamut
    ? [carneMamut, ...otrosToppings.slice(0, extrasCount)].sort(() => 0.5 - Math.random())
    : safePool
        .slice()
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.min(safePool.length, Math.random() < 0.35 ? 2 : 3));

  const seleccionToppings: MamutToppingItem[] = elegidos.map((topping) => {
    const cantidad = Math.floor(Math.random() * 6) + 1; // Entre 1 y 6 unidades
    return {
      id: topping.id,
      type: topping.type,
      nombre: topping.nombre,
      cantidadReal: cantidad,
      simbolo: tipoCliente === 'cavernicola' ? Array(cantidad).fill('|').join(' ') : cantidad,
    };
  });

  // Construcción de la frase que dice el cliente en el mostrador
  const textoPorciones =
    tipoCliente === 'cavernicola'
      ? Array(cantidadPorciones).fill('|').join(' ')
      : cantidadPorciones;

  const listaToppingsTexto = seleccionToppings
    .map((t) => `${t.simbolo} de ${t.nombre}`)
    .join(', ');

  const fraseFinal =
    tipoCliente === 'cavernicola'
      ? `¡Quiero una Pizza de Mamut cortada en [ ${textoPorciones} ] porciones, con ${listaToppingsTexto}!`
      : `Hola, me das una Pizza de Mamut de ${textoPorciones} porciones, con ${listaToppingsTexto}.`;

  return {
    cliente: tipoCliente,
    porcionesRequeridas: cantidadPorciones,
    toppingsRequeridos: seleccionToppings,
    dialogoEnPantalla: fraseFinal,
  };
}

const CAVERNICOLA_PROFILES: { name: string; avatar: CustomerAvatarConfig }[] = [
  {
    name: 'Gorg el Cavernícola',
    avatar: {
      skinColor: '#D9A077',
      hairStyle: 'caveman',
      hairColor: '#3B2314',
      shirtColor: '#B45309',
      accessory: 'bone',
      baseExpression: 'happy',
    },
  },
  {
    name: 'Uga de la Cueva',
    avatar: {
      skinColor: '#E2B18A',
      hairStyle: 'caveman',
      hairColor: '#1F140E',
      shirtColor: '#9A3412',
      accessory: 'bone',
      baseExpression: 'curious',
    },
  },
  {
    name: 'Trog el Cazador',
    avatar: {
      skinColor: '#C68B59',
      hairStyle: 'caveman',
      hairColor: '#29170B',
      shirtColor: '#78350F',
      accessory: 'bone',
      baseExpression: 'neutral',
    },
  },
];

const MODERNO_PROFILES: { name: string; avatar: CustomerAvatarConfig }[] = [
  {
    name: 'Valentina Moderna',
    avatar: {
      skinColor: '#F5D0A9',
      hairStyle: 'bun',
      hairColor: '#7C2D12',
      shirtColor: '#0EA5E9',
      accessory: 'glasses',
      baseExpression: 'happy',
    },
  },
  {
    name: 'Lucas Contemporáneo',
    avatar: {
      skinColor: '#ECC9A8',
      hairStyle: 'beanie',
      hairColor: '#1E293B',
      shirtColor: '#4F46E5',
      accessory: 'earring',
      baseExpression: 'happy',
    },
  },
  {
    name: 'Camila Urbana',
    avatar: {
      skinColor: '#FBE8D3',
      hairStyle: 'curly',
      hairColor: '#92400E',
      shirtColor: '#059669',
      accessory: 'glasses',
      baseExpression: 'curious',
    },
  },
];

export function createMamutCustomerOrder(
  tipoCliente: TipoCliente,
  unlockedToppings?: ToppingType[]
): CustomerOrder {
  const generated = generarDialogoCliente(tipoCliente, unlockedToppings);
  const profiles = tipoCliente === 'cavernicola' ? CAVERNICOLA_PROFILES : MODERNO_PROFILES;
  const chosen = profiles[Math.floor(Math.random() * profiles.length)];

  const toppingsClarificacion = generated.toppingsRequeridos
    .map((t) => `${t.cantidadReal} de ${t.nombre}`)
    .join(', ');

  const clarification =
    tipoCliente === 'cavernicola'
      ? `¡Ugh! Masa con salsa y queso, ${toppingsClarificacion}, horneado normal y cortado en ${generated.porcionesRequeridas} porciones.`
      : `Masa con salsa de tomate y queso mozzarella, exactamente ${toppingsClarificacion}, horneada 1 vez y cortada en ${generated.porcionesRequeridas} porciones.`;

  return {
    id: `mamut-${tipoCliente}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName: chosen.name,
    customerType: tipoCliente,
    menuOrderTitle: 'Pizza de Mamut',
    avatar: chosen.avatar,
    dialogue: generated.dialogoEnPantalla,
    clarification,
    toppingsDetail: generated.toppingsRequeridos,
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: generated.toppingsRequeridos.map((t) => ({
        type: t.type,
        placement: 'whole',
        exactCount: t.cantidadReal,
      })),
      bakeLevel: 1,
      cuts: generated.porcionesRequeridas,
    },
    basePrice: 14.0,
    patienceTotal: tipoCliente === 'cavernicola' ? 105 : 95,
    tipMultiplier: tipoCliente === 'cavernicola' ? 1.25 : 1.15,
  };
}

const EGYPTIAN_PROFILES: Record<
  'faraon' | 'momia',
  { name: string; avatar: CustomerAvatarConfig }[]
> = {
  faraon: [
    {
      name: 'Faraón Ramsés',
      avatar: {
        skinColor: '#D99B66',
        hairStyle: 'pharaoh',
        hairColor: '#1E293B',
        shirtColor: '#FEF3C7',
        accessory: 'uraeus',
        baseExpression: 'smug',
      },
    },
    {
      name: 'Faraón Tutankamón',
      avatar: {
        skinColor: '#E0AC7E',
        hairStyle: 'pharaoh',
        hairColor: '#1E293B',
        shirtColor: '#FDE68A',
        accessory: 'uraeus',
        baseExpression: 'happy',
      },
    },
  ],
  momia: [
    {
      name: 'Momia Imhotep',
      avatar: {
        skinColor: '#D7CCB8',
        hairStyle: 'mummy',
        hairColor: '#EFE7D6',
        shirtColor: '#C2B295',
        accessory: 'scarab',
        baseExpression: 'curious',
      },
    },
    {
      name: 'Momia Nefertari',
      avatar: {
        skinColor: '#E0D6C3',
        hairStyle: 'mummy',
        hairColor: '#F3ECE0',
        shirtColor: '#B8A688',
        accessory: 'scarab',
        baseExpression: 'happy',
      },
    },
  ],
};

export function createEgyptianCustomerOrder(
  tipoVisitante: 'faraon' | 'momia',
  unlockedToppings?: ToppingType[]
): CustomerOrder {
  const tamanos: PizzaSize[] = ['Pequeña', 'Mediana', 'Familiar'];
  const formas: PizzaShape[] = ['Circular', 'Cuadrado', 'Estrella', 'Corazón'];
  const opcionesPorciones = [2, 4, 6, 8];

  const chosenSize = tamanos[Math.floor(Math.random() * tamanos.length)];
  const chosenShape = formas[Math.floor(Math.random() * formas.length)];
  const chosenCuts = opcionesPorciones[Math.floor(Math.random() * opcionesPorciones.length)];
  const info = CATALOGO_TAMANOS[chosenSize];

  const safeUnlocked: ToppingType[] =
    unlockedToppings && unlockedToppings.length > 0
      ? unlockedToppings
      : ['pepperoni', 'mushroom', 'olive'];

  const shuffled = [...safeUnlocked].sort(() => 0.5 - Math.random());
  const toppingCount = Math.min(shuffled.length, Math.random() < 0.45 ? 1 : 2);
  const pickedToppings = shuffled.slice(0, toppingCount);

  const toppingsListText = pickedToppings.map((t) => TOPPING_NAMES[t] || t).join(' y ');
  const profilePool = EGYPTIAN_PROFILES[tipoVisitante];
  const chosen = profilePool[Math.floor(Math.random() * profilePool.length)];

  const dialogue =
    tipoVisitante === 'faraon'
      ? `¡Por Ra! Haz mi pizza de ${chosenShape.toLowerCase()} del largo de ${info.medidaEgipcia}, con ${toppingsListText} y cortada en ${chosenCuts} porciones.`
      : `Mmm... quiero una pizza de ${chosenShape.toLowerCase()} que mida ${info.medidaEgipcia}, con ${toppingsListText}, cortada en ${chosenCuts} porciones.`;

  const clarification = `Medida del cuerpo: ${info.iconoEgipcio} ${info.medidaEgipcia} (equivale a ${chosenSize} · ${info.toquesSilueta} puñados de harina sobre la silueta), molde ${chosenShape}, salsa roja, queso mozzarella, ${toppingsListText}, horneada 1 vez y cortada en ${chosenCuts} porciones.`;

  return {
    id: `egypt-${tipoVisitante}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName: chosen.name,
    customerType: tipoVisitante,
    menuOrderTitle: `Medida Egipcia · ${info.medidaEgipcia}`,
    medidaEgipcia: info.medidaEgipcia,
    iconoEgipcio: info.iconoEgipcio,
    avatar: chosen.avatar,
    dialogue,
    clarification,
    recipe: {
      size: chosenSize,
      shape: chosenShape,
      sauce: 'whole',
      cheese: 'whole',
      toppings: pickedToppings.map((type) => ({
        type,
        placement: 'whole',
        minCount: 10,
        recommendedCount: 14,
      })),
      bakeLevel: 1,
      cuts: chosenCuts,
    },
    basePrice: info.precio,
    patienceTotal: 110,
    tipMultiplier: tipoVisitante === 'faraon' ? 1.35 : 1.25,
  };
}

export function createPizzaEgipciaOrder(): CustomerOrder {
  const tamanos: PizzaSize[] = ['Pequeña', 'Mediana', 'Familiar'];
  const formas: PizzaShape[] = ['Circular', 'Cuadrado', 'Estrella', 'Corazón'];
  const opcionesPorciones = [4, 6, 8];

  const chosenSize = tamanos[Math.floor(Math.random() * tamanos.length)];
  const chosenShape = formas[Math.floor(Math.random() * formas.length)];
  const chosenCuts = opcionesPorciones[Math.floor(Math.random() * opcionesPorciones.length)];
  const info = CATALOGO_TAMANOS[chosenSize];

  type CharacterKind = 'classic' | 'moderno' | 'cavernicola' | 'faraon' | 'momia';
  const kinds: CharacterKind[] = ['classic', 'moderno', 'cavernicola', 'faraon', 'momia'];
  const pickedKind = kinds[Math.floor(Math.random() * kinds.length)];

  let customerName = 'Mateo el Hambriento';
  let avatar: CustomerAvatarConfig = CUSTOMER_POOL[0].avatar;
  let customerType: CustomerOrder['customerType'] = 'moderno';
  let dialogue = '';

  if (pickedKind === 'faraon') {
    const chosen =
      EGYPTIAN_PROFILES.faraon[Math.floor(Math.random() * EGYPTIAN_PROFILES.faraon.length)];
    customerName = chosen.name;
    avatar = chosen.avatar;
    customerType = 'faraon';
    dialogue = `¡Gloria al Nilo! Quiero nuestra Pizza Egipcia de ${chosenShape.toLowerCase()} medida a ${info.medidaEgipcia}, con puerros y cebollas moradas caramelizadas, higos o dátiles, pato o pescado ahumado del Nilo y su toque final de miel pura con sésamo en los bordes. ¡Corta en ${chosenCuts}!`;
  } else if (pickedKind === 'momia') {
    const chosen =
      EGYPTIAN_PROFILES.momia[Math.floor(Math.random() * EGYPTIAN_PROFILES.momia.length)];
    customerName = chosen.name;
    avatar = chosen.avatar;
    customerType = 'momia';
    dialogue = `Mmm... anhelo el sabor de mi tierra: una Pizza Egipcia de ${chosenShape.toLowerCase()} de ${info.medidaEgipcia}, con puerros y cebollas moradas caramelizadas, trozos de higos o dátiles, pato o pescado del Nilo y el hilo de miel con sésamo tostado, en ${chosenCuts} porciones.`;
  } else if (pickedKind === 'cavernicola') {
    const chosen =
      CAVERNICOLA_PROFILES[Math.floor(Math.random() * CAVERNICOLA_PROFILES.length)];
    customerName = chosen.name;
    avatar = chosen.avatar;
    customerType = 'cavernicola';
    const cutsTally = Array(chosenCuts).fill('|').join(' ');
    dialogue = `¡Ugh! Yo probar Pizza Egipcia nueva en [ ${cutsTally} ] porciones: puerros con cebollas moradas, higos o dátiles, pato o pescado del Nilo y miel dulce con sésamo en los bordes.`;
  } else if (pickedKind === 'moderno') {
    const chosen = MODERNO_PROFILES[Math.floor(Math.random() * MODERNO_PROFILES.length)];
    customerName = chosen.name;
    avatar = chosen.avatar;
    customerType = 'moderno';
    dialogue = `¡Escuché que ya tienen la Pizza Egipcia! Dame una en ${chosenCuts} porciones con puerros y cebollas moradas caramelizadas, higos y dátiles, pato asado o pescado del Nilo, y su toque final de miel pura y sésamo tostado en los bordes.`;
  } else {
    const classicCandidates = CUSTOMER_POOL.filter(
      (c) => c.id !== 'cust-3' && c.id !== 'cust-7'
    );
    const chosen =
      classicCandidates[Math.floor(Math.random() * classicCandidates.length)];
    customerName = chosen.customerName;
    avatar = chosen.avatar;
    customerType = 'moderno';
    dialogue = `¡Hola! Me muero por probar la nueva Pizza Egipcia: puerros y cebollas moradas caramelizadas, higos o dátiles, pato o pescado ahumado del Nilo, y ese hilo de miel pura con sésamo tostado. Cortada en ${chosenCuts}.`;
  }

  const isEgyptianBodyCustomer = customerType === 'faraon' || customerType === 'momia';
  const clarification = `${
    isEgyptianBodyCustomer
      ? `Medida del cuerpo: ${info.iconoEgipcio} ${info.medidaEgipcia} (${chosenSize} · ${info.toquesSilueta} puñados), molde ${chosenShape}. `
      : ''
  }Receta Pizza Egipcia: Salsa roja + Mozzarella + Puerros y cebollas caramelizadas + Higos y dátiles + Pato/Pescado del Nilo + Toque final de Miel pura y Sésamo tostado. Horneado 1 pasada y cortada en ${chosenCuts} porciones.`;

  return {
    id: `pizza-egipcia-${pickedKind}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName,
    customerType,
    menuOrderTitle: 'Pizza Egipcia',
    medidaEgipcia: isEgyptianBodyCustomer ? info.medidaEgipcia : undefined,
    iconoEgipcio: isEgyptianBodyCustomer ? info.iconoEgipcio : undefined,
    avatar,
    dialogue,
    clarification,
    recipe: {
      size: chosenSize,
      shape: chosenShape,
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'puerro_cebolla', placement: 'whole', minCount: 5, recommendedCount: 8 },
        { type: 'higos_datiles', placement: 'whole', minCount: 5, recommendedCount: 8 },
        { type: 'pato_pescado', placement: 'whole', minCount: 5, recommendedCount: 8 },
        { type: 'miel_sesamo', placement: 'whole', minCount: 4, recommendedCount: 7 },
      ],
      bakeLevel: 1,
      cuts: chosenCuts,
    },
    basePrice: info.precio + 4.5,
    patienceTotal: 115,
    tipMultiplier: 1.35,
  };
}

const TOPPING_PLURALS: Record<ToppingType, string> = {
  pepperoni: 'pepperonis',
  mushroom: 'champiñones',
  olive: 'aceitunas',
  carne_mamut: 'carnes de mamut',
  pina: 'piñas',
  queso_extra: 'quesos extra',
  puerro_cebolla: 'puerros y cebollas',
  higos_datiles: 'higos y dátiles',
  pato_pescado: 'tiras de pato/pescado',
  miel_sesamo: 'hilos de miel y sésamo',
  queso_paneer: 'cubos de queso paneer',
  pollo_tandoori: 'pollo tandoori y garbanzos',
  cilantro_menta: 'hojas de cilantro y menta',
  basil: 'hojas de albahaca',
  onion: 'cebollas',
  sausage: 'salchichas',
  bell_pepper: 'pimientos',
};

const SABIO_INDIA_PROFILES: { name: string; avatar: CustomerAvatarConfig }[] = [
  {
    name: 'Sabio Aryabhata de la India',
    avatar: {
      skinColor: '#C68B59',
      hairStyle: 'sage',
      hairColor: '#CBD5E1',
      shirtColor: '#6D28D9',
      accessory: 'bindi',
      baseExpression: 'happy',
    },
  },
  {
    name: 'Sabio Brahmagupta de la India',
    avatar: {
      skinColor: '#B87B4B',
      hairStyle: 'sage',
      hairColor: '#E2E8F0',
      shirtColor: '#7C3AED',
      accessory: 'bindi',
      baseExpression: 'curious',
    },
  },
];

// =========================================================================
// GENERADOR 100% ALEATORIO PARA EL SABIO DE LA INDIA (DÍA 4+)
// Elige al azar los ingredientes descartados con 0 y la cantidad (2, 3 o 4)
// de los ingredientes de su lista que NO nombró.
// =========================================================================
export function createSabioIndiaOrder(unlockedToppings?: ToppingType[]): CustomerOrder {
  const tamanos: PizzaSize[] = ['Pequeña', 'Mediana', 'Familiar'];
  const formas: PizzaShape[] = ['Circular', 'Cuadrado', 'Estrella', 'Corazón'];
  const opcionesPorciones = [4, 6, 8];

  const chosenSize = tamanos[Math.floor(Math.random() * tamanos.length)];
  const chosenShape = formas[Math.floor(Math.random() * formas.length)];
  const chosenCuts = opcionesPorciones[Math.floor(Math.random() * opcionesPorciones.length)];
  const info = CATALOGO_TAMANOS[chosenSize];

  const defaultCandidates: ToppingType[] = ['pepperoni', 'mushroom', 'olive'];
  const rawUnlocked =
    unlockedToppings && unlockedToppings.length >= 3
      ? unlockedToppings.filter((t) => t !== 'miel_sesamo')
      : defaultCandidates;

  // Baraja Fisher-Yates real sobre los ingredientes desbloqueados y toma hasta 4 para el reto del Sabio
  const candidatePool = [...rawUnlocked];
  for (let i = candidatePool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [candidatePool[i], candidatePool[j]] = [candidatePool[j], candidatePool[i]];
  }
  const poolToppings = candidatePool.slice(0, Math.min(4, candidatePool.length));

  // Segunda baraja Fisher-Yates para decidir cuáles llevan 0 y cuáles SÍ se ponen
  const baraja = [...poolToppings];
  for (let i = baraja.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [baraja[i], baraja[j]] = [baraja[j], baraja[i]];
  }

  const numDescartadosOptions =
    baraja.length >= 4 ? [1, 2, 2, 3] : [1, 2];
  const numDescartados = Math.min(
    baraja.length - 1,
    numDescartadosOptions[Math.floor(Math.random() * numDescartadosOptions.length)]
  );

  const descartados = baraja.slice(0, numDescartados);
  const requeridos = baraja.slice(numDescartados);

  const opcionesCantidad = [2, 3, 4];
  const cantidadPorCadaUno =
    opcionesCantidad[Math.floor(Math.random() * opcionesCantidad.length)];

  const listaCeros = descartados
    .map((k) => `0 ${TOPPING_PLURALS[k] || TOPPING_NAMES[k]}`)
    .join(' y ');
  const listaRequeridos = requeridos
    .map((k) => `${cantidadPorCadaUno} de ${TOPPING_NAMES[k] || k}`)
    .join(', ');

  const chosen =
    SABIO_INDIA_PROFILES[Math.floor(Math.random() * SABIO_INDIA_PROFILES.length)];

  const dialogue = `¡Namasté! Hoy quiero una pizza con ${listaCeros}. ¡Pero de los ingredientes de mi lista que NO nombré, pon ${cantidadPorCadaUno} de cada uno y córtala en ${chosenCuts} porciones!`;

  const clarification = `El 0 significa NINGUNO (0 de ${descartados
    .map((k) => TOPPING_NAMES[k])
    .join(', ')}). Pon exactamente ${listaRequeridos}, con salsa roja, queso mozzarella, horneada 1 vez y cortada en ${chosenCuts} porciones.`;

  return {
    id: `sabio-india-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName: chosen.name,
    customerType: 'sabio_india',
    menuOrderTitle: 'Reto del Cero (0)',
    sabioZeroChallenge: {
      descartados,
      requeridos,
      cantidadPorCadaUno,
      poolToppings,
    },
    avatar: chosen.avatar,
    dialogue,
    clarification,
    recipe: {
      size: chosenSize,
      shape: chosenShape,
      sauce: 'whole',
      cheese: 'whole',
      toppings: requeridos.map((type) => ({
        type,
        placement: 'whole',
        exactCount: cantidadPorCadaUno,
      })),
      bakeLevel: 1,
      cuts: chosenCuts,
    },
    basePrice: info.precio + 3.0,
    patienceTotal: 115,
    tipMultiplier: 1.35,
  };
}

export function createRuedaMaharajaOrder(): CustomerOrder {
  const tamanos: PizzaSize[] = ['Pequeña', 'Mediana', 'Familiar'];
  const opcionesPorciones = [4, 6, 8];

  const chosenSize = tamanos[Math.floor(Math.random() * tamanos.length)];
  const chosenShape: PizzaShape = 'Circular';
  const chosenCuts = opcionesPorciones[Math.floor(Math.random() * opcionesPorciones.length)];
  const info = CATALOGO_TAMANOS[chosenSize];

  const guestPool: {
    name: string;
    customerType: CustomerOrder['customerType'];
    avatar: CustomerAvatarConfig;
  }[] = [
    {
      name: 'Maharajá Vikram',
      customerType: 'moderno',
      avatar: {
        skinColor: '#C68B59',
        hairStyle: 'sage',
        hairColor: '#1E293B',
        shirtColor: '#059669',
        accessory: 'bindi',
        baseExpression: 'smug',
      },
    },
    {
      name: 'Sabio Aryabhata de la India',
      customerType: 'moderno',
      avatar: SABIO_INDIA_PROFILES[0].avatar,
    },
    {
      name: 'Valentina Moderna',
      customerType: 'moderno',
      avatar: MODERNO_PROFILES[0].avatar,
    },
    {
      name: 'Mateo el Hambriento',
      customerType: 'moderno',
      avatar: CUSTOMER_POOL[0].avatar,
    },
  ];

  const guest = guestPool[Math.floor(Math.random() * guestPool.length)];

  const dialogue = `¡Namasté! Quiero una Rueda de Maharajá ${chosenSize} en base de harina Naan Verde con ghee y ajo picado, queso paneer, pollo tandoori (o garbanzos especiados), hojas de cilantro y menta. ¡Hornéala 2 veces para bordes dorados y burbujas crujientes, en ${chosenCuts} porciones!`;

  const clarification = `Receta Rueda de Maharajá (${chosenSize} · Circular): En Masa elige Harina Naan Verde (color verde, ya trae ghee y ajo). NO pongas salsa roja ni mozzarella. Coloca Queso Paneer, Pollo Tandoori/Garbanzos y Cilantro y Menta. Hornea 2 veces (alta temperatura) y corta en ${chosenCuts} porciones.`;

  return {
    id: `rueda-maharaja-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName: guest.name,
    customerType: guest.customerType,
    menuOrderTitle: 'Rueda de Maharajá',
    avatar: guest.avatar,
    dialogue,
    clarification,
    recipe: {
      dough: 'naan_verde',
      size: chosenSize,
      shape: chosenShape,
      sauce: 'none',
      cheese: 'none',
      toppings: [
        { type: 'queso_paneer', placement: 'whole', minCount: 6, recommendedCount: 9 },
        { type: 'pollo_tandoori', placement: 'whole', minCount: 6, recommendedCount: 9 },
        { type: 'cilantro_menta', placement: 'whole', minCount: 6, recommendedCount: 9 },
      ],
      bakeLevel: 2,
      cuts: chosenCuts,
    },
    basePrice: info.precio + 5.0,
    patienceTotal: 120,
    tipMultiplier: 1.4,
  };
}

export const CUSTOMER_POOL: CustomerOrder[] = [
  {
    id: 'cust-1',
    customerName: 'Mateo el Hambriento',
    avatar: {
      skinColor: '#F5D0A9',
      hairStyle: 'short',
      hairColor: '#4A2E18',
      shirtColor: '#2563EB',
      accessory: 'earring',
      baseExpression: 'happy',
    },
    dialogue: '¡Hola! Quiero una pizza de queso bien sencillita pero sabrosa. ¿Puedes cortarla en 6?',
    clarification: 'Solo masa, salsa de tomate y queso mozzarella. Cortada en 6 porciones normales.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 8.00,
    patienceTotal: 90,
    tipMultiplier: 1.0,
  },
  {
    id: 'cust-2',
    customerName: 'Doña Carmen',
    avatar: {
      skinColor: '#E8BEAC',
      hairStyle: 'bun',
      hairColor: '#9CA3AF',
      shirtColor: '#DC2626',
      accessory: 'glasses',
      baseExpression: 'curious',
    },
    dialogue: 'Buenos días, cariño. Una pizza de pepperoni clásica para mi nieto, por favor. Cortada en 6.',
    clarification: 'Masa, salsa roja, queso y rodajas de pepperoni bien distribuidas por toda la pizza. Cortada en 6.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'pepperoni', placement: 'whole', minCount: 12, recommendedCount: 18 },
      ],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 11.50,
    patienceTotal: 85,
    tipMultiplier: 1.1,
  },
  {
    id: 'cust-3',
    customerName: 'Lucas el Poeta',
    avatar: {
      skinColor: '#F3C59A',
      hairStyle: 'curly',
      hairColor: '#1F2937',
      shirtColor: '#059669',
      accessory: 'glasses',
      baseExpression: 'neutral',
    },
    dialogue: 'Quiero que el noble trigo sienta el fuego sagrado del horno... dos veces. Sin adornos de salsa ni queso.',
    clarification: 'Solo masa pelada, sin salsa y sin queso, pasada dos veces por el horno (bien cocida), cortada en 4 rebanadas.',
    recipe: {
      sauce: 'none',
      cheese: 'none',
      toppings: [],
      bakeLevel: 2,
      cuts: 4,
    },
    basePrice: 6.50,
    patienceTotal: 80,
    tipMultiplier: 1.25,
  },
  {
    id: 'cust-4',
    customerName: 'Sofía la Arquitecta',
    avatar: {
      skinColor: '#FBE8D3',
      hairStyle: 'bun',
      hairColor: '#D97706',
      shirtColor: '#9333EA',
      accessory: 'glasses',
      baseExpression: 'curious',
    },
    dialogue: 'Necesito una pizza dividida: mitad pepperoni rojo y mitad champiñones del bosque. Salsa y queso en ambas.',
    clarification: 'Salsa y queso en toda la pizza. En la mitad izquierda pon solo pepperoni, y en la mitad derecha pon solo champiñones. Cortada en 6.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'pepperoni', placement: 'left', minCount: 6, recommendedCount: 9 },
        { type: 'mushroom', placement: 'right', minCount: 6, recommendedCount: 9 },
      ],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 13.00,
    patienceTotal: 90,
    tipMultiplier: 1.15,
  },
  {
    id: 'cust-5',
    customerName: 'Diego el Fan del Bosque',
    avatar: {
      skinColor: '#ECC9A8',
      hairStyle: 'afro',
      hairColor: '#111827',
      shirtColor: '#D97706',
      accessory: 'mustache',
      baseExpression: 'happy',
    },
    dialogue: '¡Una pizza de champiñones y aceitunas negras! Que huela a tierra fresca.',
    clarification: 'Salsa, queso, champiñones y aceitunas por toda la pizza. Cortada en 6 porciones.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'mushroom', placement: 'whole', minCount: 12, recommendedCount: 18 },
        { type: 'olive', placement: 'whole', minCount: 12, recommendedCount: 18 },
      ],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 13.50,
    patienceTotal: 85,
    tipMultiplier: 1.1,
  },
  {
    id: 'cust-6',
    customerName: 'Alicante (El Rival Pizzero)',
    avatar: {
      skinColor: '#E2B18A',
      hairStyle: 'chef',
      hairColor: '#374151',
      shirtColor: '#DC2626',
      accessory: 'mustache',
      baseExpression: 'smug',
    },
    dialogue: '¡Ja! Dicen que tienes buen toque. Prepárame una auténtica Margherita: salsa, queso y albahaca fresca. ¡Que esté crujiente!',
    clarification: 'Pizza Margherita: salsa de tomate, queso mozzarella y hojas de albahaca fresca. Pásala dos veces para que esté bien cocida, cortada en 6.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'basil', placement: 'whole', minCount: 10, recommendedCount: 16 },
      ],
      bakeLevel: 2,
      cuts: 6,
    },
    basePrice: 12.50,
    patienceTotal: 75,
    tipMultiplier: 1.3,
  },
  {
    id: 'cust-7',
    customerName: 'Valeria la Vegana',
    avatar: {
      skinColor: '#FFE0BD',
      hairStyle: 'curly',
      hairColor: '#78350F',
      shirtColor: '#10B981',
      accessory: 'earring',
      baseExpression: 'happy',
    },
    dialogue: '¡Hola! Nada de productos animales para mí. Solo salsa roja, champiñones, aceitunas y albahaca. ¡Cero queso y cero carne!',
    clarification: 'Masa con salsa de tomate pero SIN QUESO. Añade champiñones, aceitunas y albahaca. Cortada en 6 o 8.',
    recipe: {
      sauce: 'whole',
      cheese: 'none',
      toppings: [
        { type: 'mushroom', placement: 'whole', minCount: 10, recommendedCount: 16 },
        { type: 'olive', placement: 'whole', minCount: 10, recommendedCount: 16 },
        { type: 'basil', placement: 'whole', minCount: 8, recommendedCount: 14 },
      ],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 14.00,
    patienceTotal: 85,
    tipMultiplier: 1.2,
  },
  {
    id: 'cust-8',
    customerName: 'Bruno el Carnívoro',
    avatar: {
      skinColor: '#D1A374',
      hairStyle: 'short',
      hairColor: '#1F2937',
      shirtColor: '#B91C1C',
      accessory: 'mustache',
      baseExpression: 'happy',
    },
    dialogue: '¡Carne, dame carne pura! Pepperoni y salchicha italiana bien cargada con queso derretido.',
    clarification: 'Salsa de tomate, queso, pepperoni y salchicha italiana por toda la pizza. Cortada en 6.',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'pepperoni', placement: 'whole', minCount: 12, recommendedCount: 18 },
        { type: 'sausage', placement: 'whole', minCount: 12, recommendedCount: 18 },
      ],
      bakeLevel: 1,
      cuts: 6,
    },
    basePrice: 15.50,
    patienceTotal: 85,
    tipMultiplier: 1.2,
  },
  {
    id: 'cust-9',
    customerName: 'Clara la Minimalista',
    avatar: {
      skinColor: '#F5D0A9',
      hairStyle: 'beanie',
      hairColor: '#4B5563',
      shirtColor: '#1E293B',
      accessory: 'glasses',
      baseExpression: 'neutral',
    },
    dialogue: 'Una pizza blanca sencilla. Mucho queso mozzarella y nada de salsa de tomate, cortada en 4 grandes porciones.',
    clarification: 'Masa con queso mozzarella derretido pero SIN salsa de tomate. Cortada en 4 rebanadas.',
    recipe: {
      sauce: 'none',
      cheese: 'whole',
      toppings: [],
      bakeLevel: 1,
      cuts: 4,
    },
    basePrice: 8.50,
    patienceTotal: 80,
    tipMultiplier: 1.05,
  },
  {
    id: 'cust-10',
    customerName: 'Sammy el Niño',
    avatar: {
      skinColor: '#FCE7C8',
      hairStyle: 'short',
      hairColor: '#B45309',
      shirtColor: '#F59E0B',
      accessory: 'earring',
      baseExpression: 'happy',
    },
    dialogue: '¡Mamá me dejó pedir la pizza! ¡Quiero una pizza con forma de sol llena de pepperoni y sin cortar!',
    clarification: 'Pizza clásica de salsa, queso y pepperoni en toda la superficie, pero ¡OJO! ¡NO LA CORTES! Sin rebanar (0 cortes).',
    recipe: {
      sauce: 'whole',
      cheese: 'whole',
      toppings: [
        { type: 'pepperoni', placement: 'whole', minCount: 12, recommendedCount: 18 },
      ],
      bakeLevel: 1,
      cuts: 0,
    },
    basePrice: 11.00,
    patienceTotal: 90,
    tipMultiplier: 1.2,
  },
];
