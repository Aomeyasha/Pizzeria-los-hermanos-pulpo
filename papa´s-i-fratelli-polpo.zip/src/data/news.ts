export interface PnnNewsItem {
  day: number;
  headline: string;
  subheadline: string;
  story: string;
  tip: string;
  trendingTopping?: string;
  extraBulletin?: {
    badge: string;
    title: string;
    story: string;
    image?: string;
  };
}

export const PNN_NEWS_ARCHIVE: PnnNewsItem[] = [
  {
    day: 1,
    headline: '¡PAPA´S I FRATELLI POLPO ABRE SUS PUERTAS EN EL BARRIO!',
    subheadline: 'El corresponsal Octavio reporta desde su línea directa marina.',
    story: 'El legendario Alicante, dueño de la pizzería vecina, declara: "¡No durarán ni tres días... el arte de la masa no es para principiantes!" Nuestro corresponsal Octavio afirma que el aroma del horno ya atrae a los primeros clientes ansiosos.',
    tip: 'Consejo de Octavio: Presta mucha atención a si el cliente pide salsa, queso o cortes específicos. Si dudas de su pedido, pulsa "¿Qué?".',
    trendingTopping: 'pepperoni',
  },
  {
    day: 2,
    headline: '¡ÚLTIMA HORA: LLEGA UN CLIENTE DE OTRA ERA AL BARRIO!',
    subheadline: 'Testigos avistan a un auténtico cavernícola haciendo fila frente a Papa´s i fratelli Polpo.',
    story: 'Una misteriosa grieta temporal en la avenida dejó salir a un hambriento visitante de la Edad de Piedra atraído por el aroma del horno y de la Pizza de Mamut. No habla con números modernos: pide sus porciones [ | | | | ] y cada ingrediente usando rayitas (|).',
    tip: 'Consejo de Octavio: Desde hoy (Día 2 en adelante) recibirás clientes cavernícolas. Cuenta bien sus rayitas (|) para cortar las rebanadas y poner la carne de mamut y toppings exactos, o pulsa "¿Qué?" para aclarar.',
    trendingTopping: 'carne_mamut',
  },
  {
    day: 3,
    headline: 'BOOM DE LOS HONGOS Y ACEITUNAS EN LA CIUDAD',
    subheadline: 'Los agricultores locales reportan cosecha récord de champiñones frescos.',
    story: 'Los clientes ahora piden combinaciones de bosque: champiñones y aceitunas. La vegetariana Valeria afirma que "la pizza sin carne es la verdadera comida del futuro".',
    tip: 'Consejo del día: En las pizzas de "mitad y mitad", distribuye los ingredientes cuidadosamente a la izquierda y derecha para ganar la máxima propina.',
    trendingTopping: 'mushroom',
    extraBulletin: {
      badge: '🏛️ Noticia Extra · Antiguo Egipto',
      title: '¡Llegan visitantes egipcios que miden con su propio cuerpo!',
      story:
        'Una caravana del Nilo trajo a un Faraón y a una Momia al barrio. ¡Cuidado en la cocina! En el Antiguo Egipto no usaban grameras ni básculas: miden las cosas usando partes de su cuerpo como patrón — 🖐️ 1 Mano Extendida (2 puñados), 💪 1 Codo (del codo a la mano, 4 puñados) y 💪💪 2 Codos (6 puñados). Al terminar de atenderlos, la cocina regresa automáticamente a tu gramera normal.',
      image: '/assets/aistudio/image_4a13d1bc.png',
    },
  },
  {
    day: 4,
    headline: 'ALICANTE DESAFÍA PÚBLICAMENTE A NUESTRO CHEF',
    subheadline: 'El veterano pizzero afirma que nadie sabe hacer una auténtica Margherita.',
    story: '"¡Masa fina, salsa dulce, queso cremoso y hojas de albahaca fresca bien tostadas!", rugió Alicante frente a las cámaras de PNN.',
    tip: 'Consejo del chef: Desbloquea la Guía de Toppings o el Horno Rápido en la tienda de mejoras para acelerar tus pedidos.',
    trendingTopping: 'basil',
    extraBulletin: {
      badge: '🧘🏽‍♂️ Nuevo Invitado Permanente · Día 4+',
      title: '¡Llega el Sabio Matemático de la India y se queda en la ciudad!',
      story:
        'A partir de hoy (Día 4) y durante todos los días siguientes nos visitará un nuevo cliente fijo: el Sabio de la India, maestro del número CERO (0). ¡Atento a su acertijo! Cuando pide "0" de un ingrediente significa NINGUNO, y te pedirá 2, 3 o 4 unidades exactas de cada ingrediente de su lista que NO nombró.',
    },
  },
  {
    day: 5,
    headline: 'FESTIVAL DE LA PIZZA: RÉCORD HISTÓRICO DE VENTAS',
    subheadline: 'Nuestra pizzería nominada al prestigioso premio "Gran Pizza del Año".',
    story: 'Los críticos elogian la precisión de los cortes y la frescura de los ingredientes. Clientes de toda la ciudad viajan solo para disfrutar el aroma del horno.',
    tip: 'Consejo final: Mantén la felicidad de los clientes alta entregando rápido para recibir propinas generosas.',
  },
];
